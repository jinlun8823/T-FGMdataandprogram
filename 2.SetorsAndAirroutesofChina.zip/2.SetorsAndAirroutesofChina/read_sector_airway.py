import os
import sys
import numpy as np
import pandas as pd


def polygon_area(points):
    """返回多边形面积"""
    area = 0
    q = points[-1]
    for p in points:
        area += p[0] * q[1] - p[1] * q[0]
        q = p
    return area / 2


def read_airway_xml(xml):
    import xml.etree.ElementTree as ET

    tree = ET.parse(xml)
    root = tree.getroot()
    airway_dict = {}
    for a1 in root:  ### a1.tag = airway
        keyname = a1.attrib["code"]
        airway_att = {}
        airway_att.update(a1.attrib)
        points = []
        points_info = []
        for a2 in a1:  ### a2.tag = point
            latdu = int(a2.attrib["latitude"][0:2])
            latfen = int(a2.attrib["latitude"][2:4])
            latmiao = float(a2.attrib["latitude"][4:-1])
            lat = latdu + latfen * 1.0 / 60 + latmiao / 3600
            londu = int(a2.attrib["longitude"][0:3])
            lonfen = int(a2.attrib["longitude"][3:5])
            lonmiao = float(a2.attrib["longitude"][5:-1])
            lon = londu + lonfen * 1.0 / 60 + lonmiao / 3600
            points.append((lon, lat, a2.attrib["pcname"]))
            points_info.append(a2.attrib)
        airway_att["points"] = points
        airway_att["points_info"] = points_info
        airway_dict.update({keyname: airway_att})
    return airway_dict


airways = read_airway_xml(os.path.join(os.path.dirname(sys.argv[0]), "airway.xml"))


def read_sector_xml(xml):
    import xml.etree.ElementTree as ET

    tree = ET.parse(xml)
    root = tree.getroot()
    sector_dict = {}
    for a1 in root:  ### a1.tag = region
        for a2 in a1:  ### a2.tag = ctrl_area
            for a3 in a2:  ### a3.tag = sector
                keyname = a3.attrib["code"]
                sector_att = {}
                sector_att.update(a3.attrib)
                location = []
                for a4 in a3:  ### a4.tag = point
                    latdu = int(a4.attrib["latitude"][0:2])
                    latfen = int(a4.attrib["latitude"][2:4])
                    latmiao = float(a4.attrib["latitude"][4:-1])
                    lat = latdu + latfen * 1.0 / 60 + latmiao / 3600
                    londu = int(a4.attrib["longitude"][0:3])
                    lonfen = int(a4.attrib["longitude"][3:5])
                    lonmiao = float(a4.attrib["longitude"][5:-1])
                    lon = londu + lonfen * 1.0 / 60 + lonmiao / 3600
                    location.append((lon, lat))
                sector_att["location"] = location
                sector_dict.update({keyname: sector_att})
    return sector_dict


sectors = read_sector_xml(os.path.join(os.path.dirname(sys.argv[0]), "sector.xml"))


# xi,yi = m(sectors['ZBAAAP01(N)']['location'][0])
def get_position(name, sectors):
    keyname = name
    lons = []
    lats = []
    for i in range(0, len(sectors[keyname]["location"])):
        lons.append(sectors[keyname]["location"][i][0])
        lats.append(sectors[keyname]["location"][i][1])

    position_list = []
    lon1 = 999
    lon2 = 0
    lat1 = 999
    lat2 = 0
    for i in range(len(lons)):
        if lats[i] < lat1:
            lat1 = lats[i]
        if lats[i] > lat2:
            lat2 = lats[i]
        if lons[i] < lon1:
            lon1 = lons[i]
        if lons[i] > lon2:
            lon2 = lons[i]
        position_list.append([lats[i], lons[i]])
    bounds = [lon1, lat1, lon2, lat2]
    return position_list, bounds


# position_list, bounds = get_position('ZGGGAR01',sectors)
