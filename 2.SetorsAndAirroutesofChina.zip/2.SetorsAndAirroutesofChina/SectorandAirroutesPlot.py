# import pandas as pd

# data=pd.read_csv('timefileforchina20191101.csv')
# dic={}
# for i in range(len(data)):
#     dic[data['ARname'][i]]=data['time00'][i]
# # -*- coding: utf-8 -*-
"""
Created on Sat Jan  8 17:01:24 2022

@author: w10
"""
import matplotlib.pyplot as plt
from matplotlib.patches import Polygon
# from mpl_toolkits.basemap import Basemap
import numpy as np
import pandas as pd
# zi = griddata(np.array(x), np.array(y), np.array(Temperature), xi, yi, interp='linear')
fig = plt.figure(figsize=(16,8))
ax1 = fig.add_axes([0.1,0.1,0.8,0.8])
# 绘图的经纬度范围，经度范围113.4-115.8,纬度范围37.3-38.9
plt.rcParams["font.family"]='Times New Roman'######全局字体
plt.rcParams["font.size"]=30.0##########小四
plt.rcParams["text.color"]='black'#############图例和标题文本字体颜色（）
plt.rcParams["mathtext.fontset"]='stix'
# map2 = Basemap(llcrnrlon=70,llcrnrlat=16,urcrnrlon=135,urcrnrlat=55, lat_1=20, lat_2=35, lon_0=110,ax=ax1)#创建一个地图，设定经纬度
# map2.drawcoastlines()#绘制海岸线
# map2.drawcountries(linewidth=1.5)#画上国家线
# map2.drawlsmask()#####etopo地形图，shadedrelief浮雕,bluemarble,卫星图,drawlsmask()黑白图.warpimage()是另一种卫星图


# # for info, shape in zip(map2.comarques_info, map2.comarques):
# #     x, y = zip(*shape) 
# #     map2.plot(x, y, marker=None,color='red')
# # map2.readshapefile('gadm36_CHN_2','city',drawbounds=True)
# map2.readshapefile('gadm36_CHN_1','city',drawbounds=True,color='black')#加载行政区划文件CHN1:省。CHN2：市，CHN3：区
# map2.readshapefile('gadm36_TWN_1','city',drawbounds=True,color='black')
# # map2.fillcontinents(color='skyblue', lake_color='none')
# ###################################
# parallels = np.arange(0.,90,5.) 
# map2.drawparallels(parallels,labels=[1,0,0,0],fontsize=15) # 绘制纬线
# ##################################
# meridians = np.arange(70.,140.,5.)
# map2.drawmeridians(meridians,labels=[0,0,0,1],fontsize=15) # 绘制经线
#################################
ax1.axis('off')
plt.gca().xaxis.set_major_locator(plt.NullLocator())
plt.gca().yaxis.set_major_locator(plt.NullLocator())
plt.subplots_adjust(top=1, bottom=0, left=0, right=1, hspace=0, wspace=0)
plt.margins(0, 0)
####################################################在地图上画散点图
#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
Created on Thu Nov 28 15:28:23 2019

@author: atc
"""

def polygon_area(points):
    """返回多边形面积
    """
    area = 0
    q = points[-1]
    for p in points:
        area += p[0] * q[1] - p[1] * q[0]
        q = p
    return area / 2
def read_airway_xml(xml):
    import xml.etree.ElementTree as ET
    tree = ET.parse(xml)
    root = tree.getroot()
    airway_dict={}
    for a1 in root:      ### a1.tag = airway
        keyname = a1.attrib['code']
        airway_att = {}
        airway_att.update(a1.attrib)
        points = []
        points_info = []
        for a2 in a1:     ### a2.tag = point
            latdu = int(a2.attrib['latitude'][0:2])
            latfen = int(a2.attrib['latitude'][2:4])
            latmiao = float(a2.attrib['latitude'][4:-1])
            lat = latdu + latfen*1.0/60 + latmiao/3600
            londu = int(a2.attrib['longitude'][0:3])
            lonfen = int(a2.attrib['longitude'][3:5])
            lonmiao = float(a2.attrib['longitude'][5:-1])
            lon = londu + lonfen*1.0/60 + lonmiao/3600
            points.append((lon,lat,a2.attrib['pcname']))
            points_info.append(a2.attrib)      
        airway_att['points'] = points
        airway_att['points_info'] = points_info      
        airway_dict.update({keyname:airway_att})                      
    return airway_dict
airways = read_airway_xml('airway.xml')
def read_sector_xml(xml):
    import xml.etree.ElementTree as ET
    tree = ET.parse(xml)
    root = tree.getroot()
    sector_dict={}
    for a1 in root:      ### a1.tag = region
        for a2 in a1:     ### a2.tag = ctrl_area
            for a3 in a2:   ### a3.tag = sector 
                keyname = a3.attrib['code']
                sector_att = {}
                sector_att.update(a3.attrib)
                location = []
                for a4 in a3:  ### a4.tag = point
                     latdu = int(a4.attrib['latitude'][0:2])
                     latfen = int(a4.attrib['latitude'][2:4])
                     latmiao = float(a4.attrib['latitude'][4:-1])
                     lat = latdu + latfen*1.0/60 + latmiao/3600
                     londu = int(a4.attrib['longitude'][0:3])
                     lonfen = int(a4.attrib['longitude'][3:5])
                     lonmiao = float(a4.attrib['longitude'][5:-1])
                     lon = londu + lonfen*1.0/60 + lonmiao/3600
                     location.append((lon,lat))
                sector_att['location'] = location
                sector_dict.update({keyname:sector_att})
    return sector_dict
sectors = read_sector_xml('sector.xml')
#xi,yi = m(sectors['ZBAAAP01(N)']['location'][0])
def get_position(name,sectors):
    keyname = name
    lons = []
    lats = []
    for i in range(0,len(sectors[keyname]['location'])):
        lons.append(sectors[keyname]['location'][i][0])
        lats.append(sectors[keyname]['location'][i][1])
    
    position_list = []
    lon1 = 999
    lon2 = 0
    lat1 = 999
    lat2 = 0
    for i in range(len(lons)):
        if lats[i] < lat1:
            lat1 = lats[i]
        if lats[i] > lat2:
            lat2 = lats[i]
        if lons[i] < lon1:
            lon1 = lons[i]
        if lons[i] > lon2:
            lon2 = lons[i]
        position_list.append([lats[i],lons[i]])
    bounds = [lon1, lat1, lon2, lat2]
    return position_list, bounds
position_list, bounds = get_position('ZGGGAR01',sectors)

import pandas as pd
# datafuel=pd.read_csv('timefileforchina20191106.csv')
############################################################################################
dicarea={}
for i in sectors.keys():
    dicarea[i]=abs(polygon_area(sectors[i]['location']))*110*110
flowdic={}
namelis=[]
for i in sectors.keys():
    namelis.append(i)
# fuellis=[]    
# for i in range(len(datafuel)):
#     fuellis.append(datafuel['time00'][i])
# for i in range(len(namelis)):
#     flowdic[namelis[i]]=fuellis[i]

##########################################################################################
colors=['lime','lawngreen','greenyellow','yellow','sandybrown','salmon','tomato','red','darkred']
colors=['lime','lawngreen','greenyellow','yellow','sandybrown','salmon','tomato','red','darkred']

for key2 in airways.keys():
    xlon=[];ylat=[]
    for i in range(len(airways[key2]['points'])):
        xlon.append(airways[key2]['points'][i][0])
        ylat.append(airways[key2]['points'][i][1])
    plt.plot(xlon,ylat, marker='*',color='royalblue',    markersize=1, markeredgewidth=1,linewidth=0.5)
#########################################################################
lisnum=[]

dicflowdensity={}
for i in flowdic.keys():
    dicflowdensity[i]=flowdic[i]/dicarea[i]
for i in dicflowdensity.keys():
    lisnum.append(dicflowdensity[i])

# for i in sectors.keys():
#     dicflowdensity[i]=datafuel
# for j in range(len(datafuel)):
#     datafuel['ARname']

for key in sectors.keys():
    xlon=[];ylat=[]
    for i in range(len(sectors[key]['location'])):
        xlon.append(sectors[key]['location'][i][0])
        ylat.append(sectors[key]['location'][i][1])
    plt.fill(xlon,ylat,color='blue',alpha=0.06)
# x1=[114.85,114.968,115.417,115.4083,116.2119,116.090555,115.91027,114.4616667,114.3280555,114.2,114.735,114.85];
# y1=[24.8,24.76,25.092,24.673,24.4825,24.17333,23.7158333,23.43334,23.6486111,23.71833,24.29333,24.8]
# # x1,y1=map2(x1,y1)
# plt.plot(x1,y1, marker='*', color='red', markersize=1, markeredgewidth=1)
plt.show()

# import matplotlib as mpl
# font = {'family': 'Times New Roman',
#         'color':  'black',
#         'weight': 'normal',
#         'size': 20,
#         }#############x,y,z标签的字体
# ax, _ = mpl.colorbar.make_axes(plt.gca(), shrink=0.96,pad=0.05)

# cmap = mpl.colors.ListedColormap(colors[::1])
# cbar = mpl.colorbar.ColorbarBase(ax, cmap=cmap,
#                        norm=mpl.colors.Normalize(vmin=0, vmax=50))
# cbar.set_label('Flow(aircraft/per hour)',fontdict=font) #设置colorbar的标签字体及其大小
# cbar.set_clim(0, 50)










