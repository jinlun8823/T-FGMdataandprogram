Description of file "2.SetorsAndAirroutesofChina":

This is the data of China's national control areas and airspace routes, with the original data files"sector. xml" and "airway. xml".

"read_sector_airway. py" is a Python decoding program for XML files.

"SegmentandAirroutesPlot.py " is a visualization program of aerospace sectors and routes data.

Certainly, this is the old data of China's airspace in 2017, not the current airspace structure operating in China. And some biases have been applied to some critical routes, waypoints, and sectors. Therefore, there is no risk of confidentiality, which can be used to support academic research conveniently.

For example, flight plan of the aircraft can be set based on the positions of the route points.





文件"2.SetorsAndAirroutesofChina"中文说明：

这是中国全国管制区、空域航路航线数据，原始数据为"sector.xml"和"airway.xml"，

"read_sector_airway.py"为针对XML文件的python解码程序

"SectorandAirroutesPlot.py"为全国航路航线的可视化数据。

当然，这是中国2017年空域的旧数据，而非当前中国空域数据。且针对部分航路、航路点、扇区关键点数据做了一些偏置，并没有涉密的风险，研究人员可以放心的用于做一些学术研究。

例如中可以依据航路航线位置为航空器设定一些飞行计划。