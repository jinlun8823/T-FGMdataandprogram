import numpy as np
import matplotlib.pyplot as plt
from sklearn.neural_network import MLPClassifier
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split, cross_val_score, GridSearchCV
from sklearn.metrics import classification_report
from sklearn.decomposition import PCA
import logging
import time


# 设置日志记录
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(message)s')


# Helper function to calculate the distance between two points in lat/lon (Haversine)
def distance(A, B):
    A0 = (A[0] / 180) * np.pi
    A1 = (A[1] / 180) * np.pi
    B0 = (B[0] / 180) * np.pi
    B1 = (B[1] / 180) * np.pi
    a = (np.sin((B1 - A1) / 2)) ** 2
    b = np.cos(A1) * np.cos(B1)
    c = (np.sin(B0 - A0) / 2) ** 2
    e = (a + b * c) ** (1 / 2)
    d = 2 * 6371 * np.arcsin(e)
    return d


# Helper function to compute heading angle between two points
def get_heading(A, B):
    if A[0] >= B[0] and A[1] >= B[1]:
        xitao = np.arcsin((A[0] - B[0]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 1e-9) ** 0.5) * 360 / (2 * np.pi)
        xita = xitao + 180
    elif A[0] < B[0] and A[1] < B[1]:
        xitao = np.arcsin((B[0] - A[0]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 1e-9) ** 0.5) * 360 / (2 * np.pi)
        xita = xitao
    elif A[0] < B[0] and A[1] >= B[1]:
        xitao = np.arcsin((A[1] - B[1]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 1e-9) ** 0.5) * 360 / (2 * np.pi)
        xita = xitao + 90
    else:
        xitao = np.arcsin((B[1] - A[1]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 1e-9) ** 0.5) * 360 / (2 * np.pi)
        xita = xitao + 270
    return xita


# Function to extract features and labels from trajectory data
def extract_features(tracklis, step=2):
    features = []
    labels = []
    maxindex = len(tracklis) - 2 * step
    for index in range(maxindex):
        subheadingindex1 = get_heading([tracklis[index][0], tracklis[index][1]], [tracklis[index + step][0], tracklis[index + step][1]])
        subheadingindex2 = get_heading([tracklis[index + step][0], tracklis[index + step][1]], [tracklis[index + 2 * step][0], tracklis[index + 2 * step][1]])
        headingindex = subheadingindex2 - subheadingindex1
        cdindex1 = tracklis[index + step][2] - tracklis[index][2]
        cdindex2 = tracklis[index + 2 * step][2] - tracklis[index + step][2]
        cdindex = (cdindex2 + cdindex1) / 2
        speedindex1 = distance([tracklis[index][0], tracklis[index][1]], [tracklis[index + step][0], tracklis[index + step][1]])
        speedindex2 = distance([tracklis[index + step][0], tracklis[index + step][1]], [tracklis[index + 2 * step][0], tracklis[index + 2 * step][1]])
        speedinex = cdindex2 - cdindex1

        # 创建特征向量
        features.append([headingindex, cdindex, speedinex])

        # 定义标签（例如，'1'表示右转，'2'表示左转，'0'表示直行）
        if headingindex > 0:
            labels.append(1)  # 右转
        elif headingindex < 0:
            labels.append(2)  # 左转
        else:
            labels.append(0)  # 直行

    return np.array(features), np.array(labels)


# Function to preprocess data (standardize features)
def preprocess_data(features):
    scaler = StandardScaler()
    features_scaled = scaler.fit_transform(features)
    return features_scaled


# Function to apply PCA for dimensionality reduction
def apply_pca(features_scaled, n_components=2):
    pca = PCA(n_components=n_components)
    features_pca = pca.fit_transform(features_scaled)
    return features_pca


# Function to train RBF Neural Network classifier
def train_rbf_classifier(features, labels, hidden_layer_sizes=(10,), max_iter=1000):
    logging.info(f"Training RBF Neural Network with hidden layers {hidden_layer_sizes} and max iterations {max_iter}")
    rbf_nn = MLPClassifier(hidden_layer_sizes=hidden_layer_sizes, activation='relu', solver='adam', max_iter=max_iter)
    rbf_nn.fit(features, labels)
    logging.info("Training complete")
    return rbf_nn


# Function to evaluate the model using cross-validation
def evaluate_model(model, features, labels):
    scores = cross_val_score(model, features, labels, cv=5)
    logging.info(f"Cross-validation scores: {scores}")
    logging.info(f"Average cross-validation score: {scores.mean()}")
    return scores


# Function to perform grid search for hyperparameter tuning
def grid_search_rbf_classifier(features, labels):
    param_grid = {
        'hidden_layer_sizes': [(10,), (50,), (100,)],
        'max_iter': [1000, 1500, 2000],
        'activation': ['relu', 'tanh']
    }
    grid_search = GridSearchCV(MLPClassifier(solver='adam'), param_grid, cv=5)
    grid_search.fit(features, labels)
    logging.info(f"Best parameters: {grid_search.best_params_}")
    return grid_search.best_estimator_


# Function to classify trajectory and visualize the results
def classify_and_visualize(tracklis, features_scaled, rbf_nn):
    predictions = rbf_nn.predict(features_scaled)
    resultdict = {"r": [], 'l': [], 's': []}

    # 根据预测结果对轨迹进行分类
    for idx, label in enumerate(predictions):
        if label == 0:
            resultdict['s'].append([idx, idx + 1])
        elif label == 1:
            resultdict['r'].append([idx, idx + 1])
        elif label == 2:
            resultdict['l'].append([idx, idx + 1])

    pltshow(resultdict, tracklis)


# Function to plot the classification results
def pltshow(resultdict, tracklis):
    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')
    for i in resultdict.keys():
        for j in range(len(resultdict[i])):
            x = []
            y = []
            z = []
            for k in range(resultdict[i][j][0], resultdict[i][j][1] + 1):
                x.append(tracklis[k][0])
                y.append(tracklis[k][1])
                z.append(tracklis[k][2])
            if i == 'l':
                ax.plot(x, y, z, label='Left turn', color='blue')
            elif i == 'r':
                ax.plot(x, y, z, label='Right turn', color='red')
            elif i == 's':
                ax.plot(x, y, z, label='Straight', color='green')

    ax.set_xlabel('Longitude')
    ax.set_ylabel('Latitude')
    ax.set_zlabel('Altitude')
    # ax.legend()
    plt.show()


# Wrapper function to process and classify a trajectory
def process_trajectory(tracklis, step=2, use_pca=False, grid_search=False):
    logging.info("Starting trajectory processing")

    # Step 1: 提取特征和标签
    features, labels = extract_features(tracklis, step=step)

    # Step 2: 预处理数据（标准化特征）
    features_scaled = preprocess_data(features)

    # Step 3: 如果需要，应用PCA进行降维
    if use_pca:
        features_scaled = apply_pca(features_scaled)

    # Step 4: 如果需要，执行网格搜索以优化超参数
    if grid_search:
        rbf_nn = grid_search_rbf_classifier(features_scaled, labels)
    else:
        # Step 4: 训练RBF神经网络
        rbf_nn = train_rbf_classifier(features_scaled, labels)

    # Step 5: 评估模型
    evaluate_model(rbf_nn, features_scaled, labels)

    # Step 6: 分类轨迹并可视化结果
    classify_and_visualize(tracklis, features_scaled, rbf_nn)


# Example trajectory data (longitude, latitude, altitude)
tracklis = [[111.4353332519528, 24.53933270263672, 10100],
[111.43289192970556, 24.539978338758285, 10100],
[111.43045060745833, 24.54062397487985, 10100],
[111.42800928521109, 24.541269611001415, 10100],
[111.42556796296385, 24.54191524712298, 10100],
[111.42316377644772, 24.542687767356984, 10100],
[111.42075958993159, 24.54346028759099, 10100],
[111.41839912885469, 24.54435757451317, 10100],
[111.41608886307675, 24.545377168722446, 10100],
[111.41383512487569, 24.546516275581954, 10100],
[111.41164409159126, 24.547771772878974, 10100],
[111.40945305830682, 24.549027270175994, 10100],
[111.40726202502239, 24.550282767473014, 10100],
[111.40513970212453, 24.551651213976726, 10100],
[111.40309190675278, 24.553128858870377, 10100],
[111.40112425177192, 24.554711652032026, 10100],
[111.39915659679106, 24.556294445193675, 10100],
[111.39710880141931, 24.557772090087326, 10100],
[111.39506100604756, 24.559249734980977, 10100],
[111.3930132106758, 24.560727379874628, 10100],
[111.39089088777794, 24.56209582637834, 10100],
[111.38876856488008, 24.56346427288205, 10100],
[111.38664624198222, 24.564832719385763, 10100],
[111.38452391908436, 24.566201165889474, 10100],
[111.3824015961865, 24.567569612393186, 10100],
[111.38027927328864, 24.568938058896897, 10100],
[111.37815695039077, 24.57030650540061, 10100],
[111.37596591710634, 24.57156200269763, 10100],
[111.37371217890528, 24.572701109557137, 10100],
[111.37140191312734, 24.573720703766412, 10100],
[111.3690916473494, 24.574740297975687, 10100],
[111.3667311862725, 24.57563758489787, 10100],
[111.36425941978875, 24.576154567263263, 10100],
[111.361787653305, 24.576671549628657, 10100],
[111.35926544450857, 24.57679549761566, 10100],
[111.35675489855075, 24.57652335921347, 10100],
[111.35424435259293, 24.576251220811283, 10100],
[111.35173380663511, 24.575979082409095, 10100],
[111.34922326067729, 24.575706944006907, 10100],
[111.34671271471947, 24.57543480560472, 10100],
[111.34420216876165, 24.57516266720253, 10100],
[111.34169162280384, 24.574890528800342, 10100],
[111.33918107684602, 24.574618390398154, 10100],
[111.33669563634777, 24.57434897337999, 10100],
[111.3342353013091, 24.57408227774585, 10100],
[111.33180007173002, 24.573818303495727, 10100],
[111.32938994761051, 24.573557050629628, 10100],
[111.32700492895057, 24.57329851914755, 10100],
[111.32461991029064, 24.57303998766547, 10100],
[111.32225999709028, 24.572784177567417, 10100],
[111.3199251893495, 24.572531088853385, 10100],
[111.31759038160872, 24.572278000139352, 10100],
[111.31524472742804, 24.572393271767265, 10100],
[111.31294598459816, 24.57287406536708, 10100],
[111.31075075579663, 24.57370854220471, 10100],
[111.30871309484212, 24.57487615469094, 10100],
[111.30688317570991, 24.576348152331278, 10100],
[111.30505325657771, 24.577820149971615, 10100],
[111.30347613795, 24.57956028729887, 10100],
[111.30189901932229, 24.58130042462613, 10100],
[111.30032190069458, 24.583040561953386, 10100],
[111.29874478206688, 24.584780699280643, 10100],
[111.29716766343917, 24.5865208366079, 10100],
[111.29559054481146, 24.588260973935157, 10100],
[111.29430506058303, 24.590226402993153, 10100],
[111.2930195763546, 24.59219183205115, 10100],
[111.29173409212616, 24.594157261109146, 10100],
[111.29044860789773, 24.596122690167142, 10100],
[111.2891631236693, 24.59808811922514, 10100],
[111.28787763944086, 24.600053548283135, 10100],
[111.28659215521243, 24.60201897734113, 10100],
[111.285306670984, 24.603984406399128, 10100],
[111.28402118675557, 24.605949835457125, 10100],
[111.28273570252713, 24.60791526451512, 10100],
[111.2814502182987, 24.609880693573118, 10100],
[111.28016473407027, 24.611846122631114, 10100]]

# 调用主函数进行轨迹处理、分类和可视化
process_trajectory(tracklis, step=2, use_pca=True, grid_search=True)
