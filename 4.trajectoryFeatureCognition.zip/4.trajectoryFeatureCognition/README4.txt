Description of file "4.trajectoryFeatureCognition":

This is a feature recognition program for 4D trajectory data, which takes a discrete set of 4D trajectory data points as input and outputs the trajectory features of each point, such as "climb", "descent", "left turn", etc.

The usage of 'trahectoryFeatureCognitionRBF.py' is similar to 'trajectoryFeatureCognitionMathmatically.py', but the inherent methods are different. The former is based on RBF neural network, while the latter is based on partial derivative and curvature calculation.




文件"trajectoryFeatureCognition"中文说明：

这是一个四维航迹数据的特征识别程序，即输入离散的四维航迹数据点集，输出每个点的航迹特征，如"爬升""下降""左转"等。

"trahectoryFeatureCognitionRBF.py"与"trajectoryFeatureCognitionMathmatically.py"功能相似，但实现方法不同，前者是基于RBF神经网络的，后者则是基于偏导数、曲率计算。