# -*- coding: utf-8 -*-
"""
写一个scatter函数，先小涨，再大涨，爬上率大概365m/s,前慢后快，调用平滑函数库
写一个标称计划函数，直线上升即可
"""
import matplotlib.pyplot as plt
import numpy as np
from matplotlib.ticker import MultipleLocator
from class_aircraft import get_heading, distance
# from icon import CustomMarker2
import matplotlib
import pandas as pd
from matplotlib.path import Path
plt.rcParams["font.sans-serif"] = ["Times New Roman"]
plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号
x_major_locator = MultipleLocator(10)
# 把x轴的刻度间隔设置为1，并存在变量里
y_major_locator = MultipleLocator(100)
# 把y轴的刻度间隔设置为1，并存在变量里
fig = plt.figure()
ax = fig.add_subplot(111)
ax.xaxis.set_major_locator(x_major_locator)
# 把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
matplotlib.rcParams.update({'font.size': 14})


def rot(verts, az):
    # 顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)],
                      [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts


iconMat = 100*np.array([[5, 1], [6, 0],
                        [5.5, -0.5],
                        [-5.5, -0.5],
                        [-7, 1.5],
                        [-6.1, 1.5],
                        [-4.6, 1],
                        [-1, 1],
                        [-3.5, 3],
                        [-1.5, 3],
                        [2, 1],
                        [5, 1]])


class CustomMarker2(Path):
    def __init__(self, icon, az):
        if icon == "icon":
            verts = iconMat
        vertices = rot(verts, az)
        super().__init__(vertices)

# 航迹数据，提取高度


trackdata = [[111.4353332519528, 24.53933270263672, 10100], [111.43289192970556, 24.539978338758285, 10100], [111.43045060745833, 24.54062397487985, 10100], [111.42800928521109, 24.541269611001415, 10100], [111.42556796296385, 24.54191524712298, 10100], [111.42312664071662, 24.542560883244544, 10100], [111.42068531846938, 24.54320651936611, 10100], [111.41824399622215, 24.543852155487674, 10100], [111.41580267397491, 24.54449779160924, 10100], [111.41336135172767, 24.545143427730803, 10100], [111.41092002948044, 24.545789063852368, 10100], [111.4084787072332, 24.546434699973933, 10100], [111.40603738498596, 24.547080336095497, 10100], [111.40359606273873, 24.547725972217062, 10103.5], [111.40115474049149, 24.548371608338627, 10103.5], [111.39871341824426, 24.54901724446019, 10111.5], [111.39627209599702, 24.549662880581756, 10119.5], [111.39383077374978, 24.55030851670332, 10127.5], [111.39138945150255, 24.550954152824886, 10135.5], [111.38894812925531, 24.55159978894645, 10143.5], [111.38650680700808, 24.552245425068016, 10143.5], [111.38406548476084, 24.55289106118958, 10151.5], [111.3816241625136, 24.553536697311145, 10159.5], [111.37918284026637, 24.55418233343271, 10167.5], [111.37674151801913, 24.554827969554275, 10175.5], [111.3743001957719, 24.55547360567584, 10183.5], [111.37185887352466, 24.556119241797404, 10191.5], [
    111.36941755127742, 24.55676487791897, 10199.5], [111.36697622903019, 24.557410514040534, 10207.5], [111.36453490678295, 24.5580561501621, 10215.5], [111.36209358453571, 24.558701786283663, 10215.5], [111.35965226228848, 24.559347422405228, 10223.5], [111.35721094004124, 24.559993058526793, 10231.5], [111.354769617794, 24.560638694648357, 10239.5], [111.35232829554677, 24.561284330769922, 10239.5], [111.34988697329953, 24.561929966891487, 10247.5], [111.3474456510523, 24.56257560301305, 10255.5], [111.34500432880506, 24.563221239134617, 10263.5], [111.34256300655782, 24.56386687525618, 10271.5], [111.34012168431059, 24.564512511377746, 10279.5], [111.33768036206335, 24.56515814749931, 10287.5], [111.33523903981612, 24.565803783620876, 10287.5], [111.33279771756888, 24.56644941974244, 10295.5], [111.33035639532164, 24.567095055864005, 10295.5], [111.32791507307441, 24.56774069198557, 10295.5], [111.32547375082717, 24.568386328107135, 10299.0], [111.32303242857994, 24.5690319642287, 10299.0], [111.3205911063327, 24.569677600350264, 10299.0], [111.31814978408546, 24.57032323647183, 10299.0], [111.31570846183823, 24.570968872593394, 10299.0], [111.31326713959099, 24.57161450871496, 10299.0], [111.31082581734375, 24.572260144836523, 10299.0], [111.30838449509652, 24.572905780958088, 10299.0], [111.30594317284928, 24.573551417079653, 10299.0]]

planlis_of_climb = [[5.1, 10100], [12.3, 10300]]  # x=距离,y=高度
VerticalError=0.12
# 航迹数据，累加提取成距离
distancelis = []
totaldis = 0
distancelis.append(totaldis)
for i in range(len(trackdata)-1):
    dis = distance([trackdata[i][0], trackdata[i][1]], [
                   trackdata[i+1][0], trackdata[i+1][1]])
    totaldis += dis
    distancelis.append(totaldis)

altitudelis = []
for i in trackdata:
    altitudelis.append(i[2])
# plt出来
data = {'x': distancelis, 'y': altitudelis}
df = pd.DataFrame(data)
df.sort_values('x')
ax.scatter(df['x'], df['y'], s=5, color='lime',label='Operated Trajectory')

# x=[[0,planlis_of_climb[0][1]],planlis_of_climb[0],planlis_of_climb[1],[trackdata[-1][0],planlis_of_climb[1][1]]]
planx = [0, planlis_of_climb[0][0], planlis_of_climb[1][0], totaldis]
plany = [planlis_of_climb[0][1], planlis_of_climb[0]
         [1], planlis_of_climb[1][1], planlis_of_climb[1][1]]
ax.plot(planx, plany, color="royalblue", marker="o",
        linewidth=1, label="Flight Plan")

ax.scatter((planx[-1]+planx[-2])/2, (plany[-1]+plany[-2])/2, marker=CustomMarker2("icon", 0), c="blue", s=399)

ax.scatter((planx[-3]+planx[-2])/2, (plany[-3]+plany[-2])/2, marker=CustomMarker2("icon", -30), c="blue", s=399)

ax.scatter((planx[-3]+planx[-4])/2, (plany[-3]+plany[-4])/2, marker=CustomMarker2("icon", 0), c="blue", s=399)

plt.title('Instruction: Turn Right Heading 327 !'+'\n'+'Vertical flight error: '+str(VerticalError)+' km',size=16)
plt.xlabel('Flight Distance (km)')
plt.ylabel('Altitude (QNE, km)')
plt.legend()
plt.show()
