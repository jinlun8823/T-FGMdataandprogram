'''后端内测画图材料导入'''
import numpy as np
from matplotlib.path import Path


# '通过Path类自定义marker'
# 定义旋转矩阵
def rot(verts, az):
    # 顺时针旋转
    rad = az / 180 * np.pi
    verts = np.array(verts)
    rotMat = np.array([[np.cos(rad), -np.sin(rad)], [np.sin(rad), np.cos(rad)]])
    transVerts = verts.dot(rotMat)
    return transVerts
iconMat = 100 * np.array([[0, 9], [1, 8],
                          [1, 2],
                          [7, -3],
                          [7, -6],
                          [1, -3],
                          [1, -9],
                          [3, -9.5],
                          [3, -10.8],
                          [0.3, -10],
                          [0, -12],
                          [-0.3, -10], [-3, -10.8], [-3, -9.5], [-1, -9], [-1, -3], [-7, -6], [-7, -3], [-1, 2],
                          [-1, 8], [0, 9]])
class CustomMarker1(Path):
    def __init__(self, icon, az):
        if icon == "icon":
            verts = iconMat
        vertices = rot(verts, az)
        super().__init__(vertices)
###################




















