
# Function to add [CLS] tag at the start and end, [SEP] before commas, and [REQ] before command words


# def remove_atc_prefix(content):
#     print('dasda')
#     # Function to remove ATC:" from the content
def remove_atc_prefix(content):
    return [line.replace('ATC: "', '').replace('."', '') for line in content]


def add_labels(content):
    # Add [CLS] at the start and end, [SEP] before commas, and [REQ] before command words
    command_words = ['turn', 'climb', 'increase', 'reduce','descend', 'maintain']
    action_words = ['heading', 'maintaining', 'to', 'at', 'by','estimating']
    cc_words=['heading passed']
    processed_content = []
    for line in content:
        # Add [CLS] at the start and end
        line = '[CLS] [OBJ]' + line.strip() + ' [CLS]'
        
        # Add [SEP] before commas
        line = line.replace(',', ' [SEP]')
        
        # Add [REQ] before command words
        for word in command_words:
            line = line.replace(f' {word} ', f' [REQ] {word} ')
        for word in cc_words:
            line = line.replace(f' {word} ', f' [ACTION] {word} [STA]')
        # Add [ACTION] before action words
        for word in action_words:
            line = line.replace(f' {word} ', f' [ACTION] {word} [STA]')
        
        processed_content.append(line)
    
    return processed_content

# Function to read the file content
def read_file(input_file):
    with open(input_file, 'r') as file:
        return file.readlines()

# Function to write the processed content with labels to a new file
def write_to_new_file_with_labels(output_file, content):
    with open(output_file, 'w') as file:
        for line in content:
            file.write(line + '\n')

# Path to the input file and output file
input_file_path = 'originalATCdata.txt'  # Replace with your input file path
output_file_path = 'processed_file_with_labels.txt'  # Replace with your desired output file path

# Read the original file
content = read_file(input_file_path)

content_without_atc = remove_atc_prefix(content)
# Apply the label addition
processed_content = add_labels(content_without_atc)

# Write the processed content with labels to the new file
write_to_new_file_with_labels(output_file_path, processed_content)

print(f"Processed content with labels has been saved to {output_file_path}")

# # 读取原始内容
# file_path = 'originalATCdata.txt'

# # 读取文件内容
# with open(file_path, 'r') as file:
#     content = file.read()

# # 清理内容，移除 'ATC:"'
# cleaned_content = content.replace('ATC: "', '').replace('"', '')

# # 列出需要添加 [ACTION] 标签的介词和 ing 动词
# prepositions_and_ing_verbs = ['heading', 'to', 'of', 'passed', 'at']

# # 处理文本并添加 [ACTION] 标签
# processed_with_action = []
# for sentence in cleaned_content.splitlines():
#     # 将逗号替换为 [SEP] 并在句首和句尾添加 [CLS] 标签
#     sentence_with_cls_sep = f"[CLS] {sentence.replace(',', ' [SEP] ')} [CLS]"
    
#     # 分割句子为单词并检查介词和 ing 动词
#     words = sentence_with_cls_sep.split(' ')
#     for i, word in enumerate(words):
#         if word.lower() in prepositions_and_ing_verbs or word.endswith('ing'):
#             words.insert(i, '[ACTION]')
    
#     processed_with_action.append(' '.join(words))

# # 打印前 10 条处理后的结果
# for line in processed_with_action[:10]:
#     print(line)
# import re


# import re
# from colorama import init, Fore, Back, Style

# # Initialize colorama
# init(autoreset=True)

# # Function to add [STA] tag before specific values such as heading, altitude, speed, waypoints
# def add_sta_tag_for_flight_level(text):
#     # Adjust [STA] tag placement specifically for FL height levels
#     text = re.sub(r'(FL \d{3})', r'[STA] \1', text)
#     return text

# def add_sta_tag_v6(text):
#     # Regular expressions to match relevant numbers and terms for [STA] tag
#     patterns = [
#         r'(\d{3,4})',  # Matches 3 or 4 digit numbers (e.g., 170, 177) (heading numbers)
#         r'(\d+ meters)',  # Matches height in meters (e.g., 8400 meters)
#         r'(FL \d{3})',  # Matches flight levels (e.g., FL 177)
#         r'(\d+ knots)',  # Matches speed in knots (e.g., 350 knots)
#         r'(\d+ ft/min)',  # Matches climb/descent rate (e.g., 1200 ft/min)
#         r'([A-Z]{3,4})',  # Matches waypoint names (e.g., LKO, OF)
#     ]
    
#     # Find the first match after [ACTION] tag and add [STA] to it
#     for pattern in patterns:
#         # Only apply [STA] after [ACTION] tag
#         text = re.sub(r'(\[ACTION\].*?)(' + pattern + ')', r'\1[STA] \2', text, count=1)
    
#     return text

# # Correctly add [STA] tag only before specific values such as heading, altitude, speed, waypoints
# def add_sta_tag_final(text):
#     # Regular expressions to match relevant numbers and terms for [STA] tag
#     patterns = [
#         r'(\d{3,4})',  # Matches 3 or 4 digit numbers (e.g., 170, 177) (heading numbers)
#         r'(\d+ meters)',  # Matches height in meters (e.g., 8400 meters)
#         r'(FL \d{3})',  # Matches flight levels (e.g., FL 177)
#         r'(\d+ knots)',  # Matches speed in knots (e.g., 350 knots)
#         r'(\d+ ft/min)',  # Matches climb/descent rate (e.g., 1200 ft/min)
#         r'([A-Z]{3,4})',  # Matches waypoint names (e.g., LKO, OF)
#     ]
    
#     # Apply the [STA] tag correctly to only the relevant parts (numbers, altitude, etc.)
#     for pattern in patterns:
#         text = re.sub(pattern, r'[STA] \1', text)
    
#     return text

# # Function to read the file and process each line
# def process_file(input_file):
#     with open(input_file, 'r') as file:
#         # Read the content of the file
#         content = file.readlines()

#     # Apply the processing functions to all sentences
#     processed_content = []
#     for line in content:
#         line = line.strip()  # Remove any leading/trailing spaces
#         line = add_sta_tag_v6(line)
#         line = add_sta_tag_for_flight_level(line)
#         line = add_sta_tag_final(line)
#         processed_content.append(line)
    
#     return processed_content

# # Function to write the processed content to a new file
# def write_to_new_file(output_file, content):
#     with open(output_file, 'w') as file:
#         for line in content:
#             file.write(line + '\n')

# # Path to the input and output files (replace with the actual paths to your files)
# input_file_path = 'originalATCdata.txt'  # Change this to your file path
# output_file_path = 'processed_ATC_data2.txt'  # Change this to your output file path

# # Process the file and get the processed content
# processed_lines = process_file(input_file_path)

# # Write the processed content to a new file
# write_to_new_file(output_file_path, processed_lines)

# print(f"Processed content has been saved to {output_file_path}")

from colorama import init, Fore

# Initialize colorama
init(autoreset=True)

# Function to apply color to text inside [ ]
def colorize_tags(text):
    # Define color for each tag
    tag_colors = {
        '[CLS]': Fore.CYAN,
        '[OBJ]': Fore.YELLOW,
        '[SEP]': Fore.MAGENTA,
        '[REQ]': Fore.GREEN,
        '[ACTION]': Fore.YELLOW,
        '[STA]': Fore.LIGHTMAGENTA_EX
    }
    
    # Apply color to each tag found in the text
    for tag, color in tag_colors.items():
        text = text.replace(tag, f'{color}{tag}{Fore.RESET}')  # Apply color and reset
    return text

# Read the file content
def read_file(file_path):
    with open(file_path, 'r') as file:
        return file.readlines()

# Example file path (Replace with the actual file path)
file_path = 'processed_file_with_labels.txt'  # Path to the uploaded file

# Read the content of the file
content = read_file(file_path)

# Process the content and print with color
for line in content:
    colored_line = colorize_tags(line.strip())
    print(colored_line)