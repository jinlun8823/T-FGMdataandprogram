import re

# 定义一个文本分类函数
def classify_commands_updated(input_file):

    with open(input_file, 'r') as file:
        lines = file.readlines()

    # 初始化分类
    climb_commands = []
    descend_commands = []
    maintain_commands = []
    turn_commands = []
    increase_speed_commands = []
    reduce_speed_commands = []
    waypoint_time_commands = []
    attitude_maintain_commands = []  # 姿态保持指令

    # 定义分类规则
    for line in lines:
        line = line.strip()
        
        # 爬升指令（例如 "climb" 或 "climb at"）
        if re.search(r'\bclimb\b', line, re.IGNORECASE):
            climb_commands.append(line)
        
        # 下降指令（例如 "descend" 或 "descend to"）
        elif re.search(r'\bdescend\b', line, re.IGNORECASE):
            descend_commands.append(line)
        
        # 保持姿态平飞指令（例如 "maintain current heading"）
        elif re.search(r'\bmaintain\b.*\bheading\b', line, re.IGNORECASE):
            maintain_commands.append(line)
        
        # 转弯指令（例如 "turn left" 或 "turn right"）
        elif re.search(r'\bturn\b.*\bheading\b', line, re.IGNORECASE):
            turn_commands.append(line)
        
        # 加速指令（例如 "increase speed"）
        elif re.search(r'\bincrease speed\b', line, re.IGNORECASE):
            increase_speed_commands.append(line)
        
        # 减速指令（例如 "reduce speed"）
        elif re.search(r'\breduce speed\b', line, re.IGNORECASE):
            reduce_speed_commands.append(line)
        
        # 控制过点时间指令（例如 "estimating"）
        elif re.search(r'\bestimating\b', line, re.IGNORECASE):
            waypoint_time_commands.append(line)
        
        # 姿态保持指令（例如 "maintaining"）
        elif re.search(r'\bmaintaining\b', line, re.IGNORECASE):
            attitude_maintain_commands.append(line)


    output_files = {}
    if climb_commands:
        output_files['climb_commands.txt'] = climb_commands
    if descend_commands:
        output_files['descend_commands.txt'] = descend_commands
    if maintain_commands:
        output_files['maintain_commands.txt'] = maintain_commands
    if turn_commands:
        output_files['turn_commands.txt'] = turn_commands
    if increase_speed_commands:
        output_files['increase_speed_commands.txt'] = increase_speed_commands
    if reduce_speed_commands:
        output_files['reduce_speed_commands.txt'] = reduce_speed_commands
    if waypoint_time_commands:
        output_files['waypoint_time_commands.txt'] = waypoint_time_commands
    if attitude_maintain_commands:
        output_files['maintain_commands2.txt'] = attitude_maintain_commands  # 更新为"姿态保持指令"

    # 保存每个分类到文件
    for filename, commands in output_files.items():
        with open(f'{filename}', 'w') as output_file:
            output_file.write("\n".join(commands))

    # 返回生成文件
    return [f'{filename}' for filename in output_files.keys()]


input_file_path = 'originalATCdata.txt'

output_files_updated = classify_commands_updated(input_file_path)

output_files_updated
