Description of file "1.OriginalATCdataAndProcess" :

The file "originalATCdata.txt" is the original control instruction data, which comes from various control areas in China. We manually removed some instructions about holding, diversion, landing/takeoff permits, or non-standard phonetic instructions to reduce the scope of flight guidance appropriately.

It should be noted that some controllers send control instructions in the form of "[callsign], [XXX control] (name of the control unit), XXXXXX (instruction)". We have removed [XXX control] (name of the control unit) because the flight guidance method proposed in the paper is deployed onboard the aircraft, not provided by specific control units. Of course, this is also due to the confidentiality requirements of civil aviation.

Firstly, "dataProcess(classified).py" is used to classify the control instructions in "originalATCdata.txt". If you successfully execute this file, we will have files as follows:
"climb_commands.txt","descend_commands.txt","increase_speed_commands.txt","maintain_commands.txt","reduce_speed_commands.txt","turn_commands.txt","waypoint_time_commands.txt",
The function of this program is to classify control instructions according to their control purposes, such as turning, climbing, descending, accelerating, decelerating, etc.

Then execute the program "dataProcess (label).py" to label the text data, and the output result is "processed_file_with_labels.txt". This file completes the labeling of the  control instruction text, and the effect is as follows:

"TAM213, turn left heading 170."   ==> [CLS] [OBJ]TAM213 [SEP] [REQ] turn left [ACTION] heading [STA]170 [CLS]
"ANA567, descend to FL 177."  ==> [CLS] [OBJ]ANA567 [SEP] [REQ] descend [ACTION] to [STA]FL 177 [CLS]
"SIA783, climb to reach 9200 meters by LKO." ==> [CLS] [OBJ]SIA783 [SEP] [REQ] climb [ACTION] to [STA]reach 9200 meters [ACTION] by [STA]LKO [CLS]

The data obtained after labelling can be used for further Bert vectorization and LSTM model training.





文件"1.OriginalATCdataAndProcess"中文说明：

其中"originalATCdata.txt"是原始的管制指令数据，它们来自于中国各地的航路和进近管制区，我们人工去除了一些等待航线、备降、着陆/起飞许可的相关指令，或者不是那么标准的管制指令，以此适当减少飞行引导指令涉及的范围。

需要说明的是，部分管制员发送的管制指令为"[callsign], [XXX control] (name of the control unit), XXXXXX(instruction)"的形式，我们把[XXX control] (name of the control unit)去掉了，因为文章提出的飞行引导方法是飞机机载部署的，而非具体的管制单位提供。
当然，这也是出于民航保密需求的考虑。

首先，"dataProcess(classified).py"用于将"originalATCdata.txt"中的管制指令做分类，如果您成功的执行了该文件，那么您将会得到：
"climb_commands.txt","descend_commands.txt","increase_speed_commands.txt","maintain_commands.txt","reduce_speed_commands.txt","turn_commands.txt","waypoint_time_commands.txt"这些文件，
这个程序的作用是将管制指令根据控制目的分类，如转弯、爬升、下降、加速、减速等。

进一步执行"dataProcess(label).py"文件，实现对原始数据的标签化处理，输出结果为"processed_file_with_labels.txt"，该文件完成了对原始管制指令文本的添加标签工作，效果如下：

"TAM213, turn left heading 170."   ==> [CLS] [OBJ]TAM213 [SEP] [REQ] turn left [ACTION] heading [STA]170 [CLS]
"ANA567, descend to FL 177."  ==> [CLS] [OBJ]ANA567 [SEP] [REQ] descend [ACTION] to [STA]FL 177 [CLS]
"SIA783, climb to reach 9200 meters by LKO." ==> [CLS] [OBJ]SIA783 [SEP] [REQ] climb [ACTION] to [STA]reach 9200 meters [ACTION] by [STA]LKO [CLS]

完成标签添加后的数据就可以用于进一步的Bert词向量化和LSTM模型训练工作了。

