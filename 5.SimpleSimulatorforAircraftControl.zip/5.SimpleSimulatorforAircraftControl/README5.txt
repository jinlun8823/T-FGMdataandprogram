Description of file "5.SimpleSimulatorforAircraftControl":

This is a simulation program that simulates aircraft control. We can achieve aircraft simulation control through the keyboard and display the aircraft's operating status in Python matplotlib.

Execute the main program "AircraftSimulator.py" on the Python terminal to start simulating flight. Of course, before that, you can customize the flight plan route in the program.

Simulate airplane control through keyboard keys:

Up arrow ↑: Small slope climb
Down arrow ↓: Climbing on a small slope
Left Arrow ←: Small Slope Left Steering
Right Arrow →: Small Slope Right Steering
A: Acceleration
D: Slow down
L: Turn left on a steep slope
R: Turn right on a steep slope
Continuously press the up arrow ↑↑: climb on a steep slope
Continuously pressing the arrow ↑↑: descending on a steep slope
Press ESC twice to exit the simulation software (if it doesn't work, try closing the Python console)

It is a relatively simple software for simulating pilots controlling aircraft, mainly used to support scholars who do not have flight simulation cabins to conduct simulation control experiments, whose requirements for trajectory execution accuracy are not so strict, and also to make it easier for researchers to understand the content of the paper.



文件"5.SimpleSimulatorforAircraftControl"中文说明：

这是一个模拟航空器控制的仿真程序，我们可以通过键盘实现航空器的仿真控制，并python   matplotlib显示航空器运行状态。

在python终端执行主程序"AircraftSimulator.py"，开始模拟飞行。当然，在这之前可以在程序中自定义飞行计划航线。

通过键盘按键模拟飞机控制：
上箭头↑ ：小坡度爬升
下箭头↓ ：小坡度爬升
左箭头← ：小坡度左转舵
右箭头→ ：小坡度右转舵
A: 加速
D：减速
L：大坡度左转
R：大坡度右转
连续按上箭头↑↑：大坡度爬升
连续按下箭头↑↑：大坡度下降
两次按下ESC: 退出仿真软件 （如果不行的话，尝试关闭python console）

当然，这是一个相对简易的模拟飞行员控制航空器的软件，主要用于支持一些没有飞行模拟舱的学者进行仿真控制实验（对于航迹执行精度要求不是那么高），同时也为让研究者们更方便的了解文章内容。