# -*- coding: utf-8 -*-
"""
气象规避区侵入测试
"""

import numpy as np

def get_critical_cb(aircraft_position,cblis):
    cblis_cp=cblis.copy()
    cblis_filter=[]
    for cb in cblis:
        if (aircraft_position[0]-cb[0])**2+(aircraft_position[1]-cb[1])**2<=1.6**2:
            cblis_filter.append(cb)
    return cblis_filter


def judge_in_cb(point, line_point1, line_point2,r):#####判断CB云对航空器航迹意图的影响
    #对于两点坐标为同一点时,返回点与点的距离
    if line_point1 == line_point2:
        point_array = np.array(point )
        point1_array = np.array(line_point1)
        return np.linalg.norm(point_array -point1_array )
    #计算直线的三个参数
    A = line_point2[1] - line_point1[1]
    B = line_point1[0] - line_point2[0]
    C = (line_point1[1] - line_point2[1]) * line_point1[0] + \
        (line_point2[0] - line_point1[0]) * line_point1[1]
    #根据点到直线的距离公式计算距离
    distance = np.abs(A * point[0] + B * point[1] + C) / (np.sqrt(A**2 + B**2)+0.00000000000000000001)
    Flag=0
    chuizux=(B**2*point[0]-A*B*point[1]-A*C)/(A*A+B*B+0.00000000000000000001)
    chuizuy=(A**2*point[1]-A*B*point[0]-B*C)/(A*A+B*B+0.00000000000000000001)
    if distance < r-0.0001 and (line_point1[0]-chuizux)*(line_point2[0]-chuizux)<0 and (line_point1[1]-chuizuy)*(line_point2[1]-chuizuy)<0:
        Flag=1
    if Flag==1:
        return True
    else:
        return False


def judge_conflict_level(cb,aircraft_position):
    if (aircraft_position[0]-cb[0])**2+(aircraft_position[1]-cb[1])**2<=(0.2+cb[2])**2:
        level=3
    elif (aircraft_position[0]-cb[0])**2+(aircraft_position[1]-cb[1])**2<=(0.5+cb[2])**2:
        level=2
    else:
        level=1
    return level







def areas_conflict_detect(cblis,current_position,heading):
    x = current_position[0]+999*(1000/(3600*110))*np.cos(np.pi/2-(heading*2*np.pi/360))
    y = current_position[1]+999*(1000/(3600*110))*np.sin(np.pi/2-(heading*2*np.pi/360))
    pred_position=[x,y]
    tflag=0
    for cb in cblis:
        if judge_in_cb([cb[0],cb[1]],current_position,pred_position,cb[2]-0.01):
            tflag=1
            cbc=cb
            break
        else:
            continue
    if  tflag==0:
        area_risks={'risklevel':0,'word':''}
    elif tflag==1:
        rlevel=judge_conflict_level(cbc,current_position)
        area_risks={'risklevel':rlevel,'word':'注意前方气象规避区'}
    return area_risks
    

# ##############################测试程序
# test=areas_conflict_detect(heading=270,
#                           cblis=[[110.7,25,0.5],[108.5,26,0.5]],
#                           current_position=[112,24.35])
# print(test)


























