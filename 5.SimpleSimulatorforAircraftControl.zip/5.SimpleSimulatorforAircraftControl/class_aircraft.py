import numpy as np
# from generate_track_basedon_critical_points import get_heading,distance

def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d

def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita

class Aircraft:######航空器类
    '''
    __init__初始化：
    callsign:航班呼号
    crafttype：航空器型号
    flightplan：原始飞行计划
    critical_track_points：关键航迹点
    current_position：当前位置
    current_v：当前速度大小
    height：当前高度
    nine_critical_position：未来九个航迹点
    eight_minute_predicted_position：预测未来8分钟的航迹
    tracklis：历史航迹信息
    
    '''
    def __init__(self,callsign='',crafttype='B737',flightplan=[],critical_track_points=[],current_position=[],nine_critical_position=[],
                eight_minute_predicted_position=[], current_v=1000, height=9800,heading=0,tracklis=[]):##Aircraft属性

        self.callsign=callsign
        self.crafttype=crafttype
        self.flightplan=flightplan
        self.current_position=current_position
        self.nine_critical_position=nine_critical_position
        self.current_v=current_v
        self.height=height
        self.critical_track_points=critical_track_points
        self.heading=heading
        # self.Value=callsign
        self.tracklis=[[current_position[0],current_position[1],self.height]]
        
    '''
    get_next_intention获得下一个目标航路点，即航迹意图
    return: 下一个航路点/abnormal
    '''
    def get_next_track_point(self, current_point, tracklis2, v, height):  #######到达下一个点的位置，速度、高度、时间
        tracklis = tracklis2.copy()

        cc = tracklis
        dellis = []
        for i in range(len(cc) - 1):
            if (cc[i][0] - cc[i + 1][0]) ** 2 + (cc[i][1] - cc[i + 1][1]) ** 2 <= (8 / 110) ** 2:
                dellis.append(i)
        tracklis = [n for i, n in enumerate(tracklis) if i not in dellis]
        #
        # a = b
        # print(a)
        if (current_point[0] - tracklis[-1][0]) ** 2 + (current_point[1] - tracklis[-1][1]) ** 2 <= (1 / 110) ** 2:
            # return "arrive"  ###已经到了
            return -2  ###已经到了
        # if (current_point[0]-tracklis[-1][0])**2+(current_point[1]-tracklis[-1][1])**2 <= (6/110)**2:
        for i in range(len(tracklis) - 1):
            if (current_point[0] - tracklis[i][0]) ** 2 + (current_point[1] - tracklis[i][1]) ** 2 <= (1 / 110) ** 2:

                # print('there1')
                # print(current_point)
                # print(tracklis[i])
                
                next_point = i + 1
                # print(next_point)
                d = distance(current_point, tracklis[next_point])
                t = d * 3600 / v
                # print('first',next_point)
                # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                return next_point
            else:
                continue
        for i in range(len(tracklis) - 1):
            # print('second',i)
            if abs(tracklis[i + 1][0] - tracklis[i][0]) >= 0.03 and abs(tracklis[i + 1][1] - tracklis[i][1]) >= 0.03:
                # print('there2')
                if (
                    min(tracklis[i][0], tracklis[i + 1][0]) - 0.003
                    <= current_point[0]
                    <= max(tracklis[i][0], tracklis[i + 1][0]) + 0.003
                    and min(tracklis[i][1], tracklis[i + 1][1]) - 0.003
                    <= current_point[1]
                    <= max(tracklis[i][1], tracklis[i + 1][1]) + 0.003
                ):
                    next_point = i + 1
                    d = distance(current_point, tracklis[next_point])
                    t = d * 3600 / v
                    # print('second',next_point)
                    # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                    return next_point

            else:
                # print('there3')
                if abs(tracklis[i + 1][0] - tracklis[i][0]) < 0.09:
                    # print('there4')
                    if (
                        min(tracklis[i][0], tracklis[i + 1][0]) - 0.09
                        <= current_point[0]
                        <= max(tracklis[i][0], tracklis[i + 1][0]) + 0.09
                        and min(tracklis[i][1], tracklis[i + 1][1]) - 0.003
                        <= current_point[1]
                        <= max(tracklis[i][1], tracklis[i + 1][1]) + 0.003
                    ):
                        next_point = i + 1
                        d = distance(current_point, tracklis[next_point])
                        t = d * 3600 / v
                        # print('second',next_point)
                        # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                        return next_point
                elif abs(tracklis[i + 1][1] - tracklis[i][1]) < 0.09:
                    # print('there5')
                    if (
                        min(tracklis[i][0], tracklis[i + 1][0]) - 0.003
                        <= current_point[0]
                        <= max(tracklis[i][0], tracklis[i + 1][0]) + 0.003
                        and min(tracklis[i][1], tracklis[i + 1][1]) - 0.009
                        <= current_point[1]
                        <= max(tracklis[i][1], tracklis[i + 1][1]) + 0.009
                    ):
                        next_point = i + 1
                        d = distance(current_point, tracklis[next_point])
                        t = d * 3600 / v  ######分钟啊
                        # print('second',next_point)
                        # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                        return next_point

        # print('attention here')#####偶尔存在丢失航迹意图的情况，这和timestamp步长有关，也和判断到达距离有关
        # print(current_point)
        return -1  ####偏离太多的情况


    '''
    get_heading():获得当前航空器航向
    return:xita,航向角度
    
    '''
    def get_heading(self, A,B):#####一个把经纬度转化成航向角的小程序
        xita=get_heading(A, B)
        return xita
    '''
    doing_current_instruction:执行指令，状态转移
    return:xita,航向角度
    
    '''
    def doing_current_instruction(self,instruction,timestamp):#
        speed=instruction['speed']
        heading=instruction['heading']
        flightlevel=instruction['flightlevel']
        timeinterval=instruction['timeinterval']
        self.current_v=speed
        if min(abs(heading-self.heading),360-abs(heading-self.heading))<90:
            self.heading=heading
        else:
            temh1=self.heading+45
            if temh1>=360:
                temh1=temh1-360
            temh2=self.heading-45
            if temh2<=0:
                temh1=temh1+360
            if  min(abs(heading-temh2),360-abs(heading-temh2))< min(abs(heading-temh1),360-abs(heading-temh1)):
                self.heading=temh2
            else:
                self.heading=temh1
        # self.heading=heading    
        x = self.current_position[0]+timeinterval*(self.current_v/(3600*110))*np.cos(np.pi/2-(self.heading*2*np.pi/360))
        y = self.current_position[1]+timeinterval*(self.current_v/(3600*110))*np.sin(np.pi/2-(self.heading*2*np.pi/360))
        self.current_position = [x,y]
        
        if self.height < flightlevel:
            # print('y')
            z = self.height+timeinterval*5
            if z >= flightlevel:
                z=flightlevel
        elif self.height > flightlevel:
            # print('y')
            z = self.height-timeinterval*5
            if z <= flightlevel:
                z=flightlevel
        else:
            z=flightlevel
        self.height=z
        self.tracklis.append([self.current_position[0],self.current_position[1],self.height,timestamp])

        # return next_position
    '''
    判定航空器所处高度层(m)
    
    ''' 
    def flight_level_classify_m(self,height):########高度配对(m)
        levellis=[11600,11300,11000,10700,10400,10100,9800,9500,9200,8900,8400,8100,7800,7500,7200,6900,6600,6300,6000,5700,5400]
        for hh in range(len(levellis)-1):
            if levellis[hh+1]<=height<levellis[hh]:
                if levellis[hh]-height<=height-levellis[hh+1]:
                    self.flightlevelm=levellis[hh]
                else:
                    self.flightlevelm=levellis[hh+1]
    '''
    判定航空器所处高度层(ft)
    
    '''          
    def flight_level_classify_ft(self,height):########高度配对(ft)
        levellis=[38100,37100,36100,35100,34100,33100,32100,31100,30100,29100,27600,26600,25600,24600,23600,22600,21700,20700,19700,18700,17700]
        for hh in range(len(levellis)-1):
            if levellis[hh+1]<=height<levellis[hh]:
                if levellis[hh]-height<=height-levellis[hh+1]:
                    self.flightlevelft=levellis[hh]
                else:
                    self.flightlevelft=levellis[hh+1]

    #####################################航迹规划结果写入
    def add_critical_track_points(self,critical_track_points):##获取关键点[{}.{},...,{}]
        self.critical_track_points=critical_track_points
    def add_eight_minute_predicted_position(self,eight_minute_predicted_position):####未来一段时间的点迹[{}.{},...,{}]
        self.eight_minute_predicted_position=eight_minute_predicted_position
        #####################################航迹预测结果写入
    def add_risks_area(self,risks_area):##获取当前风险 risk={’‘，’‘}
        self.risks_area = risks_area
    def add_risks_aircraft(self,risks_aircraft):##获取当前风险 risk={’‘，’‘}
        self.risks_aircraft = risks_aircraft
    def add_3_4D_trajectory(self,trajectory_dict):
        self.trajectory_dict=trajectory_dict
    def add_instruction_word(self,instruction_word):####str:'左转航向030'
        self.instruction_word=instruction_word
    # def judge_same_way_now(aircraftSet,thisAircraft):
    
        
#############################功能测试#######################################航空器初始化
# flightplan=[[114.133331298828, 22.5433330535889], [113.951667785645, 22.8963890075684], [113.851058959961, 23.0928325653076], 
#             [113.415802001953, 24.1916389465332], [112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#             [110.77564239502, 24.6709175109863], [110.212219238281, 25.2047214508057], [109.608329772949, 25.7749996185303], 
#             [108.72721862793, 26.0091667175293], [108.39722442627, 26.0966663360596], [107.142776489258, 26.6330547332764], 
#             [106.780281066895, 26.7866668701172], [106.375274658203, 27.1991672515869], [106.062774658203, 27.5147228240967], 
#             [105.854721069336, 27.731388092041], [105.421417236328, 28.1706657409668], [105.042221069336, 28.4466667175293],
#             [104.753051757813, 28.6572227478027], [104.555809020996, 28.7995834350586], [104.304168701172, 29.9294452667236],
#             [104.391418457031, 30.8727493286133], [104.378723144531, 31.2490005493164], [104.366668701172, 31.4333324432373],
#             [104.316665649414, 32.4099998474121], [104.294998168945, 32.8600006103516], [104.270835876465, 33.3572235107422], 
#             [104.191390991211, 34.9758338928223], [104.151947021484, 35.7758331298828], [104.124725341797, 36.2794456481934], 
#             [104.112503051758, 36.5294456481934], [103.283889770508, 36.9369430541992], [102.439720153809, 37.3583335876465], 
#             [102.035278320313, 37.4375], [101.685554504395, 37.5047225952148], [101.316108703613, 37.6538887023926], 
#             [100.918891906738, 37.8291664123535], [100.011665344238, 38.2171669006348], [97.6258316040039, 39.2294425964355], 
#             [97.033332824707, 39.4669456481934], [96.6227798461914, 39.6308326721191], [95.1452789306641, 40.2000007629395], 
#             [94.8666687011719, 40.3058319091797], [93.8480529785156, 40.9150009155273], [91.6941680908203, 42.5183334350586],
#             [89.3930587768555, 43.5577774047852], [87.9815826416016, 44.171028137207], [88.2044448852539, 44.5552787780762], 
#             [88.317497253418, 44.7486114501953], [88.9844436645508, 45.8777770996094], [88.0850296020508, 47.7475814819336],
#             [87.466667175293, 49.091667175293]]
# callsign='CSN634'
# current=[106.7800, 26.7966668701172]#############当前位置
# aircraft1=Aircraft(callsign='CSN634',flightplan=flightplan.copy(),critical_track_points=flightplan.copy(),current_position=current,height=10130,heading=80)
# ###############################################################################测试读取航迹意图
# next_po=aircraft1.get_next_track_point(current_point=aircraft1.current_position, tracklis=aircraft1.critical_track_points, v=aircraft1.current_v, height=aircraft1.height)  
# #######################################################################测试读取航向    
# hh=aircraft1.get_heading(A=aircraft1.current_position, B=next_po['point0'])
# #######################################################################测试航空器状态转移
# def get_instruction(current_point,next_point):
#     instruction={'speed':1000,'flightlevel':9800,'heading':333,'timeinterval':4}###########默认值
#     heading=get_heading(current_point,next_point)
#     #####################################################航向调整
#     instruction['heading']=heading
#     #####################################################高度调整
#     instruction['flightlevel']=9800
#     #####################################################速度调整
#     instruction['speed']=900
#     # print(instruction)
#     return instruction
# ####################################################################基于tracklis的位置迭代
# for i in range(3600):
#     next_point = aircraft1.get_next_track_point(current_point=aircraft1.current_position,tracklis=aircraft1.critical_track_points,v=aircraft1.current_v,height=aircraft1.height)
#     # print(next_point )
#     if next_point == 'arrive':
#         break
#     elif next_point=='abnormal':
#         next_point=aircraft1.critical_track_points[-1]
#         instruction = get_instruction(current_point=aircraft1.current_position,next_point=next_point)
#     else:
#         instruction = get_instruction(current_point=aircraft1.current_position,next_point=next_point['point0'])
#     # print(instruction)
#     aircraft1.doing_current_instruction(instruction,4*i)
#     i=i+1
#     print(i)
# ##############三维图像###############
# xx=[];yy=[];zz=[]

# for i in aircraft1.tracklis:
#     xx.append(i[0])
#     yy.append(i[1])
#     zz.append(i[2])
# import matplotlib.pyplot as plt
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# ax.scatter(xx,yy,zz)

# ######################################原始关键航迹数据点
# x=[];y=[];z=[]
# for i in flightplan:
#     x.append(i[0])
#     y.append(i[1])
#     z.append(9500)
# ax.scatter(x,y,z,color='green')
# #################################################
####################################################基于指令的的位置迭代
# aircraft1=Aircraft(callsign='CSN634',flightplan=flightplan.copy(),critical_track_points=flightplan.copy(),current_position=current,height=10130,heading=80)

# instruction={'speed':1050,'flightlevel':10400,'heading':30,'timeinterval':4}
# for i in range(50):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9500,'heading':290,'timeinterval':4}
# for i in range(20):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9500,'heading':90,'timeinterval':4}
# for i in range(20):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9500,'heading':230,'timeinterval':4}
# for i in range(20):
#     aircraft1.doing_current_instruction(instruction,4)


# ##############同高度转弯测试
# instruction={'speed':1050,'flightlevel':9800,'heading':0,'timeinterval':4}
# for i in range(30):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9800,'heading':90,'timeinterval':4}
# for i in range(30):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9800,'heading':180,'timeinterval':4}
# for i in range(30):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9800,'heading':270,'timeinterval':4}
# for i in range(30):
#     aircraft1.doing_current_instruction(instruction,4)
# instruction={'speed':1050,'flightlevel':9800,'heading':360,'timeinterval':4}
# for i in range(30):
#     aircraft1.doing_current_instruction(instruction,4)
# ##############三维图像###############
# xx=[];yy=[];zz=[]

# for i in aircraft1.tracklis:
#     xx.append(i[0])
#     yy.append(i[1])
#     zz.append(i[2])
# import matplotlib.pyplot as plt
# fig = plt.figure()
# ax = fig.gca(projection='3d')
# ax.scatter(xx,yy,zz)

    
    
    
    
    
    
    
    
    

