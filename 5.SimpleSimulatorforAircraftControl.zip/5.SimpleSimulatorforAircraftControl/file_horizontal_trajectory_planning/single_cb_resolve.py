import numpy as np
import math
####求圆外一点与圆的切点
def get_tangent_line(tx, ty, ox, oy, r):####
    # 求点T到圆心O的距离
    distance = math.sqrt((tx-ox) ** 2 + (ty-oy) ** 2)
#    print('distance', distance)
    # 点T到切点P的距离
    if distance <= r:
        print("输入的数值不在范围内")
        return 'diversion'
    length = math.sqrt(distance ** 2 - r ** 2)
#    print('length', length)
    # 点到圆心的单位向量
    cx = (ox - tx) / distance
    cy = (oy - ty) / distance
    # 计算切线与圆心连线的夹角
    angle = math.asin(r / distance)
    # print('angle', angle)
    # 向正反两个方向旋转单位向量
    q1x = cx * math.cos(angle)  -  cy * math.sin(angle)
    q1y = cx * math.sin(angle)  +  cy * math.cos(angle)
    q2x = cx * math.cos(-angle) -  cy * math.sin(-angle)
    q2y = cx * math.sin(-angle) +  cy * math.cos(-angle)
#    print(q1x,q1y,q2x,q2y)
    # 得到新座标y
    q1x = q1x * length + tx
    q1y = q1y * length + ty
    q2x = q2x * length + tx
    q2y = q2y * length + ty
    return [q1x, q1y, q2x, q2y]
####测试程序
# a=get_tangent_line(2, -2, 0, 0, 2)
######求两直线交点
def findIntersection(x1,y1,x2,y2,x3,y3,x4,y4):######line1:[x1,y1]-[x2,y2],line2:[x3,y3]-[x4,y4]
    px= ( (x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4) ) / ( ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4))+0.000000000001) 
    py= ( (x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4) ) / ( ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4))+0.000000000001)
    return [px, py]
# a1=get_tangent_line(3, 0, 0, 0, 1)
# a2=get_tangent_line(-3, 0, 0, 0, 1)
# point1=findIntersection(3,0,a1[0],a1[1],-3,0,a2[0],a2[1])
# point2=findIntersection(3,0,a1[0],a1[1],-3,0,a2[2],a2[3])
# point3=findIntersection(3,0,a1[2],a1[3],-3,0,a2[0],a2[1])
# point4=findIntersection(3,0,a1[2],a1[3],-3,0,a2[2],a2[3])
def find_feasible_point(point1,point2,point3,point4,ox,oy):###ox,oy:center_of_cb，找出两种绕飞方式
    dic1={'point1':point1,'point2':point2,'point3':point3,'point4':point4}
    a=(point1[0]-ox)**2+(point1[1]-oy)**2
    b=(point2[0]-ox)**2+(point2[1]-oy)**2
    c=(point3[0]-ox)**2+(point3[1]-oy)**2
    d=(point4[0]-ox)**2+(point4[1]-oy)**2
    # print(a,b,c,d)
    dic2={a:'point1',b:'point2',c:'point3',d:'point4'}
    # print(dic)
    lis=[a,b,c,d]
    lis.sort()
    return dic1[dic2[lis[0]]],dic1[dic2[lis[1]]]
# f_p=find_feasible_point(point1,point2,point3,point4,0,0)    
def find_best_point(point1,point2,point3,point4,ox,oy):###ox,oy:center_of_cb,找出绕飞距离最短的点
    a=(point1[0]-ox)**2+(point1[1]-oy)**2
    b=(point2[0]-ox)**2+(point2[1]-oy)**2
    c=(point3[0]-ox)**2+(point3[1]-oy)**2
    d=(point4[0]-ox)**2+(point4[1]-oy)**2
    if min(a,b,c,d)==a:
        return point1
    elif min(a,b,c,d)==b:
        return point2
    elif min(a,b,c,d)==c:
        return point3
    elif min(a,b,c,d)==d:
        return point4
# b_p=find_best_point(point1,point2,point3,point4,0,0)    
def judge_in_cb(point, line_point1, line_point2,r):#####判断CB云对航空器航迹意图的影响
    #对于两点坐标为同一点时,返回点与点的距离
    if line_point1 == line_point2:
        point_array = np.array(point )
        point1_array = np.array(line_point1)
        return np.linalg.norm(point_array -point1_array )
    #计算直线的三个参数
    A = line_point2[1] - line_point1[1]
    B = line_point1[0] - line_point2[0]
    C = (line_point1[1] - line_point2[1]) * line_point1[0] + \
        (line_point2[0] - line_point1[0]) * line_point1[1]
    #根据点到直线的距离公式计算距离
    distance = np.abs(A * point[0] + B * point[1] + C) / (np.sqrt(A**2 + B**2)+0.00000000000000000001)
    Flag=0
    chuizux=(B**2*point[0]-A*B*point[1]-A*C)/(A*A+B*B+0.00000000000000000001)
    chuizuy=(A**2*point[1]-A*B*point[0]-B*C)/(A*A+B*B+0.00000000000000000001)
    if distance < r-0.0001 and (line_point1[0]-chuizux)*(line_point2[0]-chuizux)<0 and (line_point1[1]-chuizuy)*(line_point2[1]-chuizuy)<0:
        Flag=1
    if Flag==1:
        return True
    else:
        return False
# judge_in_cb([120,22], [118,18], [125,24],2)  
# a1=get_tangent_line(3, 0, 0, 0, 1)
# a2=get_tangent_line(-3, 0, 0, 0, 1)
def generate_best_track(x1,y1,x2,y2,xo,yo,r):
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==False:
        critical_track=[[x1,y1],[x2,y2]]
        return critical_track
    
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==True:
        # print('lll')
        a1=get_tangent_line(x1, y1, xo, yo, r)
        a2=get_tangent_line(x2, y2, xo, yo, r)
        if a1=='diversion' or a2=='diversion':
            return 'diversion'
        point1=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[0],a2[1])
        point2=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[2],a2[3])
        point3=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[0],a2[1])
        point4=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[2],a2[3])
        
        b_p=find_best_point(point1,point2,point3,point4,xo,yo) 
        # print('转弯点',b_p,'*需要绕飞')

        critical_track=[[x1,y1],b_p,[x2,y2]]
        return critical_track
def generate_feasible_track(x1,y1,x2,y2,xo,yo,r):
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==False:
        critical_track=[[x1,y1],[x2,y2]]
        return critical_track
    
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==True:
        # print('lll')
        a1=get_tangent_line(x1, y1, xo, yo, r)
        a2=get_tangent_line(x2, y2, xo, yo, r)
        if a1=='diversion' or a2=='diversion':
            return 'diversion'
        point1=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[0],a2[1])
        point2=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[2],a2[3])
        point3=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[0],a2[1])
        point4=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[2],a2[3])
        
        f_p=find_feasible_point(point1,point2,point3,point4,xo,yo) 
        # print('方案1：转弯点',f_p[0],'*绕飞')
        # print('方案2：转弯点',f_p[1],'*绕飞')
        critical_track1=[[x1,y1],f_p[0],[x2,y2]]
        critical_track2=[[x1,y1],f_p[1],[x2,y2]]
        return critical_track1,critical_track2
    
    
############################测试代码##########################################
##############test#################积雨云(120,22),r=0.6,最短绕飞航迹
# tracklis=generate_best_track(110,16,126,28,121,22,3.6)

# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import LinearLocator, FormatStrFormatter
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# circle=Circle(xy=(121,22),radius=3.6,alpha=0.1)
# ax.add_patch(circle)
# x=[];y=[]
# for i in range(len(tracklis)):
#     x.append(tracklis[i][0])
#     y.append(tracklis[i][1])
# ax.plot(x,y)    
# ax.scatter(121,22)

####################test#################积雨云(120,22),r=0.6,可行绕飞航迹
tracklis=generate_feasible_track(110,16,126,28,121,22,3.6)

import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from matplotlib.ticker import LinearLocator, FormatStrFormatter
from matplotlib.ticker import MultipleLocator
x_major_locator=MultipleLocator(1)
#把x轴的刻度间隔设置为1，并存在变量里
y_major_locator=MultipleLocator(1)
#把y轴的刻度间隔设置为1，并存在变量里
fig=plt.figure()
ax=fig.add_subplot(111)
ax.xaxis.set_major_locator(x_major_locator)
#把x轴的主刻度设置为1的倍数
ax.yaxis.set_major_locator(y_major_locator)
ax.set_aspect(1)
circle=Circle(xy=(121,22),radius=3.6,alpha=0.1)
ax.add_patch(circle)
x=[];y=[]
for i in range(len(tracklis[0])):
    x.append(tracklis[0][i][0])
    y.append(tracklis[0][i][1])
plt.plot(x,y,color='red')

x=[];y=[]
for i in range(len(tracklis[1])):
    x.append(tracklis[1][i][0])
    y.append(tracklis[1][i][1])
plt.plot(x,y,color='blue')    
plt.scatter(121,22)    



'''
最终调用函数为 generate_best_track 和  generate_feasible_track

其中，generate_best_track 输入为(x1：航空器起始位置经度,y1：航空器起始位置纬度,x2：航空器目的位置经度,y2：航空器目的位置纬度,xo：积雨云经度,yo：积雨云纬度,r：积雨云半径（1度等于110km）)
输出为最短绕飞航迹的关键点[起点，转弯点，终点]

其中，generate_feasible_track 输入为(x1：航空器起始位置经度,y1：航空器起始位置纬度,x2：航空器目的位置经度,y2：航空器目的位置纬度,xo：积雨云经度,yo：积雨云纬度,r：积雨云半径（1度等于110km）)
输出为可选绕飞航迹的关键点  可选航迹1：[起点，转弯点，终点]  可选航迹2：[起点，转弯点，终点]

'''














