import numpy as np
# from aircraft import Aircraft

'''1°约等于110km,0.9°约等于100km,0.09°约等于10km'''

def simple_trajectory_prediction(current_position,current_v,heading,timeinterval):
    x = current_position[0]+timeinterval*(current_v/(3600*110))*np.cos(np.pi/2-(heading*2*np.pi/360))
    y = current_position[1]+timeinterval*(current_v/(3600*110))*np.sin(np.pi/2-(heading*2*np.pi/360))
    new_position = [x,y]
    return [new_position[0],new_position[1]]


def findIntersection(x1,y1,x2,y2,x3,y3,x4,y4):######line1:[x1,y1]-[x2,y2],line2:[x3,y3]-[x4,y4]
    '''计算潜在交点坐标'''
    px= ( (x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4) ) / ( ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4))+0.00000000000000001 ) 
    py= ( (x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4) ) / ( ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4))+0.00000000000000001 )
    px=round(px,7)
    py=round(py,7)
    '''计算交点坐标是否位于线段内'''
    if min(x1,x2)-0.000001 < px < max(x1,x2)+0.000001 \
            and min(x3,x4)-0.000001 < px < max(x3,x4)+0.000001 \
            and min(y1,y2)-0.000001 <= py <= max(y1,y2)+0.000001 \
            and min(y3,y4)-0.000001 <= py <= max(y3,y4)+0.000001:
        return [px, py]
    else: 
        return 'no intersection'
    
def judge_same_way(x1,y1,x2,y2,x3,y3,x4,y4):
    k1=(y2-y1)/(x2-x1+0.000000000001)
    k2=(y4-y3)/(x4-x3+0.000000000001)
    # if (x1-x3)**2+(y1-y3)**2<0.009:
    #     flag=1
    '''大约是0.3，判断两个线段的端点是否足够靠近的一个阈值'''
    if (x2-x4)**2+(y2-y4)**2<0.09:
        flag=1
    else:
        flag=0
    '''如果两个线段的端点足够靠近，接下来计算两个线段斜率之间的夹角'''
    if flag==1 and -15.01<np.arctan(k1-k2)*360/(2*3.14159265)<15.01:#####夹角小于10度
        return [[x1,y1],[x2,y2]]
    else:
        return 'not same way'
# #####################################test
# a=findIntersection(0,0,1,0,0.,1,1,2)
# #####################################
# b=judge_same_way(110,22,110,23,110,20,110,21)
# print(b)
# b=judge_same_way(110,22,110,23,110,22,110,23)
# print(b)
# b=judge_same_way(0,0,1,1,0,0,2,2)
# print(b)
####再写一个判断折线段和折线段交点的程序
############数据格式########################线段1:[[x1,y1],[x2,y2],[x3,y3],[x4,y4],[x5,y5]],线段:[[x1,y1],[x2,y2]]

def calculate_intersection_point(lisofpolygon,lisofline):
    points=[]
    for j in range(len(lisofline)-1):
        for i in range(len(lisofpolygon)-1):
            point = findIntersection(lisofline[j][0],lisofline[j][1],lisofline[j+1][0],lisofline[j+1][1],lisofpolygon[i][0],lisofpolygon[i][1],lisofpolygon[i+1][0],lisofpolygon[i+1][1])
            if point == -1:
                continue
            else:
                if point not in  points:
                    points.append(point)
#    print(points)
    if len(points) == 0:
        return 'nonconflicts'
    else:
        return points

def  calculate_same_way_point(linelis1,linelis2):
    same_way=[]
    for j in range(len(linelis2)-1):
        for i in range(len(linelis1)-1):
            same_way_point=judge_same_way(linelis2[j][0],linelis2[j][1],linelis2[j+1][0],linelis2[j+1][1],linelis1[i][0],linelis1[i][1],linelis1[i+1][0],linelis1[i+1][1])
            if type(same_way_point) == str:
                continue
            else:
                if same_way_point not in  same_way:
                    same_way.append(same_way_point)
    if len(same_way) == 0:
        return 'no same way'
    else:
        return same_way##################是有先后顺序的

# def judge_conflicts(aircraftSet,thisAircraft):#####aircraftSet:空域中所有的航空器####
#     ##1°约等于110km,0.9°约等于100km,0.09°约等于10km
#     ##同高度层100km内是否有飞机，若无，则无冲突，若有，进入下一步
#     ###其他飞机与本飞机有无交叉点，若无则无冲突，若有，进入下一步
#     ###
#     conflicts_dic={'same_point':[],'same_way':[]}
#     aircraftSet.remove(thisAircraft)
#     for i in aircraftSet:
#         '''同高度、特定距离判断'''
#         if i.flightlevelm == thisAircraft.flightlevelm and (i.current_position[0]-thisAircraft.current_position[0])**2+(i.current_position[1]-thisAircraft.current_position[1])**2 < 0.81:####100km
#             #####判断未来1个航迹点构成的线段是否与周围的飞机有冲突
#             a=thisAircraft.intention
#             b=i.intention
#             kk=judge_same_way(x1=thisAircraft.current_position[0],y1=thisAircraft.current_position[1],
#                               x2=a[0],y2=a[1],
#                               x3=i.current_position[0],y3=i.current_position[1],
#                               x4=b[0],y4=b[1])
#             if type(kk) == list:
#                 conflicts_dic['same_way'].append(i)
#             elif (a[0]-b[0])**2+(a[1]-b[1])**2 <0.0081:
#                 conflicts_dic['same_point'].append(i)
#             else:#没有冲突
#                 continue
#         else:#没有冲突
#             continue
#     return conflicts_dic#####返回具有存在冲突/潜在冲突的航空器

def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d
def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    '''考虑了四种不同的情况，这取决于 B 相对于 A 的位置（东、南、西、北）'''
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita




def get_aircraft_conflicts(aircraftlis_ori,my_aircraft):

    ##########第一步，把不在同高度层的航空器（有稳定的垂直间隔）和超出80km范围的航空器（有稳定的水平间隔）删掉
    aircraftlis_filter1=[]
    for craft in aircraftlis_ori:
        if distance([my_aircraft['lon'],my_aircraft['lat']],[craft['lon'],craft['lat']]) <=80:
            aircraftlis_filter1.append(craft)
    aircraftlis_filter2=[]
    for craft in aircraftlis_filter1:
        if abs(my_aircraft['alt']-craft['alt'])<=100:
            aircraftlis_filter2.append(craft)
    ##############到这里，我们获得了与自主运行航空器在80km内且同高度的航空器
    
    #########第二步，判定未来是否会存在航迹交叉，为的是删除那些背向飞行的航空器,以及那些暂时不会交叉的航空器
    my_pred_position = simple_trajectory_prediction(current_position=[my_aircraft['lon'],my_aircraft['lat']],
                                                    current_v=my_aircraft['speed'],heading=my_aircraft['heading'],timeinterval=250)
    aircraftlis_filter3={'intersection conflict':[],'tailgating conflict':[]}
    for craft in aircraftlis_filter2:

        pred_position = simple_trajectory_prediction(current_position=[craft['lon'],craft['lat']],
                                                        current_v=craft['speed'],heading=craft['heading'],timeinterval=250)
        intersection = findIntersection(craft['lon'],craft['lat'],pred_position[0],pred_position[1],
                                        my_aircraft['lon'],my_aircraft['lat'],my_pred_position[0],my_pred_position[1])######line1:[x1,y1]-[x2,y2],line2:[x3,y3]-[x4,y4]
        same_way=judge_same_way(craft['lon'],craft['lat'],pred_position[0],pred_position[1],
                                        my_aircraft['lon'],my_aircraft['lat'],my_pred_position[0],my_pred_position[1])
        # print(craft['name'])
        # print(intersection,same_way)

        '''风险等级设定： x<20  1级
                       20<x<40 2级
                        x>40  3级  '''

        conflict_distance = distance([my_aircraft['lon'], my_aircraft['lat']], [craft['lon'], craft['lat']])
        if conflict_distance <= 20:
            risk_level = "1级"
        elif conflict_distance <= 40 and conflict_distance > 20:
            risk_level = "2级"
        elif conflict_distance > 40 and conflict_distance <= 80:
            risk_level = "3级"
        else:
            risk_level = ""

        if type(intersection)!= str:
            '''存在交叉，计算风险等级 '''
            aircraft_info = {}
            aircraft_info.update(craft)
            aircraft_info["risk_level"] = risk_level
            aircraftlis_filter3['intersection conflict'].append(aircraft_info)
        if type(same_way) != str:
            '''存在追赶，计算风险等级'''
            aircraft_info = {}
            aircraft_info.update(craft)
            aircraft_info["risk_level"] = risk_level
            aircraftlis_filter3['tailgating conflict'].append(aircraft_info)
    return aircraftlis_filter3
    
######测试场景，CSN634''CCA1032'存在交叉，CSN634''CCA1033'存在追赶，剩下的为无冲突航空器

aircraftlis_ori=[{'name':'CCA1031','lon':117.5,'lat':22.5,'speed':1400,'alt':8900,'heading':get_heading([117.5,22.5],[117,23])},
              {'name':'CCA1032','lon':117.5,'lat':22.85,'speed':1400,'alt':8900,'heading':get_heading([117.5,22.5],[117,23])},
              {'name':'CCA1033','lon':118,'lat':23,'speed':1200,'alt':8900,'heading':get_heading([118,23],[117,23])},
              
              {'name':'CCA1038','lon':117.02,'lat':23.02,'speed':1200,'alt':8900,'heading':get_heading([117.02,23.02],[117,24])},
              {'name':'CCA1034','lon':118,'lat':23,'speed':1200,'alt':10100,'heading':get_heading([118,23],[117,23])},
              {'name':'CCA1035','lon':121,'lat':23,'speed':1200,'alt':8900,'heading':get_heading([121,23],[117,23])},
              {'name':'CCA1036','lon':120,'lat':23,'speed':900,'alt':8400,'heading':get_heading([120,23],[117,23])}
              ]

my_aircraft = {'name':'CSN634','lon':117.5,'lat':23,'speed':800,'alt':8900,'heading':get_heading([117.5,23],[117,23])}

aircraft_conflicts_data = get_aircraft_conflicts(aircraftlis_ori,my_aircraft)
# print(aircraft_conflicts_data)

def aircraft_conflict_data_to_word(aircraft_conflicts_data):
    namelis_intersection=[]
    risklis_intersection = []
    for aircraft in aircraft_conflicts_data['intersection conflict']:
        namelis_intersection.append(aircraft['name'])
        risklis_intersection.append(aircraft['risk_level'])
    namelis_tailgating=[]
    risklis_tailgating = []
    for aircraft in aircraft_conflicts_data['tailgating conflict']:
        namelis_tailgating.append(aircraft['name'])
        risklis_tailgating.append(aircraft['risk_level'])
    if namelis_intersection !=[] and namelis_tailgating ==[]:
        namelis1=str()
        for name, risk_level in zip(namelis_intersection, risklis_intersection):
            namelis1= ' ' + namelis1+ name + ',风险等级:' + risk_level + ' '
        aircraft_conflicts_word = '注意本机与'+namelis1+'同高度汇聚趋势'
    elif  namelis_intersection ==[] and namelis_tailgating !=[]:
        namelis2=str()
        for name, risk_level in zip(namelis_tailgating, risklis_tailgating):
            namelis2 = ' ' + namelis2 + name + ',风险等级:' + risk_level + ' '
        aircraft_conflicts_word = '注意本机与'+namelis2+'同高度追赶趋势'
    elif namelis_intersection !=[] and namelis_tailgating !=[]:
        namelis1=str()
        for name, risk_level in zip(namelis_intersection, risklis_intersection):
            namelis1 = ' ' + namelis1 + name + ',风险等级:' + risk_level + ' '
        namelis2=str()
        for name, risk_level in zip(namelis_tailgating, risklis_tailgating):
            namelis2 = ' ' + namelis2 + name + ',风险等级:' + risk_level + ' '
        aircraft_conflicts_word = '注意本机与'+namelis1+'同高度汇聚趋势'+';'+'注意本机与'+namelis2+'同高度追赶趋势'
    else:
        aircraft_conflicts_word=''
    return aircraft_conflicts_word

aircraft_conflicts_word=aircraft_conflict_data_to_word(aircraft_conflicts_data)
# print(aircraft_conflicts_word)
# '''测试代码'''
# ##########第一步，把不在同高度层的航空器（有稳定的垂直间隔）和超出8km范围的航空器（有稳定的水平间隔）删掉
# aircraftlis_filter1=[]
# for craft in aircraftlis_ori:
#     if distance([my_aircraft['lon'],my_aircraft['lat']],[craft['lon'],craft['lat']]) <=80:
#         aircraftlis_filter1.append(craft)
# aircraftlis_filter2=[]
# for craft in aircraftlis_filter1:
#     if abs(my_aircraft['alt']-craft['alt'])<=0.29:
#         aircraftlis_filter2.append(craft)
# ##############到这里，我们获得了与自主运行航空器在80km内且同高度的航空器

# #########第二步，判定未来是否会存在航迹交叉，为的是删除那些背向飞行的航空器,已经那些暂时不会交叉的航空器
# my_pred_position = simple_trajectory_prediction(current_position=[my_aircraft['lon'],my_aircraft['lat']],
#                                                 current_v=my_aircraft['speed'],heading=my_aircraft['heading'],timeinterval=250)
# aircraftlis_filter3=[]
# for craft in aircraftlis_filter2:
#     pred_position = simple_trajectory_prediction(current_position=[craft['lon'],craft['lat']],
#                                                     current_v=craft['speed'],heading=craft['heading'],timeinterval=250)
#     intersection = findIntersection(craft['lon'],craft['lat'],pred_position[0],pred_position[1],
#                                     my_aircraft['lon'],my_aircraft['lat'],my_pred_position[0],my_pred_position[1])######line1:[x1,y1]-[x2,y2],line2:[x3,y3]-[x4,y4]
#     same_way=judge_same_way(craft['lon'],craft['lat'],pred_position[0],pred_position[1],
#                                     my_aircraft['lon'],my_aircraft['lat'],my_pred_position[0],my_pred_position[1])
#     print(craft['name'])
#     print(intersection,same_way)
#     if type(intersection)!= str or type(same_way) != str:
#         aircraftlis_filter3.append(craft)






# flightplan1=[[0,0],[1,0],[2,0],[3,0],[4,0]]
# flightplan2=[[0,1],[1,0],[2,-1]]
# flightplan3=[[0,0],[1,0],[2,0],[3,1]]
# flightplan4=[[0,-1],[1,0],[2,1],[3,1]]
# flightplan5=[[0,-1],[1,0],[2,1],[3,1]]
# aircraft1=Aircraft(callsign='CSN634',flightplan=flightplan1,critical_track_points=flightplan1,current_position=[0.9,0.01],height=10113,heading=0)
# aircraft2=Aircraft(callsign='CSN635',flightplan=flightplan2,critical_track_points=flightplan2,current_position=[0.9,0.1],height=10098,heading=130)
# aircraft3=Aircraft(callsign='CSN636',flightplan=flightplan3,critical_track_points=flightplan3,current_position=[0.8,0],height=10111,heading=130)
# aircraft4=Aircraft(callsign='CSN637',flightplan=flightplan4,critical_track_points=flightplan4,current_position=[0.9,-0.1],height=10080,heading=130)
# aircraft5=Aircraft(callsign='CSN638',flightplan=flightplan5,critical_track_points=flightplan5,current_position=[0.9,-0.1],height=10700,heading=130)
# # next_two_points=get_next_track2(aircraft1.current_position,aircraft1.critical_track_points,aircraft1.current_v,aircraft1.height)
# # aircraft1.add_two_critical_position(next_two_points)
# # next_two_points=get_next_track2(aircraft2.current_position,aircraft2.critical_track_points,aircraft2.current_v,aircraft2.height)
# # aircraft2.add_two_critical_position(next_two_points)
# # next_two_points=get_next_track2(aircraft3.current_position,aircraft3.critical_track_points,aircraft3.current_v,aircraft3.height)
# # aircraft3.add_two_critical_position(next_two_points)
# # next_two_points=get_next_track2(aircraft4.current_position,aircraft4.critical_track_points,aircraft4.current_v,aircraft4.height)
# # aircraft4.add_two_critical_position(next_two_points)
# # next_two_points=get_next_track2(aircraft5.current_position,aircraft5.critical_track_points,aircraft5.current_v,aircraft5.height)
# # aircraft5.add_two_critical_position(next_two_points)
# # aircraft1.add_two_critical_position(next_two_points)
# aircraft1.flight_level_classify_m(aircraft1.height);aircraft1.get_heading()
# aircraft2.flight_level_classify_m(aircraft2.height);aircraft2.get_heading()
# aircraft3.flight_level_classify_m(aircraft3.height);aircraft3.get_heading()
# aircraft4.flight_level_classify_m(aircraft4.height);aircraft4.get_heading()
# aircraft5.flight_level_classify_m(aircraft5.height);aircraft5.get_heading()

# aircraftlis=[aircraft1,aircraft2,aircraft3,aircraft4,aircraft5]
# conflictsDic=judge_conflicts(aircraftSet=aircraftlis,thisAircraft=aircraft1)




