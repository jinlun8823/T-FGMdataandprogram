

#############flightplan_original带高度和时间戳的详细计划
flightplan_original=[[112.83528137207, 24.2983341217041,9800,0],[112,24.2], [111.294166564941, 24.5766658782959,9800,40], 
          [110.64373175634925, 25.995402602531787,9800,120],[109.6,26,9800,180], [108.72721862793, 26.0091667175293,10100,210],
          [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]
#############flightplan只有顺序水平位置的简单计划
flightplan=[[112.83528137207, 24.2983341217041], [112,24.2],[111.294166564941, 24.5766658782959], 
          [110.64373175634925, 25.995402602531787],[109.6,26], [108.72721862793, 26.0091667175293],
          [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]

callsign='CSN634'#航空器呼号
current=[112.29851073826941, 24.395277135100315]#############当前位置
height=10130;heading=80;current_v=1000


from file_avoidance_areas_process.min_circle import get_centerpoint,get_r



######最后变成最小覆盖圆的规避区列表
cloudlis=[[110.7,25,0.5],[108.5,26,0.5]]
r_are=[[110,]]



############最终周边航空器数据格式
aircraftdict=[{'name':'CCA1603','lon':112.55,'lat':26.28541217041,'speed':900,'alt':9800,'heading':170},
              {'name':'CCA1604','lon':111.241696564941,'lat':24.40658782959,'speed':0,'alt':9800,'heading':270},
              {'name':'CCA1605','lon':110.33373175634925,'lat':25.56402602531787,'speed':900,'alt':9800,'heading':170},
              {'name':'CCA1606','lon':109.520,'lat':25.853,'speed':900,'alt':9800,'heading':30},
              {'name':'CCA1607','lon':107.741,'lat':26.432,'speed':900,'alt':9800,'heading':30},
              {'name':'CCA1608','lon':109.939,'lat':26.127,'speed':900,'alt':9800,'heading':270}]



class information:
    message={'flightplan_original':flightplan_original,'flightplan':flightplan,
               'callsign':callsign,'current':current,'height':height,'heading':heading,
               'current_v':current_v,'cloudlis':cloudlis,'aircraftdict':aircraftdict}















1