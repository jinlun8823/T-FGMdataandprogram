'''
计算航迹偏离误差的程序
输入：航空器历史航迹点，新规划航迹/飞行计划
输出：执行航迹平均偏离程度（km）
'''

'''
1.读取航迹意图
2.已知两点求直线方程
3.计算当前航迹点到直线的距离
4.求平均值
'''
import numpy as np



def get_next_track_point(current_point, tracklis2):  #######到达下一个点的位置，速度、高度、时间
    tracklis = tracklis2.copy()
    cc = tracklis
    dellis = []
    for i in range(len(cc) - 1):
        if (cc[i][0] - cc[i + 1][0]) ** 2 + (cc[i][1] - cc[i + 1][1]) ** 2 <= (8 / 110) ** 2:
            dellis.append(i)
    tracklis = [n for i, n in enumerate(tracklis) if i not in dellis]
    #
    # a = b
    # print(a)
    if (current_point[0] - tracklis[-1][0]) ** 2 + (current_point[1] - tracklis[-1][1]) ** 2 <= (3 / 110) ** 2:
        # return "arrive"  ###已经到了
        return -2  ###已经到了
    
    # if (current_point[0]-tracklis[-1][0])**2+(current_point[1]-tracklis[-1][1])**2 <= (6/110)**2:
    for i in range(len(tracklis) - 1):
        if (current_point[0] - tracklis[i][0]) ** 2 + (current_point[1] - tracklis[i][1]) ** 2 <= (3 / 110) ** 2:

            # print('there1')
            # print(current_point)
            # print(tracklis[i])
            next_point = i + 1
            # print( tracklis[next_point])
            # d = distance(current_point, tracklis[next_point])

            # print('first',next_point)
            # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
            return next_point
        else:
            continue
        
    for i in range(len(tracklis) - 1):
        # print('second',i)
        if abs(tracklis[i + 1][0] - tracklis[i][0]) >= 0.03 and abs(tracklis[i + 1][1] - tracklis[i][1]) >= 0.03:
            # print('there2')
            if (
                min(tracklis[i][0], tracklis[i + 1][0]) - 0.003
                <= current_point[0]
                <= max(tracklis[i][0], tracklis[i + 1][0]) + 0.003
                and min(tracklis[i][1], tracklis[i + 1][1]) - 0.003
                <= current_point[1]
                <= max(tracklis[i][1], tracklis[i + 1][1]) + 0.003
            ):
                next_point = i + 1
                # d = distance(current_point, tracklis[next_point])

                # print('second',next_point)
                # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                return next_point

        else:
            # print('there3')
            if abs(tracklis[i + 1][0] - tracklis[i][0]) < 0.09:
                # print('there4')
                if (
                    min(tracklis[i][0], tracklis[i + 1][0]) - 0.09
                    <= current_point[0]
                    <= max(tracklis[i][0], tracklis[i + 1][0]) + 0.09
                    and min(tracklis[i][1], tracklis[i + 1][1]) - 0.003
                    <= current_point[1]
                    <= max(tracklis[i][1], tracklis[i + 1][1]) + 0.003
                ):
                    next_point = i + 1
                    # d = distance(current_point, tracklis[next_point])

                    # print('second',next_point)
                    # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                    return next_point
            elif abs(tracklis[i + 1][1] - tracklis[i][1]) < 0.09:
                # print('there5')
                if (
                    min(tracklis[i][0], tracklis[i + 1][0]) - 0.003
                    <= current_point[0]
                    <= max(tracklis[i][0], tracklis[i + 1][0]) + 0.003
                    and min(tracklis[i][1], tracklis[i + 1][1]) - 0.009
                    <= current_point[1]
                    <= max(tracklis[i][1], tracklis[i + 1][1]) + 0.009
                ):
                    next_point = i + 1
                    # d = distance(current_point, tracklis[next_point])
 
                    # print('second',next_point)
                    # return {"next_point_idx": next_point, "heading": 0, "speed": v, "height": height, "time": t}
                    return next_point
    # print('attention here')#####偶尔存在丢失航迹意图的情况，这和timestamp步长有关，也和判断到达距离有关
    # print(current_point)
    return -1  ####偏离太多的情况
##################测试程序
# c_p=[113.851058959961, 23.0928325653076, 9800]

# flightplan = [
#     [114.133331298828, 22.5433330535889, 9800],
#     [113.951667785645, 22.8963890075684, 9800],
#     [113.851058959961, 23.0928325653076, 9800],
#     [113.415802001953, 24.1916389465332, 9800],
#     [112.83528137207, 24.2983341217041, 9800],
#     [111.294166564941, 24.5766658782959, 9800],
# ]

# c = get_next_track_point(current_point=c_p, tracklis2 = flightplan)

# 根据已知两点坐标，求过这两点的直线解析方程： a*x+b*y+c = 0  (a >= 0)
def getLinearEquation(p1x, p1y, p2x, p2y):
    sign = 1
    a = p2y - p1y
    if a < 0:
        sign = -1
        a = sign * a
    b = sign * (p1x - p2x)
    c = sign * (p1y * p2x - p1x * p2y)
    return (a, b, c)
 
###########测试程序####### 
# linerpameters=getLinearEquation(114.133331298828, 22.5433330535889, 113.951667785645, 22.8963890075684)


#####计算点到直线的距离#######单位经纬度

# 导入数学库
import math

# 输入点和直线参数
point = (1, 2)  # 点的坐标 (x, y)
line = (2, -1, 3)  # 直线的参数：Ax + By + C = 0

# 计算点到直线的距离的公式
def distance_point_to_line(point, line):
    x0, y0 = point
    A, B, C = line
    # 点到直线的距离公式
    distance = abs(A * x0 + B * y0 + C) / math.sqrt(A**2 + B**2)
    return distance

# 计算点到直线的距离
distance = distance_point_to_line(point, line)

# 输出计算结果
# print("点到直线的距离为:", distance)



def cal_horizontal_mae(history_lis,planed_lis):
    totalerror=0
    for i in history_lis:
        index=get_next_track_point(i, planed_lis)
        # print(index)
        linepoint1=planed_lis[index-1];linepoint2=planed_lis[index]
        linertuple = getLinearEquation(linepoint1[0], linepoint1[1], linepoint2[0], linepoint2[1])
        disll=distance_point_to_line((i[0],i[1]), linertuple)
        # print(disll)
        dis=disll*111
        totalerror=totalerror+dis
        # print(totalerror)
        mae=totalerror/len(history_lis)
    return mae

# history_lis=[
# [111.4353332519528, 24.53933270263672, 10100],
# [111.43289192970556, 24.539978338758285, 10100],
# [111.43045060745833, 24.54062397487985, 10100],
# [111.42800928521109, 24.541269611001415, 10100],
# [111.42556796296385, 24.54191524712298, 10100],
# [111.42312664071662, 24.542560883244544, 10100],
# [111.42068531846938, 24.54320651936611, 10100],
# [111.41824399622215, 24.543852155487674, 10100],
# [111.41580267397491, 24.54449779160924, 10100],
# [111.41336135172767, 24.545143427730803, 10100],
# [111.41092002948044, 24.545789063852368, 10100],
# [111.4084787072332, 24.546434699973933, 10100],
# [111.40603738498596, 24.547080336095497, 10100]
# ]

# planed_lis=[
# [112.83528137207, 24.2983341217041, 9800],
# [112, 24.39, 9800],
# [111.294166564941, 24.5766658782959, 9800],
# [110.64373175634925, 25.995402602531787, 9800],
# [109.6, 26, 10400],
# [108.72721862793, 26.0091667175293, 10400],
# [108.39722442627, 26.0966663360596, 9800],
# [107.142776489258, 26.6330547332764, 9800]
# ]


# a=cal_horizontal_mae(history_lis,planed_lis)


##########计算



