import numpy as np
# from aircraft import Aircraft
##################################################基础函数
def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita
def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d
def get_next_position(current_point,tracklis,v):###生成4s后下一个航空器位置,v:km/h
    # print(current_point,tracklis,v)
    flag=0
    for i in range(len(tracklis) - 1):
        if (current_point[0] - tracklis[i][0]) ** 2 + (current_point[1] - tracklis[i][1]) ** 2 <= (1 / 110) ** 2:

            # print('there1')
            # print(current_point)
            # print(tracklis[i])
 
            ind = i + 1
            vx=(tracklis[ind][0]-current_point[0])/((tracklis[ind][0]-current_point[0])**2+(tracklis[ind][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
            vy=(tracklis[ind][1]-current_point[1])/((tracklis[ind][0]-current_point[0])**2+(tracklis[ind][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
            vector=[vx,vy]###单位向量
            x=current_point[0]+vx*(v/110)*4/3600
            y=current_point[1]+vy*(v/110)*4/3600
            heading=get_heading(current_point,[tracklis[ind][0],tracklis[ind][1]])##航向
            next_position=[x,y,heading,4]
            flag=1
            return next_position
        else:
            continue
    for i in range(len(tracklis)-1):
        if abs(tracklis[i+1][0]-tracklis[i][0])>=0.03 and abs(tracklis[i+1][1]-tracklis[i][1])>=0.03:
            if min(tracklis[i][0],tracklis[i+1][0])<=current_point[0]<=max(tracklis[i][0],tracklis[i+1][0]) and min(tracklis[i][1],tracklis[i+1][1])<=current_point[1]<=max(tracklis[i][1],tracklis[i+1][1]):
                flag=1
                vx=(tracklis[i+1][0]-current_point[0])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
                vy=(tracklis[i+1][1]-current_point[1])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
                vector=[vx,vy]###单位向量
                x=current_point[0]+vx*(v/110)*4/3600
                y=current_point[1]+vy*(v/110)*4/3600
                heading=get_heading(current_point,[tracklis[i+1][0],tracklis[i+1][1]])##航向
                next_position=[x,y,heading,4]
                return next_position####[经度，纬度，航向，时间间隔]
        elif abs(tracklis[i+1][0]-tracklis[i][0]) < 0.09:
            if min(tracklis[i][0],tracklis[i+1][0])-0.09 <= current_point[0] <= max(tracklis[i][0],tracklis[i+1][0])+0.09 and min(tracklis[i][1],tracklis[i+1][1])-0.003 <= current_point[1] <= max(tracklis[i][1],tracklis[i+1][1])+0.003:
                flag=1
                vx=(tracklis[i+1][0]-current_point[0])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
                vy=(tracklis[i+1][1]-current_point[1])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
                vector=[vx,vy]###单位向量
                x=current_point[0]+vx*(v/110)*4/3600
                y=current_point[1]+vy*(v/110)*4/3600
                heading=get_heading(current_point,[tracklis[i+1][0],tracklis[i+1][1]])##航向
                next_position=[x,y,heading,4]
                return next_position####[经度，纬度，航向，时间间隔]
        elif abs(tracklis[i+1][1]-tracklis[i][1]) < 0.09:
            if min(tracklis[i][0],tracklis[i+1][0])-0.001 <= current_point[0] <= max(tracklis[i][0],tracklis[i+1][0])+0.001 and min(tracklis[i][1],tracklis[i+1][1])-0.09 <= current_point[1] <= max(tracklis[i][1],tracklis[i+1][1])+0.09:
                flag=1
                vx=(tracklis[i+1][0]-current_point[0])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
                vy=(tracklis[i+1][1]-current_point[1])/((tracklis[i+1][0]-current_point[0])**2+(tracklis[i+1][1]-current_point[1])**2+0.000000000000000000000001)**(1/2)
                vector=[vx,vy]###单位向量
                x=current_point[0]+vx*(v/110)*4/3600
                y=current_point[1]+vy*(v/110)*4/3600
                heading=get_heading(current_point,[tracklis[i+1][0],tracklis[i+1][1]])##航向
                next_position=[x,y,heading,4]
                return next_position####[经度，纬度，航向，时间间隔]
        else:
            continue
    if flag==0:
        return '读取航迹意图失败'
####################################################主函数
def get_next_track9(current_point,next_point,tracklis,v,height):######未来9个关键航迹节点
    index=tracklis.index(next_point)
    next_c_point=[];t=0
    if len(tracklis)- index >= 9:
        for k in range(9):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            # print(dis)
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    else:
        for k in range(len(tracklis)-index):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point

def get_next_track4(current_point,next_point,tracklis,v,height):######未来4个关键航迹节点
    index=tracklis.index(next_point)
    next_c_point=[];t=0
    if len(tracklis)- index >= 4:
        for k in range(4):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            # print(dis)
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    else:
        for k in range(len(tracklis)-index):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    
def get_next_track2(current_point,next_point,tracklis,v,height):######未来2个关键航迹节点
    index=tracklis.index(next_point)
    next_c_point=[];t=0
    if len(tracklis)- index >= 2:
        for k in range(2):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            # print(dis)
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point
    else:
        for k in range(len(tracklis)-index):
            heading=get_heading(tracklis[index],tracklis[index+k])
            dis=distance(tracklis[index],tracklis[index+k])
            t+=3600*dis/v
            next_c_point.append({'point'+str(k+1):tracklis[index+k],'time':t,'speed':v,'height':height,'heading':heading})
        return next_c_point


def get_predicted_track(aircraft,current_point,tracklis,v,height):######未来分钟的航迹，每4s一个点
    next_eight_minutes_t_points = []
    current_point_iterate=current_point
    t=0
    for i in range(45):
        if get_next_position(current_point_iterate,tracklis,v) == '读取航迹意图失败':
            return next_eight_minutes_t_points
        else:
            t=t+4
            mid = get_next_position(current_point_iterate,tracklis,v)
            current_point_iterate=[mid[0],mid[1]]
            ky = 'point'+str(i)
            next_eight_minutes_t_points.append({ky:[mid[0],mid[1]],'time':t,'speed':v,'height':height,'heading':mid[3]})
    aircraft.add_eight_minute_predicted_position(next_eight_minutes_t_points)
    return next_eight_minutes_t_points


# ###########测试###############即将到达目的地
# tracklis=[[105.421417236328, 28.1706657409668],[105.042221069336, 28.4466667175293]]
# current_point=[105.221417236328, 28.2706657409668]
# aircraft1=Aircraft(callsign='CSN634',flightplan=tracklis.copy(),critical_track_points=tracklis.copy(),current_position=current_point,height=10130,heading=80)
# pred_track1=get_predicted_track(aircraft1,current_point,tracklis,v=800,height=9800)
# #############测试###############很久才到目的地
# tracklis=[[112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#           [110.64373175634925, 25.995402602531787], [108.72721862793, 26.0091667175293],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]

# current_point=[112.83528137207, 24.2983341217041]
# aircraft1=Aircraft(callsign='CSN634',flightplan=tracklis.copy(),critical_track_points=tracklis.copy(),current_position=current_point,height=10130,heading=80)

# pred_track2=get_predicted_track(aircraft1,current_point,tracklis,v=900,height=9800)

# current_point=[111.76174010446815, 24.492220148496553]
# pred_track3=get_predicted_track(aircraft1,current_point,tracklis,v=900,height=9800)

# current_point=[110.9357046435978, 25.13241976445622]
# pred_track4=get_predicted_track(aircraft1,current_point,tracklis,v=900,height=9800)
# # 画图
# import matplotlib.pyplot as plt
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    
# x=[];y=[]
# for i in tracklis:
#     x.append(i[0])
#     y.append(i[1])
# ax.scatter(x,y,color='blue',label='flight plan')  
# x=[];y=[]
# for i in range(len(pred_track2)):
#     x.append(pred_track2[i]['point'+str(i)][0])
#     y.append(pred_track2[i]['point'+str(i)][1])
# ax.scatter(x,y,color='green',label='predicted1')
# x=[];y=[]
# for i in tracklis:
#     x.append(i[0])
#     y.append(i[1])
# ax.scatter(x,y,color='blue')  
# x=[];y=[]
# for i in range(len(pred_track3)):
#     x.append(pred_track3[i]['point'+str(i)][0])
#     y.append(pred_track3[i]['point'+str(i)][1])
# ax.scatter(x,y,color='orange',alpha=0.5,label='predicted2')
# plt.legend()

# x=[];y=[]
# for i in range(len(pred_track4)):
#     x.append(pred_track4[i]['point'+str(i)][0])
#     y.append(pred_track4[i]['point'+str(i)][1])
# ax.scatter(x,y,color='purple',alpha=0.1,label='predicted3')
# plt.legend()








# #################################改变航迹意图
# tracklis2=[[112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
#           [110.64373175634925, 25.995402602531787], [108.72721862793, 26.8091667175293],
#           [107.142776489258, 26.6330547332764]]
# # current_point = [110.46871568218573, 26.002802254713917]
# for i in tracklis2:
#     x.append(i[0])
#     y.append(i[1])
    
# ax.scatter(x,y,color='orange',label='flight plan2')  
# pred_track5=get_predicted_track(aircraft1,current_point,tracklis2,v=1000,height=9800)
# x=[];y=[]
# for i in range(len(pred_track4)):
#     x.append(pred_track5[i]['point'+str(i)][0])
#     y.append(pred_track5[i]['point'+str(i)][1])
# ax.scatter(x,y,color='purple',alpha=0.1,label='predicted5')
# plt.legend()







