import numpy as np
from aircraft import Aircraft,get_heading,distance
from trajectoryPrediction import get_predicted_track

'''
初始化自主运行航空器信息
'''
flightplan=[[112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
          [110.64373175634925, 25.995402602531787],[109.6,26], [108.72721862793, 26.0091667175293],
          [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]
callsign='CSN634'
current=[112.29851073826941, 24.395277135100315]#############当前位置
aircraft1=Aircraft(callsign='CSN634',flightplan=flightplan.copy(),critical_track_points=flightplan.copy(),current_position=current,height=10130,heading=80,current_v=1000)

#######################################################################航空器状态转移
def get_instruction(current_point,next_point):
    instruction={'speed':1000,'flightlevel':9800,'heading':333,'timeinterval':4}###########默认值
    heading=get_heading(current_point,next_point)
    #####################################################航向调整
    instruction['heading']=heading
    #####################################################高度调整
    instruction['flightlevel']=9800
    #####################################################速度调整
    instruction['speed']=9000
    # print(instruction)
    return instruction
######################################################################################
import datetime
time_interval_seconds = 1
#############################################定时矫正

while True:
    next_start_time  = datetime.datetime.now()#记录程序开始运行时的系统时间
    print(str(next_start_time)[-8])
    if str(next_start_time)[-8] == '3':
        break
#############################################开始周期运行

i=0
while True:
    next_start_time = next_start_time + datetime.timedelta(seconds = time_interval_seconds)
    try:
        next_point = aircraft1.get_next_track_point(current_point=aircraft1.current_position,tracklis=aircraft1.critical_track_points,v=aircraft1.current_v,height=aircraft1.height)
        print(next_point)
        if next_point == 'arrive':
            break
        elif next_point=='abnormal':
            next_point=aircraft1.critical_track_points[-1]
            instruction = get_instruction(current_point=aircraft1.current_position,next_point=next_point)
        else:
            instruction = get_instruction(current_point=aircraft1.current_position,next_point=next_point['point0'])
        # print(instruction)
        aircraft1.doing_current_instruction(instruction,4*i)
        i=i+1
        ##############################航迹预测主程序
        if i >= 10:
           flightplan=[[112.83528137207, 24.2983341217041], [111.294166564941, 24.5766658782959], 
                     [110.64373175634925, 25.995402602531787],[109.6,26.6], [108.92721862793, 29.0091667175293],
                     ]
        pred_track=get_predicted_track(aircraft1,aircraft1.current_position,tracklis=flightplan,v=1000,height=9800)
        ##############################结束
        
        
        
        '''
        以下为画图测试程序
        '''
        # print('time',i)
        # import matplotlib.pyplot as plt
        # from matplotlib.ticker import MultipleLocator
        # x_major_locator=MultipleLocator(1)
        # #把x轴的刻度间隔设置为1，并存在变量里
        # y_major_locator=MultipleLocator(1)
        # #把y轴的刻度间隔设置为1，并存在变量里
        # fig=plt.figure()
        # ax=fig.add_subplot(111)
        # ax.xaxis.set_major_locator(x_major_locator)
        # #把x轴的主刻度设置为1的倍数
        # ax.yaxis.set_major_locator(y_major_locator)
        # ax.set_aspect(1)    
        # x=[];y=[]
        # for j in flightplan:
        #     x.append(j[0])
        #     y.append(j[1])
        # ax.scatter(x,y,color='blue',label='flight plan')  
        # x=[];y=[]
        # for j in range(len(pred_track)):
        #     x.append(pred_track[j]['point'+str(j)][0])
        #     y.append(pred_track[j]['point'+str(j)][1])
        # ax.scatter(x,y,color='green',label='predicted1')
    except:
        print('waiting/error')
    #############################  end_function()
    while datetime.datetime.now() - next_start_time < datetime.timedelta(seconds = 0):
        continue;













