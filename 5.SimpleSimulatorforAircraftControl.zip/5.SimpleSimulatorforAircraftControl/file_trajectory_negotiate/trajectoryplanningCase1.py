'''4D trajectory planning-----Case1'''
'''both conflicts between aircraft and avoidance areas and conflict between aircraft--------horizontal,vertical and speed adjustment'''
 
import numpy as np
# from single_cb_resolve import judge_in_cb,generate_feasible_track,generate_best_track
# from cb_aggregation import aggregate_cb
#######################single_cb_resolve
import math
import copy
####求圆外一点与圆的切点
def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d
def get_tangent_line(tx, ty, ox, oy, r):####
    # 求点T到圆心O的距离
    distance = math.sqrt((tx-ox) ** 2 + (ty-oy) ** 2)
#    print('distance', distance)
    # 点T到切点P的距离
    if distance <= r:
        print("输入的数值不在范围内")
        return 'diversion'
    length = math.sqrt(distance ** 2 - r ** 2)
#    print('length', length)
    # 点到圆心的单位向量
    cx = (ox - tx) / distance
    cy = (oy - ty) / distance
    # 计算切线与圆心连线的夹角
    angle = math.asin(r / distance)
    # print('angle', angle)
    # 向正反两个方向旋转单位向量
    q1x = cx * math.cos(angle)  -  cy * math.sin(angle)
    q1y = cx * math.sin(angle)  +  cy * math.cos(angle)
    q2x = cx * math.cos(-angle) -  cy * math.sin(-angle)
    q2y = cx * math.sin(-angle) +  cy * math.cos(-angle)
#    print(q1x,q1y,q2x,q2y)
    # 得到新座标y
    q1x = q1x * length + tx
    q1y = q1y * length + ty
    q2x = q2x * length + tx
    q2y = q2y * length + ty
    return [q1x, q1y, q2x, q2y]
####测试程序
# a=get_tangent_line(2, -2, 0, 0, 2)
######求两直线交点
def findIntersection(x1,y1,x2,y2,x3,y3,x4,y4):######line1:[x1,y1]-[x2,y2],line2:[x3,y3]-[x4,y4]
    px= ( (x1*y2-y1*x2)*(x3-x4)-(x1-x2)*(x3*y4-y3*x4) ) / ( ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4))+0.000000000001 ) 
    py= ( (x1*y2-y1*x2)*(y3-y4)-(y1-y2)*(x3*y4-y3*x4) ) / ( ((x1-x2)*(y3-y4)-(y1-y2)*(x3-x4))+0.000000000001 )
    return [px, py]
# a1=get_tangent_line(3, 0, 0, 0, 1)
# a2=get_tangent_line(-3, 0, 0, 0, 1)
# point1=findIntersection(3,0,a1[0],a1[1],-3,0,a2[0],a2[1])
# point2=findIntersection(3,0,a1[0],a1[1],-3,0,a2[2],a2[3])
# point3=findIntersection(3,0,a1[2],a1[3],-3,0,a2[0],a2[1])
# point4=findIntersection(3,0,a1[2],a1[3],-3,0,a2[2],a2[3])
def find_feasible_point(point1,point2,point3,point4,ox,oy):###ox,oy:center_of_cb，找出两种绕飞方式
    dic1={'point1':point1,'point2':point2,'point3':point3,'point4':point4}
    a=(point1[0]-ox)**2+(point1[1]-oy)**2
    b=(point2[0]-ox)**2+(point2[1]-oy)**2
    c=(point3[0]-ox)**2+(point3[1]-oy)**2
    d=(point4[0]-ox)**2+(point4[1]-oy)**2
    # print(a,b,c,d)
    dic2={a:'point1',b:'point2',c:'point3',d:'point4'}
    # print(dic)
    lis=[a,b,c,d]
    lis.sort()
    return dic1[dic2[lis[0]]],dic1[dic2[lis[1]]]
# f_p=find_feasible_point(point1,point2,point3,point4,0,0)    
def find_best_point(point1,point2,point3,point4,ox,oy):###ox,oy:center_of_cb,找出绕飞距离最短的点
    a=(point1[0]-ox)**2+(point1[1]-oy)**2
    b=(point2[0]-ox)**2+(point2[1]-oy)**2
    c=(point3[0]-ox)**2+(point3[1]-oy)**2
    d=(point4[0]-ox)**2+(point4[1]-oy)**2
    if min(a,b,c,d)==a:
        return point1
    elif min(a,b,c,d)==b:
        return point2
    elif min(a,b,c,d)==c:
        return point3
    elif min(a,b,c,d)==d:
        return point4
# b_p=find_best_point(point1,point2,point3,point4,0,0)    
def judge_in_cb(point, line_point1, line_point2,r):#####判断CB云对航空器航迹意图的影响
    #对于两点坐标为同一点时,返回点与点的距离
    if line_point1 == line_point2:
        point_array = np.array(point )
        point1_array = np.array(line_point1)
        return np.linalg.norm(point_array -point1_array )
    #计算直线的三个参数
    A = line_point2[1] - line_point1[1]
    B = line_point1[0] - line_point2[0]
    C = (line_point1[1] - line_point2[1]) * line_point1[0] + \
        (line_point2[0] - line_point1[0]) * line_point1[1]
    #根据点到直线的距离公式计算距离
    distance = np.abs(A * point[0] + B * point[1] + C) / (np.sqrt(A**2 + B**2)+0.00000000000000000001)
    Flag=0
    chuizux=(B**2*point[0]-A*B*point[1]-A*C)/(A*A+B*B+0.00000000000000000001)
    chuizuy=(A**2*point[1]-A*B*point[0]-B*C)/(A*A+B*B+0.00000000000000000001)
    if distance < r-0.0001 and (line_point1[0]-chuizux)*(line_point2[0]-chuizux)<0 and (line_point1[1]-chuizuy)*(line_point2[1]-chuizuy)<0:
        Flag=1
    if Flag==1:
        return True
    else:
        return False
# judge_in_cb([120,22], [118,18], [125,24],2)  
# a1=get_tangent_line(3, 0, 0, 0, 1)
# a2=get_tangent_line(-3, 0, 0, 0, 1)
def generate_best_track(x1,y1,x2,y2,xo,yo,r):
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==False:
        critical_track=[[x1,y1],[x2,y2]]
        return critical_track
    
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==True:
        # print('lll')
        a1=get_tangent_line(x1, y1, xo, yo, r)
        a2=get_tangent_line(x2, y2, xo, yo, r)
        if a1=='diversion' or a2=='diversion':
            return 'diversion'
        point1=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[0],a2[1])
        point2=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[2],a2[3])
        point3=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[0],a2[1])
        point4=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[2],a2[3])
        
        b_p=find_best_point(point1,point2,point3,point4,xo,yo) 
        # print('转弯点',b_p,'*需要绕飞')

        critical_track=[[x1,y1],b_p,[x2,y2]]
        return critical_track
def generate_feasible_track(x1,y1,x2,y2,xo,yo,r):
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==False:
        critical_track=[[x1,y1],[x2,y2]]
        return critical_track
    
    if judge_in_cb([xo,yo], [x1,y1], [x2,y2],r)==True:
        # print('lll')
        a1=get_tangent_line(x1, y1, xo, yo, r)
        a2=get_tangent_line(x2, y2, xo, yo, r)
        if a1=='diversion' or a2=='diversion':
            return 'diversion'
        point1=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[0],a2[1])
        point2=findIntersection(x1,y1,a1[0],a1[1],x2,y2,a2[2],a2[3])
        point3=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[0],a2[1])
        point4=findIntersection(x1,y1,a1[2],a1[3],x2,y2,a2[2],a2[3])
        
        f_p=find_feasible_point(point1,point2,point3,point4,xo,yo) 
        # print('方案1：转弯点',f_p[0],'*绕飞')
        # print('方案2：转弯点',f_p[1],'*绕飞')
        critical_track1=[[x1,y1],f_p[0],[x2,y2]]
        critical_track2=[[x1,y1],f_p[1],[x2,y2]]
        return critical_track1,critical_track2
    



################################cb_aggregation
def aggregate_cb(a,b,ra,rb):
    if min(ra,rb)<=max(ra,rb)-((b[0]-a[0])**2+(b[1]-a[1])**2)**(1/2):
        dic={ra:a,rb:b}
        center_new=dic[max(ra,rb)]
        r_new=max(ra,rb)
    else:
        vectorr1=[b[0]-a[0],b[1]-a[1]]
        absvector1=((b[0]-a[0])**2+(b[1]-a[1])**2)**(1/2)+0.0000000000000000000000001
        unit_vertor1=[vectorr1[0]/absvector1,vectorr1[1]/absvector1]
        unit_vertor2=[-vectorr1[0]/absvector1,-vectorr1[1]/absvector1]
        
        p1=[b[0]+rb*unit_vertor1[0],b[1]+rb*unit_vertor1[1]]
        p2=[a[0]+ra*unit_vertor2[0],a[1]+ra*unit_vertor2[1]]
        
        center_new=[(p1[0]+p2[0])/2,(p1[1]+p2[1])/2]
        r_new=0.5*((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)**(1/2)
    return center_new,r_new




#########################################
def generate_point(cloudlis,critical_tralis):########################生成俩个绕飞点，但不一定可用,同时根据return作为判定程序
    # print(critical_tralis)
    for clould in cloudlis:
        for i in range(len(critical_tralis)-1):
            current_leg=[critical_tralis[i],critical_tralis[i+1]]
            # print(i,current_leg)
            if judge_in_cb(clould[0:2],current_leg[0],current_leg[1],clould[-1]) == False:
                continue
            else:
                conflict_leg=current_leg
                conflict_cloud=clould
                conflict_index=i
                feasible_track=generate_feasible_track(conflict_leg[0][0],conflict_leg[0][1],conflict_leg[1][0],conflict_leg[1][1],
                                                      conflict_cloud[0],conflict_cloud[1],conflict_cloud[2])
                # print(feasible_track)
                feasible_points=[feasible_track[0][1],feasible_track[1][1]]
                best_track=generate_best_track(conflict_leg[0][0],conflict_leg[0][1],conflict_leg[1][0],conflict_leg[1][1],
                                                      conflict_cloud[0],conflict_cloud[1],conflict_cloud[2])
                best_points=best_track[1]
                return {'conflict_index':conflict_index,'feasible_points[0]':feasible_points[0],'feasible_points[1]':feasible_points[1],
                        'conflict_cloud':conflict_cloud,'best_points':best_points}##返回插值位置和绕飞转弯点
    return {'conflict_index':'noconflict','critical_tralis':critical_tralis}######直接返回无冲突计划航路

def insert_point(result,cloudlis,critical_tralis):#####插入绕飞点，若无法绕飞则合并积雨云
    # print(cloudlis)
    # print(result)
    if result['conflict_index']=='noconflict':
        return {'type':'track','critical_tralis':critical_tralis}
    else:
        cir_point1=result['feasible_points[0]']
        cir_point2=result['feasible_points[1]']
        for clould in cloudlis:
              if (cir_point1[0]-clould[0])**2+(cir_point1[1]-clould[1])**2>=clould[2]**2:
                  continue
              else:
                  result.pop('feasible_points[0]')
                  conflict_cloud2=clould
        for clould in cloudlis:
              if (cir_point2[0]-clould[0])**2+(cir_point2[1]-clould[1])**2>=clould[2]**2:
                  continue
              else:
                  result.pop('feasible_points[1]')
                  conflict_cloud3=clould
        if 'feasible_points[0]' in result.keys() and 'feasible_points[1]' in result.keys():
            b_p=result['best_points']
            critical_tralis.insert(result['conflict_index']+1,b_p)
            return {'type':'track','critical_tralis':critical_tralis}
        elif 'feasible_points[0]' in result.keys() and 'feasible_points[1]' not in result.keys():
            f_p=result['feasible_points[0]']
            critical_tralis.insert(result['conflict_index']+1,f_p)
            return {'type':'track','critical_tralis':critical_tralis}
        elif 'feasible_points[0]' not in result.keys() and 'feasible_points[1]' in result.keys():
            f_p=result['feasible_points[1]']
            critical_tralis.insert(result['conflict_index']+1,f_p)
            return {'type':'track','critical_tralis':critical_tralis}
        else:
            new_cb=aggregate_cb(conflict_cloud2[0:2],conflict_cloud3[0:2],conflict_cloud2[2],conflict_cloud3[2])
            # print(conflict_cloud2)
            # print(conflict_cloud3)
            cloudlis.remove(conflict_cloud2);
            if conflict_cloud3 in cloudlis:
                cloudlis.remove(conflict_cloud3)
            if result['conflict_cloud'] in cloudlis:
                cloudlis.remove(result['conflict_cloud'])
            cloudlis.append([new_cb[0][0],new_cb[0][1],new_cb[1]])
            return {'type':'cloudlis','cloudlis':cloudlis}
def insert_point2(result,cloudlis,critical_tralis):#####插入绕飞点，若无法绕飞则合并积雨云
    # print(cloudlis)
    if result['conflict_index']=='noconflict':
        return {'type':'track','critical_tralis':critical_tralis}
    else:
        cir_point1=result['feasible_points[0]']
        cir_point2=result['feasible_points[1]']
        for clould in cloudlis:
              if (cir_point1[0]-clould[0])**2+(cir_point1[1]-clould[1])**2>=clould[2]**2:
                  continue
              else:
                  result.pop('feasible_points[0]')
                  conflict_cloud2=clould
        for clould in cloudlis:
              if (cir_point2[0]-clould[0])**2+(cir_point2[1]-clould[1])**2>=clould[2]**2:
                  continue
              else:
                  result.pop('feasible_points[1]')
                  conflict_cloud3=clould
        if 'feasible_points[0]' in result.keys() and 'feasible_points[1]' in result.keys():
            b_p=result['best_points']
            if (b_p[0]-result['feasible_points[0]'][0])**2+(b_p[1]-result['feasible_points[0]'][1])**2<=0.000001:
                b_p=result['feasible_points[1]']
            else:
                b_p=result['feasible_points[0]']
            critical_tralis.insert(result['conflict_index']+1,b_p)
            return {'type':'track','critical_tralis':critical_tralis}
        elif 'feasible_points[0]' in result.keys() and 'feasible_points[1]' not in result.keys():
            f_p=result['feasible_points[0]']
            critical_tralis.insert(result['conflict_index']+1,f_p)
            return {'type':'track','critical_tralis':critical_tralis}
        elif 'feasible_points[0]' not in result.keys() and 'feasible_points[1]' in result.keys():
            f_p=result['feasible_points[1]']
            critical_tralis.insert(result['conflict_index']+1,f_p)
            return {'type':'track','critical_tralis':critical_tralis}
        else:
            new_cb=aggregate_cb(conflict_cloud2[0:2],conflict_cloud3[0:2],conflict_cloud2[2],conflict_cloud3[2])
            # print(conflict_cloud2)
            # print(conflict_cloud3)
            cloudlis.remove(conflict_cloud2);
            if conflict_cloud3 in cloudlis:
                cloudlis.remove(conflict_cloud3)
            if result['conflict_cloud'] in cloudlis:
                cloudlis.remove(result['conflict_cloud'])
            cloudlis.append([new_cb[0][0],new_cb[0][1],new_cb[1]])
            return {'type':'cloudlis','cloudlis':cloudlis}

def get_initial_trajectory(cloudlis,critical_tralis):
    for i in cloudlis:
        if (i[0]-critical_tralis[0][0])**2+(i[1]-critical_tralis[0][1])**2<i[2]**2 or (i[0]-critical_tralis[-1][0])**2+(i[1]-critical_tralis[-1][1])**2<i[2]**2:
            return 'diversion'
    result=generate_point(cloudlis,critical_tralis)    
    # print(result)
    ii=0;max_layer=2000
    while result['conflict_index'] !='noconflict':
        ii+=1
        if ii>=max_layer:
            return 'diversion'
        cc=insert_point(result,cloudlis,critical_tralis)
        if cc['type']=='track':
            critical_tralis=cc['critical_tralis']
        elif cc['type']=='cloudlis':
            cloudlis=cc['cloudlis']
        result=generate_point(cloudlis,critical_tralis)    
    return result['critical_tralis']



def get_initial_trajectory2(cloudlis,critical_tralis):
    for i in cloudlis:
        if (i[0]-critical_tralis[0][0])**2+(i[1]-critical_tralis[0][1])**2<i[2]**2 or (i[0]-critical_tralis[-1][0])**2+(i[1]-critical_tralis[-1][1])**2<i[2]**2:
            return 'diversion'
    result=generate_point(cloudlis,critical_tralis)    
    # print(result)
    ii=0;max_layer=2000
    while result['conflict_index'] !='noconflict':
        ii+=1
        if ii>=max_layer:
            return 'diversion'
        cc=insert_point2(result,cloudlis,critical_tralis)
        if cc['type']=='track':
            critical_tralis=cc['critical_tralis']
        elif cc['type']=='cloudlis':
            cloudlis=cc['cloudlis']
        result=generate_point(cloudlis,critical_tralis)    
    return result['critical_tralis']
'''
主函数为get_initial_trajectory
输入数据：get_initial_trajectory(cloudlis=[[lon1,lat1],[lon2,lat2],...,[lonn,latn]],critical_tralis=[from_point=[[lon1,lat1],[lon2,lat2],...,[lonn,latn]])
该函数返回关键航迹点列表，即需要转弯绕飞的点
'''
def get_c_lis1(cloudlis,critical_tralis):
    original_plan = critical_tralis
    for i in critical_tralis[1:-1]:########删除被积雨云覆盖的航迹点
        # print(i)
        for j in cloudlis:
            # print(j)
            if (i[0]-j[0])**2+(i[1]-j[1])**2<(j[2])**2+0.05:
                critical_tralis.remove(i)
                # print(i)
    i_t=get_initial_trajectory(cloudlis,critical_tralis)
    
    if i_t == 'diversion':
        return i_t
    ###########################航迹简化
    rotate_index=[]
    for i in i_t:
        if i not in original_plan:
            rotate_index.append(i_t.index(i))
        else:
            continue
    direct_to_index=[]
    for ii in range(len(rotate_index)-1):
        if rotate_index[ii+1]-rotate_index[ii]<3:
            direct_to_index.append([rotate_index[ii],rotate_index[ii+1]])
        else:
            continue
    # for i in direct_to_index:
    #     del i_t[i[0]+1:i[1]]
    # print(direct_to_index)
    for i in direct_to_index:
        point1=i_t[i[0]]
        # print(i_t[i[0]]);print(point1[0]);print(point1[1])
        flagg=0
        point1=i_t[i[0]];p1x=point1[0];p1y=point1[1]
        point2=i_t[i[1]];p2x=point2[0];p2y=point2[1]
        AA=p2y-p1y
        BB=p1x-p2x
        CC=p2x*(p1y-p2y)-p2y*(p1x-p2x)
        for j in cloudlis:
            if (AA*j[0]+BB*j[1]+CC)**2/(AA**2+BB**2)>=j[2]**2:
                continue
            flagg==1
        if flagg==1:
            del i_t[i[0]+1:i[1]]
        else:
            continue
    for k in range(len(i_t)):
        if len(i_t[k]) <3:
            try:
                i_t[k].append(i_t[k-1][2])
            except:
                i_t[k].append(i_t[k+1][2])       
    return i_t



def get_c_lis2(cloudlis,critical_tralis):
    original_plan = critical_tralis.copy()
    for i in critical_tralis[1:-1]:########删除被积雨云覆盖的航迹点
        # print(i)
        for j in cloudlis:
            # print(j)
            if (i[0]-j[0])**2+(i[1]-j[1])**2<(j[2]+0.25)**2:
                critical_tralis.remove(i)
                # print(i)
    i_t=get_initial_trajectory2(cloudlis,critical_tralis)
    
    if i_t == 'diversion':
        return i_t
    ###########################航迹简化
    rotate_index=[]
    for i in i_t:
        if i not in original_plan:
            rotate_index.append(i_t.index(i))
        else:
            continue
    direct_to_index=[]
    for ii in range(len(rotate_index)-1):
        if rotate_index[ii+1]-rotate_index[ii]<3:
            direct_to_index.append([rotate_index[ii],rotate_index[ii+1]])
        else:
            continue
    # for i in direct_to_index:
    #     del i_t[i[0]+1:i[1]]
    # print(direct_to_index)
    for i in direct_to_index:
        point1=i_t[i[0]]
        # print(i_t[i[0]]);print(point1[0]);print(point1[1])
        flagg=0
        point1=i_t[i[0]];p1x=point1[0];p1y=point1[1]
        point2=i_t[i[1]];p2x=point2[0];p2y=point2[1]
        AA=p2y-p1y
        BB=p1x-p2x
        CC=p2x*(p1y-p2y)-p2y*(p1x-p2x)
        for j in cloudlis:
            if (AA*j[0]+BB*j[1]+CC)**2/(AA**2+BB**2)>=j[2]**2:
                continue
            flagg==1
        if flagg==1:
            del i_t[i[0]+1:i[1]]
        else:
            continue
    for k in range(len(i_t)):
        if len(i_t[k]) <3:
            try:
                i_t[k].append(i_t[k-1][2])
            except:
                i_t[k].append(i_t[k+1][2])       
    return i_t
# #####验证实验#################场景一
# cloudlis=[[1,6,1],[5,5,1],[5.745,4.309,0.2],[8,1,2]]
# cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# cloudlis=[[1,6,1],[5,5,1],[4.254,5.672,0.3],[5.745,4.309,0.2],[2,2,1],[7,8,1],[4.5,7.5,0.9],[8,1,2],[8,10,1],[3,4.5,0.6]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# critical_tralis=[[0,0],[10,11]]
# i_t=get_c_lis(cloudlis,critical_tralis)
# #####作图###
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# x=[];y=[]
# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='orange')
#     ax.add_patch(circle1)
# x=[];y=[]
# for i in i_t:
#     x.append(i[0])
#     y.append(i[1])
# ax.plot(x,y,color='red')

# ######验证实验#################场景二
# # cloudlis=[[1,6,1],[5,5,1],[5.745,4.309,0.2],[8,1,2]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# cloudlis=[[1,6,1],[5,5,1],[4.254,5.672,0.3],[5.745,4.309,0.2],[2,2,1],[7,8,1],[4.5,7.5,0.9],[8,1,2],[8,10,1],[3,4.5,0.6],[8,4,0.6]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# critical_tralis=[[10,0],[0,11]]
# i_t=get_c_lis(cloudlis,critical_tralis)
# #####作图###
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# x=[];y=[]
# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='orange')
#     ax.add_patch(circle1)
# x=[];y=[]
# for i in i_t:
#     x.append(i[0])
#     y.append(i[1])
# ax.plot(x,y,color='red')

# #####验证实验#################场景三
# # cloudlis=[[1,6,1],[5,5,1],[5.745,4.309,0.2],[8,1,2]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# cloudlis=[[118,20,0.9],[117.5,22,0.6]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# critical_tralis=[[117,23],[119,18]]
# i_t=get_c_lis(cloudlis,critical_tralis)
# #####作图###
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)


# x=[];y=[]
# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='orange')
#     ax.add_patch(circle1)
# x=[];y=[]
# for i in i_t:
#     x.append(i[0])
#     y.append(i[1])
# ax.plot(x,y,color='red')


# #####验证实验#################场景四####备降场景###航空器已经无法避开危险天气
# # cloudlis=[[1,6,1],[5,5,1],[5.745,4.309,0.2],[8,1,2]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# cloudlis=[[118,20,3],[117.5,22,0.6]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# critical_tralis=[[117,23],[119,18]]
# i_t=get_initial_trajectory(cloudlis,critical_tralis)
# #####作图###
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)
# x=[];y=[]
# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='orange')
#     ax.add_patch(circle1)
# x=[];y=[]
# if str(type(i_t))!="<class 'str'>": 
#     for i in i_t:
#         x.append(i[0])
#         y.append(i[1])
# ax.plot(x,y,color='red')

# #####验证实验#################场景四####基于实际飞行计划进行航迹规划：广州--乌鲁木齐
# #cloudlis=[[1,6,1],[5,5,1],[5.745,4.309,0.2],[8,1,2]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# cloudlis=[[100,30,5],[110,25,1],[93,41,2.2],[109,42,1.2],[88,30,0.8],[89,35,0.6]]
# ## cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# x=[114.133331298828, 113.951667785645, 113.851058959961, 113.415802001953, 112.83528137207, 111.294166564941,
#     110.77564239502, 110.212219238281, 109.608329772949, 108.72721862793, 108.39722442627, 107.142776489258, 
#     106.780281066895, 106.375274658203, 106.062774658203, 105.854721069336, 105.421417236328, 105.042221069336,
#     104.753051757813, 104.555809020996, 104.304168701172, 104.391418457031, 104.378723144531, 104.366668701172,
#     104.316665649414, 104.294998168945, 104.270835876465, 104.191390991211, 104.151947021484, 104.124725341797, 
#     104.112503051758, 103.283889770508, 102.439720153809, 102.035278320313, 101.685554504395, 101.316108703613, 
#     100.918891906738, 100.011665344238, 97.6258316040039, 97.033332824707, 96.6227798461914, 95.1452789306641,
#     94.8666687011719, 93.8480529785156, 91.6941680908203, 89.3930587768555, 87.9815826416016, 88.2044448852539, 
#     88.317497253418, 88.9844436645508, 88.0850296020508, 87.466667175293];
# y=[22.5433330535889, 22.8963890075684, 23.0928325653076, 24.1916389465332, 24.2983341217041, 24.5766658782959,
#     24.6709175109863, 25.2047214508057, 25.7749996185303, 26.0091667175293, 26.0966663360596, 26.6330547332764, 
#     26.7866668701172, 27.1991672515869, 27.5147228240967, 27.731388092041, 28.1706657409668, 28.4466667175293, 
#     28.6572227478027, 28.7995834350586, 29.9294452667236, 30.8727493286133, 31.2490005493164, 31.4333324432373,
#     32.4099998474121, 32.8600006103516, 33.3572235107422, 34.9758338928223, 35.7758331298828, 36.2794456481934, 
#     36.5294456481934, 36.9369430541992, 37.3583335876465, 37.4375, 37.5047225952148, 37.6538887023926, 
#     37.8291664123535, 38.2171669006348, 39.2294425964355, 39.4669456481934, 39.6308326721191, 40.2000007629395, 
#     40.3058319091797, 40.9150009155273, 42.5183334350586, 43.5577774047852, 44.171028137207, 44.5552787780762,
#     44.7486114501953, 45.8777770996094, 47.7475814819336, 49.091667175293]
# ####作图###
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)

# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='red')
#     ax.add_patch(circle1)
# ax.plot(x,y,color='blue',label='original plan')
# critical_tralis=[]
# for p in range(len(x)):
#     critical_tralis.append([x[p],y[p]])
    
# for i in critical_tralis[1:-1]:########删除被积雨云覆盖的航迹点
#     # print(i)
#     for j in cloudlis:
#         if (i[0]-j[0])**2+(i[1]-j[1])**2<j[2]**2:
#             critical_tralis.remove(i)
#             # print(i)
# i_t=get_c_lis(cloudlis,critical_tralis)
# x=[];y=[]
# if str(type(i_t))!="<class 'str'>": 
#     for i in i_t:
#         x.append(i[0])
#         y.append(i[1])
# ax.plot(x,y,color='green',label='fly round CB')
# plt.legend()


# ####验证实验#################场景四####基于实际飞行计划进行航迹规划：广州--乌鲁木齐 依赖BAESMAP
# #cloudlis=[[1,6,1],[5,5,1],[5.745,4.309,0.2],[8,1,2]]
# # cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# cloudlis=[[103,30,5],[110,25,0.5],[109,26,0.5],[95,43,0.3],[93,41,2.2],[109,42,1.2],[115,35,1.3],[88,30,0.8],[89,35,0.6],[99.5,38.3,0.8],[101.6,37.5,0.8]]
# ## cloudlis=[[1,6,1],[5,5,1],[8,1,2]]
# x=[114.133331298828, 113.951667785645, 113.851058959961, 113.415802001953, 112.83528137207, 111.294166564941,
#     110.77564239502, 110.212219238281, 109.608329772949, 108.72721862793, 108.39722442627, 107.142776489258, 
#     106.780281066895, 106.375274658203, 106.062774658203, 105.854721069336, 105.421417236328, 105.042221069336,
#     104.753051757813, 104.555809020996, 104.304168701172, 104.391418457031, 104.378723144531, 104.366668701172,
#     104.316665649414, 104.294998168945, 104.270835876465, 104.191390991211, 104.151947021484, 104.124725341797, 
#     104.112503051758, 103.283889770508, 102.439720153809, 102.035278320313, 101.685554504395, 101.316108703613, 
#     100.918891906738, 100.011665344238, 97.6258316040039, 97.033332824707, 96.6227798461914, 95.1452789306641,
#     94.8666687011719, 93.8480529785156, 91.6941680908203, 89.3930587768555, 87.9815826416016, 88.2044448852539, 
#     88.317497253418, 88.9844436645508, 88.0850296020508, 87.466667175293];
# y=[22.5433330535889, 22.8963890075684, 23.0928325653076, 24.1916389465332, 24.2983341217041, 24.5766658782959,
#     24.6709175109863, 25.2047214508057, 25.7749996185303, 26.0091667175293, 26.0966663360596, 26.6330547332764, 
#     26.7866668701172, 27.1991672515869, 27.5147228240967, 27.731388092041, 28.1706657409668, 28.4466667175293, 
#     28.6572227478027, 28.7995834350586, 29.9294452667236, 30.8727493286133, 31.2490005493164, 31.4333324432373,
#     32.4099998474121, 32.8600006103516, 33.3572235107422, 34.9758338928223, 35.7758331298828, 36.2794456481934, 
#     36.5294456481934, 36.9369430541992, 37.3583335876465, 37.4375, 37.5047225952148, 37.6538887023926, 
#     37.8291664123535, 38.2171669006348, 39.2294425964355, 39.4669456481934, 39.6308326721191, 40.2000007629395, 
#     40.3058319091797, 40.9150009155273, 42.5183334350586, 43.5577774047852, 44.171028137207, 44.5552787780762,
#     44.7486114501953, 45.8777770996094, 47.7475814819336, 49.091667175293]
# ####作图###
# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# from matplotlib.patches import Polygon
# # fig=plt.figure()
# # ax=fig.add_subplot(111)
# fig = plt.figure(figsize=(16,8))
# ax = fig.add_axes([0.1,0.1,0.8,0.8])
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)

# # from mpl_toolkits.basemap import Basemap
# # zi = griddata(np.array(x), np.array(y), np.array(Temperature), xi, yi, interp='linear')

# # 绘图的经纬度范围，经度范围113.4-115.8,纬度范围37.3-38.9
# plt.rcParams["font.family"]='Times New Roman'######全局字体
# plt.rcParams["font.size"]=18.0##########小四
# plt.rcParams["text.color"]='black'#############图例和标题文本字体颜色（）
# plt.rcParams["mathtext.fontset"]='stix'
# # map2 = Basemap(llcrnrlon=70,llcrnrlat=16,urcrnrlon=135,urcrnrlat=55, lat_1=20, lat_2=35, lon_0=110,ax=ax)#创建一个地图，设定经纬度
# # map2.drawcoastlines()#绘制海岸线
# # map2.drawcountries(linewidth=1.5)#画上国家线
# # map2.drawlsmask()#####etopo地形图，shadedrelief浮雕,bluemarble,卫星图,drawlsmask()黑白图.warpimage()是另一种卫星图
# # for info, shape in zip(map2.comarques_info, map2.comarques):
# #     x, y = zip(*shape) 
# #     map2.plot(x, y, marker=None,color='red')
# # map2.readshapefile('gadm36_CHN_2','city',drawbounds=True)
# # map2.readshapefile('gadm36_CHN_1','city',drawbounds=True,color='black')#加载行政区划文件CHN1:省。CHN2：市，CHN3：区
# # map2.readshapefile('gadm36_TWN_1','city',drawbounds=True,color='black')
# # map2.fillcontinents(color='skyblue', lake_color='none')
# ###################################
# parallels = np.arange(0.,90,5.) 
# # map2.drawparallels(parallels,labels=[1,0,0,0],fontsize=15) # 绘制纬线
# ##################################
# meridians = np.arange(70.,140.,5.)
# # map2.drawmeridians(meridians,labels=[0,0,0,1],fontsize=15) # 绘制经线
# #################################
# # ax.axis('off')
# plt.gca().xaxis.set_major_locator(plt.NullLocator())
# plt.gca().yaxis.set_major_locator(plt.NullLocator())
# plt.subplots_adjust(top=1, bottom=0, left=0, right=1, hspace=0, wspace=0)
# plt.margins(0, 0)
# for i in cloudlis:
#     circle1=Circle(xy=i[0:2],radius=i[2],alpha=0.2,color='red')
#     ax.add_patch(circle1)
# ax.plot(x,y,color='blue',label='original plan')
# ax.scatter(x,y,color='blue')

# critical_tralis=[]
# for p in range(len(x)):
#     critical_tralis.append([x[p],y[p]])
# # original_plan = critical_tralis.copy()

#         # del i_t[i[0]+2]
#     ###########################
# i_t= get_c_lis1(cloudlis,critical_tralis)       

# # i_t2= get_c_lis2(cloudlis,critical_tralis) 
# x=[];y=[]
# if str(type(i_t))!="<class 'str'>": 
#     for i in i_t:
#         x.append(i[0])
#         y.append(i[1])
# ax.plot(x,y,color='green',label='fly round CB')
# ax.scatter(x,y,color='green')
# plt.legend(loc='upper right')

# i_t2= get_c_lis2(cloudlis,critical_tralis) 
# x=[];y=[]
# if str(type(i_t2))!="<class 'str'>": 
#     for i in i_t2:
#         x.append(i[0])
#         y.append(i[1])
# ax.plot(x,y,color='yellow',label='fly round CB2')
# ax.scatter(x,y,color='yellow')
# plt.legend(loc='upper right')

'''第二部分，判断未来n个航路点直到返回计划航线'''

# cloudlis=[[110.7,25,0.5],[108.5,26,0.5]]
# flightplan_c1=[[112.83528137207, 24.2983341217041,9800,0], [112,24.2],[111.294166564941, 24.5766658782959,9800,40], 
#           [110.64373175634925, 25.995402602531787,9800,120],[109.6,26,9800,180], [108.72721862793, 26.0091667175293,10100,210],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]
# flightplan_c2=[[112.83528137207, 24.2983341217041,9800,0],  [112,24.2],[111.294166564941, 24.5766658782959,9800,40], 
#           [110.64373175634925, 25.995402602531787,9800,120],[109.6,26,9800,180], [108.72721862793, 26.0091667175293,10100,210],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]
# flightplan=[[112.83528137207, 24.2983341217041,9800,0],  [112,24.2],[111.294166564941, 24.5766658782959,9800,40], 
#           [110.64373175634925, 25.995402602531787,9800,120],[109.6,26,9800,180], [108.72721862793, 26.0091667175293,10100,210],
#           [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]



# trajectory1 = get_c_lis1(cloudlis,flightplan_c1) 
# trajectory2 = get_c_lis2(cloudlis,flightplan_c2) 
# ###先采样
# next_point=[112,24.2]

# for j1 in range(len(trajectory1)):
#     if (trajectory1[j1][0]-next_point[0])**2+(trajectory1[j1][1]-next_point[1])**2<=0.0001:
#         index_from1 = j1
#         break

# for j2 in range(len(trajectory2)):
#     if (trajectory1[j2][0]-next_point[0])**2+(trajectory1[j2][1]-next_point[1])**2<=0.0001:
#         index_from2 = j2
#         break



# a=j1+5
# for k in flightplan:
#     # if (trajectory1[j1+1][0]-k[0])**2+(trajectory1[j1+1][1]-k[1])**2<=0.0001:
#     #     b=j1+1
#     #     # print('dasdfsa')
#     #     break
#     # else:
#     #     b=j1+5
#     if (trajectory1[j1+2][0]-k[0])**2+(trajectory1[j1+2][1]-k[1])**2<=0.0001:
#         b=j1+2
#         # print('dasdfsa')
#         break
#     else:
#         b=j1+5
# for k in flightplan:
#     if (trajectory1[j1+3][0]-k[0])**2+(trajectory1[j1+3][1]-k[1])**2<=0.0001:
#         c=j1+3
#         # print('dasdfsa')
#         break
#     else:
#         c=j1+5
# for k in flightplan:
#     if (trajectory1[j1+4][0]-k[0])**2+(trajectory1[j1+4][1]-k[1])**2<=0.0001:
#         d=j1+4 
#         break
#     else:
#         d=j1+5
# print(a,b,c,d)
# index_end1=min(a,b,c,d)

# a=j2+5
# for k in flightplan:
#     # if (trajectory2[j2+1][0]-k[0])**2+(trajectory2[j2+1][1]-k[1])**2<=0.0001:
#     #     b=j2+1
#     #     # print('dasdfsa')
#     #     break
#     # else:
#     #     b=j2+5
#     if (trajectory2[j2+2][0]-k[0])**2+(trajectory2[j2+2][1]-k[1])**2<=0.0001:
#         b=j2+2
#         # print('dasdfsa')
#         break
#     else:
#         b=j2+5
# for k in flightplan:
#     if (trajectory2[j2+3][0]-k[0])**2+(trajectory2[j2+3][1]-k[1])**2<=0.0001:
#         c=j2+3
#         # print('dasdfsa')
#         break
#     else:
#         c=j2+5
# for k in flightplan:
#     if (trajectory2[j2+4][0]-k[0])**2+(trajectory2[j2+4][1]-k[1])**2<=0.0001:
#         d=j2+4 
#         break
#     else:
#         d=j2+5
# print(a,b,c,d)
# index_end2=min(a,b,c,d)      
        
# track1_for_negoriate=trajectory1[index_from1:index_end1+1]
# track2_for_negoriate=trajectory2[index_from2:index_end2+1]









# import matplotlib.pyplot as plt
# from matplotlib.patches import Circle
# from matplotlib.ticker import MultipleLocator
# x_major_locator=MultipleLocator(1)
# #把x轴的刻度间隔设置为1，并存在变量里
# y_major_locator=MultipleLocator(1)
# #把y轴的刻度间隔设置为1，并存在变量里
# fig=plt.figure()
# ax=fig.add_subplot(111)
# ax.xaxis.set_major_locator(x_major_locator)
# #把x轴的主刻度设置为1的倍数
# ax.yaxis.set_major_locator(y_major_locator)
# ax.set_aspect(1)    

# x=[];y=[]
# for j in flightplan:
#     x.append(j[0])
#     y.append(j[1])
# ax.plot(x,y,color='blue',label='flight plan')  
# for ele in cloudlis:
#     circle1=Circle(xy=ele[0:2],radius=ele[2],alpha=0.2,color='red')
#     ax.add_patch(circle1)
# x=[];y=[]
# for j in trajectory1:
#     x.append(j[0])
#     y.append(j[1])
# ax.plot(x,y,color='green',label='planning trajectory1',linestyle='--',marker='.')  
# x=[];y=[]
# for j in trajectory2:
#     x.append(j[0])
#     y.append(j[1])
# ax.plot(x,y,color='yellow',label='planning trajectory2',linestyle='--',marker='.')  





def trajectory_planning_h_a(next_pointc,next_point2,next_point3,cloudlis,critical_tralis,flight_plan):#####critical_tralis是上一轮绕飞后的航迹，aircraft.criticaltrack
    flight_planc=flight_plan
    next_point=next_pointc;
    cloudlisc=cloudlis;
    critical_tralisc1=critical_tralis.copy()
    critical_tralisc2=critical_tralis.copy()
    # critical_tralisc3=critical_tralis.copy()
    trajectory1 = get_c_lis1(cloudlisc,critical_tralisc1) 
    # print(trajectory1)
    trajectory2 = get_c_lis2(cloudlisc, critical_tralisc2) 
    # print(trajectory1)
    # print(trajectory2)
    ###先采样
    # next_point=[112,24.2]
    
    for j1 in range(len(trajectory1)):
        if (trajectory1[j1][0]-next_point[0])**2+(trajectory1[j1][1]-next_point[1])**2<=0.0001:
            index_from1 = j1
            break
    # print(trajectory1)
    # print(trajectory2)
    flag=0
    for j2 in range(len(trajectory2)):
        if (trajectory2[j2][0]-next_point[0])**2+(trajectory2[j2][1]-next_point[1])**2<=0.0001:
            index_from2 = j2
            flag=1
            break
    # if flag==0:
    #     for j2 in range(len(trajectory2)):
    #         if (trajectory2[j2][0]-next_point2[0])**2+(trajectory2[j2][1]-next_point2[1])**2<=0.0001:
    #             index_from2 = j2
    #             break
    # if flag==0:
    #     for j2 in range(len(trajectory2)):
    #         if (trajectory2[j2][0]-next_point3[0])**2+(trajectory2[j2][1]-next_point3[1])**2<=0.0001:
    #             index_from2 = j2
    #             break

    # print(trajectory1)
    # print(trajectory2)
    # a=j1+5
    b=j1+5
    if len(trajectory1) > index_from1+2:
        for k in flight_planc:
            if (trajectory1[index_from1+2][0]-k[0])**2+(trajectory1[index_from1+2][1]-k[1])**2<=0.0001:
                b=j1+2
                # print('dasdfsa')
                break
    c=j1+5
    if len(trajectory1) > index_from1+3:
        for k in flight_planc:
            if (trajectory1[index_from1+3][0]-k[0])**2+(trajectory1[index_from1+3][1]-k[1])**2<=0.0001:
                c=j1+3
                # print('dasdfsa')
                break
    d=j1+5
    if len(trajectory1) > index_from1+4:
        for k in flight_planc:
            if (trajectory1[index_from1+4][0]-k[0])**2+(trajectory1[index_from1+4][1]-k[1])**2<=0.0001:
                d=j1+4 
                break

    # print(b,c,d)
    index_end1=min(b,c,d)
    # print(index_end1)
    if len(trajectory1) <index_from1+2:
        index_end1=len(trajectory1)
    # print(trajectory1)
    # print(trajectory2)
    track1_for_negoriate1=trajectory1[index_from1:index_end1+1]
    if flag==1:
        b=j2+5
        if len(trajectory2) > index_from2+2:
            for k in flight_planc:
                if (trajectory2[index_from2+2][0]-k[0])**2+(trajectory2[index_from2+2][1]-k[1])**2<=0.0001:
                    b=j2+2
                    # print('dasdfsa')
                    break
        c=j2+5
        if len(trajectory2) > index_from2+3:
            for k in flight_planc:
                if (trajectory2[index_from2+3][0]-k[0])**2+(trajectory2[index_from2+3][1]-k[1])**2<=0.0001:
                    c=j2+3
                    # print('dasdfsa')
                    break
        d=j2+4
        if len(trajectory2) > index_from2+4:
            for k in flight_planc:
                if (trajectory2[index_from2+4][0]-k[0])**2+(trajectory2[index_from2+4][1]-k[1])**2<=0.0001:
                    d=j2+4 
                    break
    
        
        # print(b,c,d)
        index_end2=min(b,c,d)      
        # print(index_end2)
        if len(trajectory2) <index_from2+2:
            index_end2=len(trajectory2)
        # print(trajectory1)
        # print(trajectory2)
        track2_for_negoriate2=trajectory2[index_from2:index_end2+1]
    else:
        track2_for_negoriate2={}
    # print(track1_for_negoriate1)
    track3_for_negoriate3=copy.deepcopy(track1_for_negoriate1)

    
    for kkk in range(len(track1_for_negoriate1)):
        if len(track1_for_negoriate1[kkk]) <3:
            try:
                track1_for_negoriate1[kkk].append(track1_for_negoriate1[kkk-1][2])
            except:
                track1_for_negoriate1[kkk].append(track1_for_negoriate1[kkk+1][2])            
    for kkk in range(len(track2_for_negoriate2)):
        if len(track2_for_negoriate2[kkk]) <3:
            try:
                track2_for_negoriate2[kkk].append(track2_for_negoriate2[kkk-1][2])
            except:
                track2_for_negoriate2[kkk].append(track2_for_negoriate2[kkk+1][2])  
    for kkk in range(len(track3_for_negoriate3)):
        if len(track3_for_negoriate3[kkk]) <3:
            try:
                track3_for_negoriate3[kkk].append(track3_for_negoriate3[kkk-1][2])
            except:
                track3_for_negoriate3[kkk].append(track3_for_negoriate3[kkk+1][2])  
    print('look me')
    # print('fsdefwe',track1_for_negoriate1)
    # track3_for_negoriate3=[]
    try:
        for hh in range(len(track3_for_negoriate3)):
            if track3_for_negoriate3[hh][2]>=9800:
                track3_for_negoriate3[hh][2]=track3_for_negoriate3[hh][2]-600
            else:
                track3_for_negoriate3[hh][2]=track3_for_negoriate3[hh][2]+600
    except:
        track3_for_negoriate3=[]
    print('look me2')
    # print('fsdefwe',track1_for_negoriate1)
    three_trajectories_for_negotiate={'track1_for_negoriate':track1_for_negoriate1,'track2_for_negoriate':track2_for_negoriate2,'track3_for_negoriate':track3_for_negoriate3}
    return three_trajectories_for_negotiate


# def add_flight_level(trajectorylis,aircraftinfo,my_aircraft):
#     aircraftlis_ori=aircraftinfo
#     aircraftlis_filter1=[]
#     for craft in aircraftlis_ori:
#         if distance([my_aircraft['lon'],my_aircraft['lat']],[craft['lon'],craft['lat']]) <=80:
#             aircraftlis_filter1.append(craft)
#     aircraftlis_filter2=[]
#     for craft in aircraftlis_filter1:
#         if abs(my_aircraft['alt']-craft['alt'])<=0.29:
#             aircraftlis_filter2.append(craft)
#     available_flight_level=
    
    
    
    
    
    
    


# testdata = trajectory_planning_h_a(next_pointc=[112,24.2],next_point2=[111.294166564941, 24.5766658782959,9800,40],next_point3=[110.64373175634925, 25.995402602531787,9800,120],cloudlis=cloudlis,critical_tralis=flightplan,flight_plan=flightplan)






















