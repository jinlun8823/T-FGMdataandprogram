# -*- coding: utf-8 -*-
"""
Created on Mon Apr  8 16:55:32 2024

@author: PC
"""

import numpy as np






def trajectory_planning_none():
    
    three_trajectories_for_negotiate={}
    return three_trajectories_for_negotiate
