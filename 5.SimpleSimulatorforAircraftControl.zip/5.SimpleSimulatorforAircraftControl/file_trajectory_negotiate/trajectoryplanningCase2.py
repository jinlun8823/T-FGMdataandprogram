import numpy as np
import copy

def distance(A,B):#A=[lon,lat];B=[lon,lat]，要浮点数经纬度，度分秒格式需要转换为float
    A0=(A[0]/180)*np.pi
    A1=(A[1]/180)*np.pi
    B0=(B[0]/180)*np.pi
    B1=(B[1]/180)*np.pi
    a=(np.sin((B1-A1)/2))**2
    b=np.cos(A1)*np.cos(B1)
    c=(np.sin(B0-A0)/2)**2
    e=(a+b*c)**(1/2)
    d=2*6371*np.arcsin(e)
    return d
def get_heading(A,B):#####一个把经纬度转化成航向角的小程序
    '''考虑了四种不同的情况，这取决于 B 相对于 A 的位置（东、南、西、北）'''
    if A[0] >= B[0] and A[1]>=B[1]:
        xitao=np.arcsin((A[0]-B[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+180
    if A[0] < B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[0]-A[0])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao           
    if A[0] < B[0] and A[1] >= B[1]:
        xitao=np.arcsin((A[1]-B[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+90    
    if A[0] >= B[0] and A[1] < B[1]:
        xitao=np.arcsin((B[1]-A[1])/((A[0]-B[0])**2+(A[1]-B[1])**2+0.00000000000000000000001)**(1/2))*360/(2*np.pi)
        xita=xitao+270
    return xita

def trajectory_planning_a_s(aircraftlis_ori,my_aircraft,next_point):
    trajectory_for_negotiate={}
    # next_pointc=copy.deepcopy(next_point)
    next_pointc1=copy.deepcopy(next_point)
    next_pointc2=copy.deepcopy(next_point)
    next_pointc3=copy.deepcopy(next_point)
    aircraftlis_filter1=[]
    for craft in aircraftlis_ori:
        if distance([my_aircraft['lon'],my_aircraft['lat']],[craft['lon'],craft['lat']]) <=80:
            aircraftlis_filter1.append(craft)
    aircraftlis_filter2=[]
    for craft in aircraftlis_filter1:
        if abs(my_aircraft['alt']-craft['alt'])<=150:
            aircraftlis_filter2.append(craft)
    altitude_lis =  [my_aircraft['alt']+300,my_aircraft['alt']-300,my_aircraft['alt']-600,my_aircraft['alt']+600]
    for craft in aircraftlis_ori:
        for l in altitude_lis:
            if abs(my_aircraft['alt']-l)<=30:
                altitude_lis.remove(l)
            break
    if len(altitude_lis)==0:
        return "no flight level available"
    elif len(altitude_lis)>=3:
        next_pointc1[2]=altitude_lis[0]
        next_pointc2[2]=altitude_lis[1]
        next_pointc3[2]=altitude_lis[2]
        trajectory_for_negotiate={"track1_for_negoriate":[next_pointc1],"track2_for_negoriate":[next_pointc2],"track3_for_negoriate":[next_pointc3]}#####返回一个航路点，下一个航路点变高度
    elif len(altitude_lis)==2:
        next_pointc1[2]=altitude_lis[0]
        next_pointc2[2]=altitude_lis[1]
        trajectory_for_negotiate={"track1_for_negoriate":[next_pointc1],"track2_for_negoriate":[next_pointc2],"track3_for_negoriate":[]}#####返回一个航路点，下一个航路点变高度
    else:
        next_pointc1[2]=altitude_lis[0]
        trajectory_for_negotiate={"track1_for_negoriate":[next_pointc1],"track2_for_negoriate":[],"track3_for_negoriate":[]}
    return trajectory_for_negotiate






# aircraftlis_ori=[{'name':'CCA1031','lon':117.5,'lat':22.5,'speed':1400,'alt':8900,'heading':get_heading([117.5,22.5],[117,23])},
#               {'name':'CCA1032','lon':117.5,'lat':22.85,'speed':1400,'alt':8900,'heading':get_heading([117.5,22.5],[117,23])},
#               {'name':'CCA1033','lon':118,'lat':23,'speed':1200,'alt':8900,'heading':get_heading([118,23],[117,23])},
              
#               {'name':'CCA1038','lon':117.02,'lat':23.02,'speed':1200,'alt':8900,'heading':get_heading([117.02,23.02],[117,24])},
#               {'name':'CCA1034','lon':118,'lat':23,'speed':1200,'alt':10100,'heading':get_heading([118,23],[117,23])},
#               {'name':'CCA1035','lon':121,'lat':23,'speed':1200,'alt':8900,'heading':get_heading([121,23],[117,23])},
#               {'name':'CCA1036','lon':120,'lat':23,'speed':900,'alt':8400,'heading':get_heading([120,23],[117,23])}
#               ]

# my_aircraft = {'name':'CSN634','lon':117.5,'lat':23,'speed':800,'alt':8900,'heading':get_heading([117.5,23],[117,23])}

# next_point=[1,2,3]
# ##########test##################
# cc=trajectory_planning_a_s(aircraftlis_ori,my_aircraft,next_point)





