import keyboard
import time
from class_aircraft import Aircraft
import numpy as np
from matplotlib.patches import Circle
from rich.console import Console
from rich.panel import Panel
import copy
console = Console()
#############已写完模块
from class_aircraft import Aircraft, get_heading, distance
from file_horizontal_trajectory_planning.multi_cb_conflicts_resolve import get_c_lis
from file_trajectory_prediction.trajectoryPrediction import get_predicted_track
from file_get_instruction.get_instruction import get_instruction, get_instruction_word
from file_aircraft_conflict.judge_aircraft_conflict import get_aircraft_conflicts, aircraft_conflict_data_to_word
from file_trajectory_negotiate.trajectoryplanningCase1 import trajectory_planning_h_a, get_c_lis1, get_c_lis2
from file_trajectory_negotiate.trajectoryplanningCase2 import trajectory_planning_a_s  ######
from file_trajectory_negotiate.trajectoryplanningCase3 import trajectory_planning_none
from file_area_conflicts.conflict_areas import areas_conflict_detect
from icon import CustomMarker1
import threading
import datetime

# heading=0;speed=0;altitude=0;longitude=0;latitude=0##########初始化航空器速度高度经纬度

############flightplan_original带高度和时间戳的详细计划
flightplan_original=[[112.83528137207, 24.2983341217041,9800,0],[112,24.39], [111.294166564941, 24.5766658782959,9800,40],
          [110.64373175634925, 25.995402602531787,9800,120],[109.6,26,9800,180], [108.72721862793, 26.0091667175293,10100,210],
          [108.39722442627, 26.0966663360596],[107.142776489258, 26.6330547332764]]
#############flightplan只有顺序水平位置的简单计划
flightplan=[[112.83528137207, 24.2983341217041,9800], [112,24.39,9800],[111.294166564941, 24.5766658782959,9800],
          [110.64373175634925, 25.995402602531787,9800],[109.6,26,10400], [108.72721862793, 26.0091667175293,10400],
          [108.39722442627, 26.0966663360596,9800],[107.142776489258, 26.6330547332764,9800]]
callsign='CSN634'#航空器呼号

A=[112,24.39]
B=[111.294166564941, 24.5766658782959,9800]
current=[A[0]+0.8*(B[0]-A[0]),A[1]+0.8*(B[1]-A[1]),B[2],90]#r############当前位置current=[longitude,latitude,altitude]
height=10100;
heading=get_heading(A,B);
current_v=1000
'''生成自主运行航空器对象'''
aircraft1=Aircraft(callsign='CSN634',flightplan=flightplan.copy(),critical_track_points=flightplan.copy(),current_position=current,height=height,heading=heading,current_v=current_v)


# 添加热键
keyboard.add_hotkey('up', lambda: print('up被按下了'))
keyboard.add_hotkey('down', lambda: print('down被按下了'))
keyboard.add_hotkey('left', lambda: print('left被按下了'))
keyboard.add_hotkey('right', lambda: print('right被按下了'))
keyboard.add_hotkey('l', lambda: print('强力左转被按下了'))
keyboard.add_hotkey('r', lambda: print('强力右转被按下了'))
keyboard.add_hotkey('q', lambda: print('q被按下了'))
keyboard.add_hotkey('a', lambda: print('a被按下了'))
keyboard.add_hotkey('esc', lambda: print('退出运行'))##############按两下esc退出
# 或者这样
# def on_left():
#     print('left被按下了')
# keyboard.add_hotkey('left', on_left)
# if min(abs(heading-self.heading),360-abs(heading-self.heading))<90:
#     self.heading=heading
# else:
#     temh1=self.heading+45
#     if temh1>=360:
#         temh1=temh1-360
#     temh2=self.heading-45
#     if temh2<=0:
#         temh1=temh1+360
#     if  min(abs(heading-temh2),360-abs(heading-temh2))< min(abs(heading-temh1),360-abs(heading-temh1)):
#         self.heading=temh2
#     else:
#         self.heading=temh1
flag=True
def worker1():####创建并行线程
    while flag:
        next_start_time = datetime.datetime.now()
        next_start_time = next_start_time + datetime.timedelta(seconds=1)
        aircraft1.current_position[0] = aircraft1.current_position[0]+1*(aircraft1.current_v/(3600*110))*np.cos(np.pi/2-(aircraft1.heading*2*np.pi/360))
        aircraft1.current_position[1] = aircraft1.current_position[1]+1*(aircraft1.current_v/(3600*110))*np.sin(np.pi/2-(aircraft1.heading*2*np.pi/360))
        print('开始实时状态转移线程')
        print(aircraft1.current_position,aircraft1.height,aircraft1.heading,aircraft1.current_v)
        # print(f"线程 开始工作")
        aircraft1.tracklis.append([aircraft1.current_position[0],aircraft1.current_position[1],aircraft1.height])
        time.sleep(1)

def worker2():####创建并行线
    while flag:
        import matplotlib.pyplot as plt
        from matplotlib.ticker import MultipleLocator
        next_start_time = datetime.datetime.now()
        next_start_time = next_start_time + datetime.timedelta(seconds=1)
        plt.rcParams["font.sans-serif"] = ["SimHei"]
        plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号
        
        x_major_locator = MultipleLocator(0.1)
        # 把x轴的刻度间隔设置为1，并存在变量里
        y_major_locator = MultipleLocator(0.1)
        # 把y轴的刻度间隔设置为1，并存在变量里
        fig = plt.figure()
        ax = fig.add_subplot(111)
        ax.xaxis.set_major_locator(x_major_locator)
        # 把x轴的主刻度设置为1的倍数
        ax.yaxis.set_major_locator(y_major_locator)
        ax.set_aspect(1)
        x = []
        y = []
    
        # 更改：改航后飞行计划点
        new_flightpath_x = []
        new_flightpath_y = []
        for j in aircraft1.flightplan:
            new_flightpath_x.append(j[0])
            new_flightpath_y.append(j[1])
        
        # ax.scatter(new_flightpath_x, new_flightpath_y, color='royalblue', label='flight plan')
        ax.plot(new_flightpath_x, new_flightpath_y, color="royalblue", marker="o", linewidth=1, label="new flight plan")
        ax.scatter(
        aircraft1.current_position[0], aircraft1.current_position[1], marker=CustomMarker1("icon", aircraft1.heading), c="blue", s=199
        )
        plt.xlim(aircraft1.current_position[0]-0.1,aircraft1.current_position[0]+0.1)
        plt.ylim(aircraft1.current_position[1]-0.1,aircraft1.current_position[1]+0.1)
        plt.title('高度'+str(aircraft1.height)+'\n'+'速度'+str(aircraft1.current_v)+'航向'+str(aircraft1.heading))
        x = []
        y = []
        for i in aircraft1.tracklis:
            x.append(i[0])
            y.append(i[1])
        plt.scatter(x,y,s=5,color='lime')
        plt.show()
        time.sleep(1)
def worker3():
    from data_input_processing import information
    
    while flag:
        message_input = information.message
        cloudlis = message_input["cloudlis"]
        aircraftdict = message_input["aircraftdict"]
        # try:
        """2.2  宏观水平航迹规划（确定航迹意图，水平航迹规划）--------周锦伦"""
        
        i_t = get_c_lis(cloudlis, flightplan)
        # print('i_t',i_t)########导致bug的问题:插入的绕飞航迹点没有高度，已修改
        aircraft1.add_critical_track_points(i_t)
        # print('aircraft1.critical_track_points:',aircraft1.critical_track_points)########到这边没问题
        """输出航空器的下一个目标航路点"""
        next_point_idx = aircraft1.get_next_track_point(
            current_point=aircraft1.current_position,
            tracklis2=aircraft1.critical_track_points,
            v=aircraft1.current_v,
            height=aircraft1.height,
        )
    
        next_point = aircraft1.critical_track_points[next_point_idx]
        
        """2.3  自主运行短时航迹预测-------沈雪"""
        pred_track = get_predicted_track(aircraft1, aircraft1.current_position, tracklis=flightplan, v=1000, height=9800)
        console.print("预测航迹生成成功", style="green")
        # print(pred_track)
        ##############################结束
        """2.4  自主运行三区侵入风险感知-------唐思嘉"""
        # function
        # return_data = {冲突的类型，冲突的限制区、规避区信息，提前时间}
        # return_word = {屏幕输出文本:注意前方规避区....}
        area_conflict_detect = areas_conflict_detect(
            cblis=cloudlis, current_position=aircraft1.current_position, heading=aircraft1.heading
        )
        aircraft1.add_risks_area(
            {"sanqu_conflict_data": area_conflict_detect, "sanqu_conflict_word": area_conflict_detect["word"]}
        )
        if area_conflict_detect["risklevel"] != 0:
            area_risk_print_word = area_conflict_detect["word"] + "等级" + str(area_conflict_detect["risklevel"])
        else:
            area_risk_print_word = ""
        console.print("气象规避区冲突：" + area_risk_print_word, style="red")
        """2.5  自主运行航空器冲突风险-------张世佳"""
        mycraftdict = {
            "name": aircraft1.callsign,
            "lon": aircraft1.current_position[0],
            "lat": aircraft1.current_position[1],
            "speed": aircraft1.current_v,
            "alt": aircraft1.height,
            "heading": aircraft1.heading,
        }
        # function
        # return_data = {冲突航空器列表}   例如：{’CSN6147:'intersecting','CCA4154':'tailgating'}
        # return_word = {屏幕输出文本:注意与....的同高度交叉/追赶}
        aircraft_conflicts_data = get_aircraft_conflicts(aircraftdict, mycraftdict)
        # print(aircraft_conflicts_data)
        aircraft_conflicts_word = aircraft_conflict_data_to_word(aircraft_conflicts_data)
        console.print("航空器间冲突探测:" + aircraft_conflicts_word, style="red")
        # print('航空器间冲突探测'+aircraft_conflicts_word)
        aircraft1.add_risks_aircraft(
            {"aircraft_conflict_data": aircraft_conflicts_data, "aircraft_conflict_word": aircraft_conflicts_word}
        )
        """2.6  无冲突四维航迹协商规划-------周锦伦，外协"""
        """2.6.1  无冲突四维航迹协商规划-------周锦伦"""
        # 情况1：既要进行气象规避区冲突解脱，又要进行航空器间的冲突解脱
        track1_for_negoriate = []
        track2_for_negoriate = []
        ''''
        先判断航空器间的冲突，进行高度协商规划，再判断规避区冲突，进行水平航迹协商规划
        
        '''
    
        # 情况2：只要进行航空器间的冲突解脱
        
        # 情况3：无冲突，按计划飞行,返回空字典
        # print(next_point[2])
        """2.7  飞行航迹引导指令获取--------宁常远"""
        instruction = get_instruction(current_point=aircraft1.current_position, next_point=next_point)
        print(instruction)
        next_next_point = (
            None
            if next_point_idx == -1 or next_point_idx >= len(aircraft1.critical_track_points) - 1
            else aircraft1.critical_track_points[next_point_idx + 1]
        )
        instruction_word = get_instruction_word(
            aircraft1.heading, aircraft1.height, instruction, next_point, next_next_point
        )
        # print("instruction: ", instruction_word)
        # console.print("引导指令"+ instruction_word, style="green")
        panel = Panel.fit(instruction_word, title="Instructions")
        console.print(panel, style="green")
        aircraft1.add_instruction_word(instruction_word)
        time.sleep(4)


        

thread1 = threading.Thread(target=worker1)
thread1.start()
thread2 = threading.Thread(target=worker2)
thread2.start()
thread3 = threading.Thread(target=worker3)
thread3.start()
# for thread in [thread1,thread2]:
#     thread.join()

class my_event():
    def __init__(self,name):
        self.name=name
    
last_event=my_event(name='')
last_time=datetime.datetime.now()
flagg1= False
while True:
    # 等待下一个事件。
    event = keyboard.read_event()
    # last_time=datetime.datetime.now()
    print(event.event_type)
    print(event.name)
    if event.event_type == keyboard.KEY_DOWN and event.name == 'l':
        aircraft1.heading=aircraft1.heading-9
        if aircraft1.heading<=0:
            aircraft1.heading=aircraft1.heading+360
        print(aircraft1.heading)
        print('正在左转弯（强力转舵）')
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'left':
        aircraft1.heading-=3
        if aircraft1.heading>=360:
            aircraft1.heading=aircraft1.heading-360
        print(aircraft1.heading)
        print('正在左转弯')
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'r':
        aircraft1.heading=aircraft1.heading+9
        if aircraft1.heading<=0:
            aircraft1.heading=aircraft1.heading+360
        print(aircraft1.heading)
        print('正在右转弯（强力转舵）')
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'right':
        aircraft1.heading+=3
        if aircraft1.heading<=0:
            aircraft1.heading=aircraft1.heading+360
        print(aircraft1.heading)
        print('正在右转弯')
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'up':
        aircraft1.height+=3.5####
        # print(event.name)
        # print(last_event.name)
        if event.name == last_event.name and datetime.datetime.now() - last_time < datetime.timedelta(seconds=1.5):
            flagg1 = True
            aircraft1.height+=4.5
            # if datetime.datetime.now() - last_time > datetime.timedelta(seconds=1.5):
            # #     aircraft1.height+=1.5
            #     flagg1= True
            # flagg2 = True
        # print(aircraft1.height)
            
            # time.sleep(1)
            # aircraft1.height+=1
            # time.sleep(1)
        print('正在爬升')
        time.sleep(1)
        # aircraft1.height+=1.5
        # time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'down':
        aircraft1.height-=5
        if event.name == last_event.name and datetime.datetime.now() - last_time < datetime.timedelta(seconds=1.5):
            flagg1 = True
            aircraft1.height-=5
            # if datetime.datetime.now() - last_
        print(aircraft1.height)
        print('正在下降') 
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'q':
        aircraft1.current_v+=101
        print(aircraft1.current_v)
        print('正在加速')
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'a':
        aircraft1.current_v-=10
        print(aircraft1.current_v)
        print('正在减速')
        time.sleep(1)
    elif event.event_type == keyboard.KEY_DOWN and event.name == 'esc':
        flag=False
        print('exit process')
        keyboard.wait('esc')
        break#
    # if flagg1 == True and datetime.datetime.now() - last_time > datetime.timedelta(seconds=2):
    #     print(datetime.datetime.now())
    #     print(last_time)
    #     aircraft1.height+=1.5
    # flagg1= False
    last_event = event
    last_time=datetime.datetime.now()
    '''航空器运行控制实时显示模块'''
    # import matplotlib.pyplot as plt
    # from matplotlib.ticker import MultipleLocator
    # next_start_time = datetime.datetime.now()
    # next_start_time = next_start_time + datetime.timedelta(seconds=1)
    # plt.rcParams["font.sans-serif"] = ["SimHei"]
    # plt.rcParams["axes.unicode_minus"] = False  # 用来正常显示负号
    
    # x_major_locator = MultipleLocator(0.1)
    # # 把x轴的刻度间隔设置为1，并存在变量里
    # y_major_locator = MultipleLocator(0.1)
    # # 把y轴的刻度间隔设置为1，并存在变量里
    # fig = plt.figure()
    # ax = fig.add_subplot(111)
    # ax.xaxis.set_major_locator(x_major_locator)
    # # 把x轴的主刻度设置为1的倍数
    # ax.yaxis.set_major_locator(y_major_locator)
    # ax.set_aspect(1)
    # x = []
    # y = []

    # # 更改：改航后飞行计划点
    # new_flightpath_x = []
    # new_flightpath_y = []
    # for j in aircraft1.flightplan:
    #     new_flightpath_x.append(j[0])
    #     new_flightpath_y.append(j[1])
    # # ax.scatter(new_flightpath_x, new_flightpath_y, color='royalblue', label='flight plan')
    # ax.plot(new_flightpath_x, new_flightpath_y, color="royalblue", marker="o", linewidth=1, label="new flight plan")
    # ax.scatter(
    # aircraft1.current_position[0], aircraft1.current_position[1], marker=CustomMarker1("icon", aircraft1.heading), c="blue", s=199
    # )
    # plt.xlim(aircraft1.current_position[0]-0.1,aircraft1.current_position[0]+0.1)
    # plt.ylim(aircraft1.current_position[1]-0.1,aircraft1.current_position[1]+0.1)
    # plt.show()
    # time.sleep(1)
    # aircraft1.current_position[0] = aircraft1.current_position[0]+1*(aircraft1.current_v/(3600*110))*np.cos(np.pi/2-(aircraft1.heading*2*np.pi/360))
    # aircraft1.current_position[1] = aircraft1.current_position[1]+1*(aircraft1.current_v/(3600*110))*np.sin(np.pi/2-(aircraft1.heading*2*np.pi/360))
    # print(aircraft1.current_position,aircraft1.height,aircraft1.heading,aircraft1.current_v)
    # self.current_position = [x,y]
#########水平方向误差

from cal_horizontal_mae import cal_horizontal_mae

mae=  cal_horizontal_mae(aircraft1.tracklis,flightplan)

#########垂直方向误差
'''
1.平滑
2.算误差
3.算平均
'''