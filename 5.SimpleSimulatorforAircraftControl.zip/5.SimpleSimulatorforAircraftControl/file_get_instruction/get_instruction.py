import numpy as np
from enum import Enum


def get_heading(A, B):  #####一个把经纬度转化成航向角的小程序
    if A[0] >= B[0] and A[1] >= B[1]:
        xitao = (
            np.arcsin((A[0] - B[0]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 0.00000000000000000000001) ** (1 / 2))
            * 360
            / (2 * np.pi)
        )
        xita = xitao + 180
    if A[0] < B[0] and A[1] < B[1]:
        xitao = (
            np.arcsin((B[0] - A[0]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 0.00000000000000000000001) ** (1 / 2))
            * 360
            / (2 * np.pi)
        )
        xita = xitao
    if A[0] < B[0] and A[1] >= B[1]:
        xitao = (
            np.arcsin((A[1] - B[1]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 0.00000000000000000000001) ** (1 / 2))
            * 360
            / (2 * np.pi)
        )
        xita = xitao + 90
    if A[0] >= B[0] and A[1] < B[1]:
        xitao = (
            np.arcsin((B[1] - A[1]) / ((A[0] - B[0]) ** 2 + (A[1] - B[1]) ** 2 + 0.00000000000000000000001) ** (1 / 2))
            * 360
            / (2 * np.pi)
        )
        xita = xitao + 270
    return xita


#######################################################################可信引导指令
def get_instruction(current_point, next_point):
    instruction = {"speed": 1000, "flightlevel": 9800, "heading": 333, "timeinterval": 4}  ###########默认值
    heading = get_heading(current_point, next_point)
    #####################################################航向调整
    instruction["heading"] = heading
    #####################################################高度调整
    instruction["flightlevel"] = 9800 if len(next_point) < 3 else next_point[2]
    #####################################################速度调整
    instruction["speed"] = 1000
    # print(instruction)
    return instruction


class TurnType(Enum):
    NO_TURN = "no turn"
    LEFT = "left"
    RIGHT = "right"


def get_turn_action(current, target) -> TurnType:
    diff = target - current
    if diff > 180:
        diff -= 360
    elif diff < -180:
        diff == 360

    if abs(diff) < 5:
        return TurnType.NO_TURN
    return TurnType.LEFT if diff < 0 else TurnType.RIGHT


def get_instruction_word(cur_heading, cur_height, next_inst, point_a, point_b):
    if abs(cur_heading - next_inst["heading"]) >= 10:
        return "TOO FAR"
    res = "Fly straight to ({:.4f},{:.4f})".format(float(point_a[0]), float(point_a[1]))
    if len(point_a) >= 3 and cur_height != point_a[2]:
        res += ". Change height to {}".format(point_a[2])
    if not point_b:
        return res
    tar = get_heading(point_a, point_b)
    action = get_turn_action(cur_heading, tar)
    if action == TurnType.NO_TURN:
        action_word = "Maintain heading"
    else:
        action_word = "Turn {} to {:d}°".format(action.value, int(tar))
    res += "\n" + action_word + " passed ({:.4f},{:.4f})".format(float(point_a[0]), float(point_a[1]))
    return res
