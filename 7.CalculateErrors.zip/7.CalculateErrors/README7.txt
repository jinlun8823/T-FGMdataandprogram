Description of file "7.CalculateErrors":

This is a program used to calculate trajectory execution error.







文件"7.CalculateErrors"中文说明：

这是用于计算航迹执行误差的程序。