import torch
from transformers import BertTokenizer, BertModel
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler
from tqdm import tqdm
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.svm import SVC


tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
model = BertModel.from_pretrained('bert-base-uncased')


def read_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
    return lines


def clean_text(line):
    line = line.strip()
    line = line.replace("[CLS]", "").replace("[SEP]", "").replace("[REQ]", "").replace("[ACTION]", "").replace("[STA]", "").replace("[OBJ]", "").strip()
    return line


def tokenize_text(text):
    encoded_dict = tokenizer.encode_plus(
                        text,                      # 输入的文本
                        add_special_tokens=True,    # 添加[CLS]和[SEP]标签
                        max_length=128,            # 句子的最大长度
                        padding='max_length',      # 填充至最大长度
                        truncation=True,           # 截断超出最大长度的部分
                        return_attention_mask=True, # 返回attention mask
                        return_tensors='pt',       # 返回PyTorch张量
                   )
    return encoded_dict


def process_lines(lines):
    input_ids = []
    attention_masks = []

    for line in tqdm(lines):
        cleaned_text = clean_text(line)
        encoded_dict = tokenize_text(cleaned_text)
        
        input_ids.append(encoded_dict['input_ids'])
        attention_masks.append(encoded_dict['attention_mask'])
    
    input_ids = torch.cat(input_ids, dim=0)
    attention_masks = torch.cat(attention_masks, dim=0)

    return input_ids, attention_masks


def get_bert_embeddings(input_ids, attention_masks):
    with torch.no_grad():
        outputs = model(input_ids, attention_mask=attention_masks)
        last_hidden_states = outputs.last_hidden_state  # 获取最后一层的隐藏状态
    return last_hidden_states


def average_pooling(last_hidden_states):
    sentence_embeddings = last_hidden_states.mean(dim=1)  # 对每个句子做平均池化
    return sentence_embeddings


def visualize_embeddings(embeddings, title="Visualization of BERT embeddings"):
    scaler = StandardScaler()
    scaled_embeddings = scaler.fit_transform(embeddings.numpy())

    
    pca = PCA(n_components=2)
    pca_result = pca.fit_transform(scaled_embeddings)

    
    plt.figure(figsize=(10, 8))
    plt.scatter(pca_result[:, 0], pca_result[:, 1], alpha=0.5)
    plt.title(title)

    plt.show()

def save_embeddings_to_file(embeddings, file_name="embeddings.npy"):
    np.save(file_name, embeddings.numpy())

def load_embeddings_from_file(file_name="embeddings.npy"):
    return np.load(file_name)


def save_embeddings_as_dataframe(embeddings, file_name="embeddings.csv"):
    df = pd.DataFrame(embeddings.numpy())
    df.to_csv(file_name, index=False)


def get_original_text(input_ids):
    texts = []
    for ids in input_ids:
        tokens = tokenizer.convert_ids_to_tokens(ids.tolist())
        texts.append(tokenizer.convert_tokens_to_string(tokens))
    return texts


def prepare_data(input_ids, attention_masks, labels, test_size=0.2):
    X_train, X_test, y_train, y_test = train_test_split(input_ids, labels, test_size=test_size, random_state=42)
    return X_train, X_test, y_train, y_test


def train_svm(X_train, y_train):
    model = SVC(kernel='linear')
    model.fit(X_train, y_train)
    return model


def evaluate_svm(model, X_test, y_test):
    y_pred = model.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    print(f"Accuracy: {accuracy * 100:.2f}%")

# 16. 使用示例：读取文件，处理文本并获取词向量
def process_and_get_embeddings(file_path):

    lines = read_file(file_path)
    input_ids, attention_masks = process_lines(lines)
    
   
    last_hidden_states = get_bert_embeddings(input_ids, attention_masks)
    
    
    sentence_embeddings = average_pooling(last_hidden_states)
    
   
    save_embeddings_to_file(sentence_embeddings, "sentence_embeddings.npy")
    save_embeddings_as_dataframe(sentence_embeddings, "sentence_embeddings.csv")
    
    # 可视化降维后的词向量
    visualize_embeddings(sentence_embeddings, "Visualization of Sentence Embeddings")
    
    return sentence_embeddings




file_path = 'processed_file_with_labels.txt'


sentence_embeddings = process_and_get_embeddings(file_path)


labels = np.random.randint(0, 2, size=(sentence_embeddings.shape[0],)) 


X_train, X_test, y_train, y_test = prepare_data(sentence_embeddings, None, labels)


svm_model = train_svm(X_train, y_train)


evaluate_svm(svm_model, X_test, y_test)


print(f"词向量的形状为: {sentence_embeddings.shape}")

