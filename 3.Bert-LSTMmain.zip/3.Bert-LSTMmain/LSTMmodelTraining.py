import torch
import torch.nn as nn
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from torch.utils.data import Dataset, DataLoader
from sklearn.model_selection import train_test_split
from transformers import BertTokenizer
from torch.optim import Adam
from sklearn.metrics import accuracy_score
import random


npy_file_path = 'sentence_embeddings.npy'
csv_file_path = 'sentence_embeddings.csv'


sentence_embeddings = np.load(npy_file_path)


df = pd.read_csv(csv_file_path)

# 数据预处理：构建生成模型的输入数据
def generate_synthetic_structure(df):
    samples = []
    for _, row in df.iterrows():
        req = "[REQ] turn left"
        obj = "[OBJ] aircraft"
        action = "[ACTION] heading"
        sta = "[STA] _"  # 数值部分为空缺
        sample = f"{req} {obj} {action} {sta}"
        samples.append(sample)
    return samples

# 生成训练数据样本
training_data = generate_synthetic_structure(df)


class CommandDataset(Dataset):
    def __init__(self, data, tokenizer, max_length=20):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        text = self.data[idx]
        encoding = self.tokenizer(
            text,
            padding="max_length",
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )
        return encoding.input_ids.squeeze(0), encoding.attention_mask.squeeze(0)

#定义LSTM生成模型
class LSTMGenerationModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, num_layers, dropout=0.5):
        super(LSTMGenerationModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, num_layers, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, _ = self.lstm(embedded)
        output = self.fc(lstm_out)
        return output

#训练集与验证集划分
tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
train_data, val_data = train_test_split(training_data, test_size=0.1, random_state=42)

train_dataset = CommandDataset(train_data, tokenizer)
val_dataset = CommandDataset(val_data, tokenizer)

train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)

#定义训练参数
vocab_size = len(tokenizer)
embedding_dim = 128
hidden_dim = 256
num_layers = 2
epochs = 20  # 增加训练次数
lr = 0.001
dropout = 0.5

#搭建LSTM模型
model = LSTMGenerationModel(vocab_size, embedding_dim, hidden_dim, num_layers, dropout)
criterion = nn.CrossEntropyLoss(ignore_index=tokenizer.pad_token_id)
optimizer = Adam(model.parameters(), lr=lr)

#模型训练
def train_model():
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch_idx, (input_ids, attention_mask) in enumerate(train_loader):
            optimizer.zero_grad()
            outputs = model(input_ids)
            loss = criterion(outputs.view(-1, vocab_size), input_ids.view(-1))
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

            if batch_idx % 100 == 0:  # 每100个batch打印一次
                print(f"Epoch [{epoch+1}/{epochs}], Batch [{batch_idx}], Loss: {loss.item():.4f}")

        avg_loss = total_loss / len(train_loader)
        print(f"Epoch [{epoch+1}/{epochs}] complete. Average Loss: {avg_loss:.4f}")

#生成指令函数
def generate_instruction(model, tokenizer, prompt, max_length=20, temperature=1.0):

    model.eval()
    inputs = tokenizer(prompt, return_tensors='pt', padding=True, truncation=True)
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']

    with torch.no_grad():
        outputs = model(input_ids)
    
    # 使用温度采样来生成
    logits = outputs.squeeze(0)
    logits = logits / temperature  # 调整logits的温度
    
    predicted_ids = torch.argmax(logits, dim=-1)  # 选择最大概率的词
    generated_text = tokenizer.decode(predicted_ids.tolist(), skip_special_tokens=True)
    return generated_text

#训练模型
train_model()


sample_prompt = "[REQ] turn left [OBJ] aircraft [ACTION] heading [STA] _"
generated_instruction = generate_instruction(model, tokenizer, sample_prompt, temperature=0.8)
print("Generated Instruction:", generated_instruction)

#模型评估
def evaluate_model(model, val_loader):
    model.eval()
    total_loss = 0
    with torch.no_grad():
        for batch_idx, (input_ids, attention_mask) in enumerate(val_loader):
            outputs = model(input_ids)
            loss = criterion(outputs.view(-1, vocab_size), input_ids.view(-1))
            total_loss += loss.item()
    
    avg_loss = total_loss / len(val_loader)
    print(f"Validation Loss: {avg_loss:.4f}")

evaluate_model(model, val_loader)


def visualize_generated_instruction(instruction):

    print(f"Generated Command Structure: {instruction}")
    plt.figure(figsize=(8, 4))
    plt.text(0.5, 0.5, instruction, fontsize=14, ha='center', va='center')
    plt.axis('off')
    plt.show()

#可视化生成的指令
visualize_generated_instruction(generated_instruction)

#保存和加载模型
def save_model(model, optimizer, epoch, file_path='lstm_model.pth'):
    torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            }, file_path)
    print(f"Model saved to {file_path}")

def load_model(model, optimizer, file_path='lstm_model.pth'):
    checkpoint = torch.load(file_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    epoch = checkpoint['epoch']
    print(f"Model loaded from {file_path}, last saved at epoch {epoch}")
    return model, optimizer, epoch

#模型存储
save_model(model, optimizer, epochs)

# 17. 随机生成指令样本
def generate_random_samples(model, tokenizer, num_samples=5, temperature=1.0):
    prompts = [
        "[REQ] turn left [OBJ] aircraft [ACTION] heading [STA] _",
        "[REQ] climb [OBJ] aircraft [ACTION] to [STA] _",
        "[REQ] descend [OBJ] aircraft [ACTION] to [STA] _"
    ]
    for _ in range(num_samples):
        prompt = random.choice(prompts)
        instruction = generate_instruction(model, tokenizer, prompt, temperature)
        print(f"Generated Instruction: {instruction}")


generate_random_samples(model, tokenizer, num_samples=5)




from trajectoryFeatureCognition import trajectory_feature_recongition

#加载数据（词向量文件和原始数据）
npy_file_path = 'sentence_embeddings.npy'
csv_file_path = 'sentence_embeddings.csv'

sentence_embeddings = np.load(npy_file_path)


df = pd.read_csv(csv_file_path)


def generate_synthetic_structure(df):

    samples = []
    for _, row in df.iterrows():
        req = "[REQ] turn left"
        obj = "[OBJ] aircraft"
        action = "[ACTION] heading"
        sta = "[STA] _"  # 数值部分为空缺
        sample = f"{req} {obj} {action} {sta}"
        samples.append(sample)
    return samples

training_data = generate_synthetic_structure(df)


class CommandDataset(Dataset):
    def __init__(self, data, tokenizer, max_length=20):
        self.data = data
        self.tokenizer = tokenizer
        self.max_length = max_length

    def __len__(self):
        return len(self.data)

    def __getitem__(self, idx):
        text = self.data[idx]
        encoding = self.tokenizer(
            text,
            padding="max_length",
            truncation=True,
            max_length=self.max_length,
            return_tensors="pt"
        )
        return encoding.input_ids.squeeze(0), encoding.attention_mask.squeeze(0)

class LSTMGenerationModel(nn.Module):
    def __init__(self, vocab_size, embedding_dim, hidden_dim, num_layers, dropout=0.5):
        super(LSTMGenerationModel, self).__init__()
        self.embedding = nn.Embedding(vocab_size, embedding_dim)
        self.lstm = nn.LSTM(embedding_dim, hidden_dim, num_layers, batch_first=True, dropout=dropout)
        self.fc = nn.Linear(hidden_dim, vocab_size)

    def forward(self, x):
        embedded = self.embedding(x)
        lstm_out, _ = self.lstm(embedded)
        output = self.fc(lstm_out)
        return output

tokenizer = BertTokenizer.from_pretrained('bert-base-uncased')
train_data, val_data = train_test_split(training_data, test_size=0.1, random_state=42)

train_dataset = CommandDataset(train_data, tokenizer)
val_dataset = CommandDataset(val_data, tokenizer)

train_loader = DataLoader(train_dataset, batch_size=8, shuffle=True)
val_loader = DataLoader(val_dataset, batch_size=8, shuffle=False)

# 6. 定义训练参数
vocab_size = len(tokenizer)
embedding_dim = 128
hidden_dim = 256
num_layers = 2
epochs = 20  # 增加训练次数
lr = 0.001
dropout = 0.5


model = LSTMGenerationModel(vocab_size, embedding_dim, hidden_dim, num_layers, dropout)
criterion = nn.CrossEntropyLoss(ignore_index=tokenizer.pad_token_id)
optimizer = Adam(model.parameters(), lr=lr)

def train_model():
    for epoch in range(epochs):
        model.train()
        total_loss = 0
        for batch_idx, (input_ids, attention_mask) in enumerate(train_loader):
            optimizer.zero_grad()
            outputs = model(input_ids)
            loss = criterion(outputs.view(-1, vocab_size), input_ids.view(-1))
            loss.backward()
            optimizer.step()
            total_loss += loss.item()

            if batch_idx % 100 == 0:  # 每100个batch打印一次
                print(f"Epoch [{epoch+1}/{epochs}], Batch [{batch_idx}], Loss: {loss.item():.4f}")

        avg_loss = total_loss / len(train_loader)
        print(f"Epoch [{epoch+1}/{epochs}] complete. Average Loss: {avg_loss:.4f}")


def generate_instruction(model, tokenizer, prompt, max_length=20, temperature=1.0):

    model.eval()
    inputs = tokenizer(prompt, return_tensors='pt', padding=True, truncation=True)
    input_ids = inputs['input_ids']
    attention_mask = inputs['attention_mask']

    with torch.no_grad():
        outputs = model(input_ids)
    
    # 使用温度采样来生成
    logits = outputs.squeeze(0)
    logits = logits / temperature  # 调整logits的温度
    
    predicted_ids = torch.argmax(logits, dim=-1)  # 选择最大概率的词
    generated_text = tokenizer.decode(predicted_ids.tolist(), skip_special_tokens=True)
    return generated_text

train_model()


sample_prompt = "[REQ] turn left [OBJ] aircraft [ACTION] heading [STA] _"
generated_instruction = generate_instruction(model, tokenizer, sample_prompt, temperature=0.8)
print("Generated Instruction:", generated_instruction)


def evaluate_model(model, val_loader):
    model.eval()
    total_loss = 0
    with torch.no_grad():
        for batch_idx, (input_ids, attention_mask) in enumerate(val_loader):
            outputs = model(input_ids)
            loss = criterion(outputs.view(-1, vocab_size), input_ids.view(-1))
            total_loss += loss.item()
    
    avg_loss = total_loss / len(val_loader)
    print(f"Validation Loss: {avg_loss:.4f}")

evaluate_model(model, val_loader)


def visualize_generated_instruction(instruction):

    print(f"Generated Command Structure: {instruction}")
    plt.figure(figsize=(8, 4))
    plt.text(0.5, 0.5, instruction, fontsize=14, ha='center', va='center')
    plt.axis('off')
    plt.show()


visualize_generated_instruction(generated_instruction)


def save_model(model, optimizer, epoch, file_path='lstm_model.pth'):
    torch.save({
            'epoch': epoch,
            'model_state_dict': model.state_dict(),
            'optimizer_state_dict': optimizer.state_dict(),
            }, file_path)
    print(f"Model saved to {file_path}")

# 保存训练好的LSTM模型


def load_model(model, optimizer, file_path='lstm_model.pth'):
    checkpoint = torch.load(file_path)
    model.load_state_dict(checkpoint['model_state_dict'])
    optimizer.load_state_dict(checkpoint['optimizer_state_dict'])
    epoch = checkpoint['epoch']
    print(f"Model loaded from {file_path}, last saved at epoch {epoch}")
    return model, optimizer, epoch


save_model(model, optimizer, epochs)


def generate_random_samples(model, tokenizer, num_samples=5, temperature=1.0):
    prompts = [
        "[REQ] turn left [OBJ] aircraft [ACTION] heading [STA] _",
        "[REQ] climb [OBJ] aircraft [ACTION] to [STA] _",
        "[REQ] descend [OBJ] aircraft [ACTION] to [STA] _"
    ]
    for _ in range(num_samples):
        prompt = random.choice(prompts)
        instruction = generate_instruction(model, tokenizer, prompt, temperature)
        print(f"Generated Instruction: {instruction}")


generate_random_samples(model, tokenizer, num_samples=5)

#调用航迹特征识别生成管制指令
tracklis = [
    [111.4353332519528, 24.53933270263672, 10100],
    [111.43289192970556, 24.539978338758285, 10100],
    [111.43045060745833, 24.54062397487985, 10100],
    [111.42800928521109, 24.541269611001415, 10100],
    [111.42556796296385, 24.54191524712298, 10100],
    [111.42316377644772, 24.542687767356984, 10100],
    [111.42075958993159, 24.54346028759099, 10100],
    [111.41839912885469, 24.54435757451317, 10100],
    [111.41608886307675, 24.545377168722446, 10100],
    [111.41383512487569, 24.546516275581954, 10100],
]


resultdict = trajectory_feature_recongition(tracklis=tracklis, step=2)

# 生成管制指令
def generate_control_instruction(features):
    instructions = []
    for key in features.keys():
        if features[key]:
            for segment in features[key]:
                if key == 'r':
                    instructions.append(f"[REQ] turn right [OBJ] aircraft [ACTION] heading [STA] {segment}")
                elif key == 'l':
                    instructions.append(f"[REQ] turn left [OBJ] aircraft [ACTION] heading [STA] {segment}")
                elif key == 's':
                    instructions.append(f"[REQ] continue straight [OBJ] aircraft [ACTION] heading [STA] {segment}")
                elif key == 'c':
                    instructions.append(f"[REQ] climb [OBJ] aircraft [ACTION] to [STA] {segment}")
                elif key == 'd':
                    instructions.append(f"[REQ] descend [OBJ] aircraft [ACTION] to [STA] {segment}")
                elif key == 'ac':
                    instructions.append(f"[REQ] accelerate [OBJ] aircraft [ACTION] speed [STA] {segment}")
                elif key == 'dc':
                    instructions.append(f"[REQ] decelerate [OBJ] aircraft [ACTION] speed [STA] {segment}")
    return instructions

control_instructions = generate_control_instruction(resultdict)
print("生成的航空器飞行引导指令：")
for instruction in control_instructions:
    print(instruction)
